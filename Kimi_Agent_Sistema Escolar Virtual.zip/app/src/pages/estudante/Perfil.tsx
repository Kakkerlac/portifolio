import { useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  UserCircle, 
  Mail, 
  Phone, 
  MapPin, 
  Calendar,
  GraduationCap,
  CreditCard,
  FileText,
  Bell,
  Lock,
  Edit,
  Eye,
  User,
  Users,
  AlertCircle
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { mockEstudantes, mockMensalidades, mockAvisos } from '@/data/mockData';
import { cn } from '@/lib/utils';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';

export default function Perfil() {
  const { user } = useAuth();
  const [showEncarregadoDialog, setShowEncarregadoDialog] = useState(false);
  
  const estudanteData = mockEstudantes.find(e => e.id === user?.id);
  const mensalidades = mockMensalidades.filter(m => m.estudante_id === user?.id);
  const avisos = mockAvisos.filter(a => a.tipo_destino === 'todos' || a.tipo_destino === 'estudante');

  const infoFields = [
    { label: 'Nome Completo', value: user?.nome_completo, icon: UserCircle },
    { label: 'Número de Estudante', value: user?.numero_utilizador, icon: GraduationCap },
    { label: 'Número de Matrícula', value: estudanteData?.numero_matricula, icon: FileText },
    { label: 'Email', value: user?.email, icon: Mail },
    { label: 'Telefone', value: user?.telefone, icon: Phone },
    { label: 'Data de Nascimento', value: user?.data_nascimento ? new Date(user.data_nascimento).toLocaleDateString('pt-AO') : '-', icon: Calendar },
    { label: 'Género', value: user?.genero, icon: User },
    { label: 'Turma', value: '10ª Classe A', icon: Users },
    { label: 'Ano Letivo', value: '2024/2025', icon: Calendar },
    { label: 'Data de Matrícula', value: estudanteData?.data_matricula ? new Date(estudanteData.data_matricula).toLocaleDateString('pt-AO') : '-', icon: Calendar },
  ];

  const statusPagamento = estudanteData?.status_pagamento || 'regular';

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">Perfil</h1>
            <p className="text-muted-foreground">Informações pessoais e académicas</p>
          </div>
          <Button variant="outline">
            <Edit className="h-4 w-4 mr-2" />
            Pedir Alteração
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Profile Info */}
          <div className="space-y-6">
            {/* Profile Card */}
            <Card>
              <CardContent className="p-6 text-center">
                <Avatar className="h-24 w-24 mx-auto mb-4">
                  <AvatarImage src={user?.foto_url} />
                  <AvatarFallback className="text-2xl">
                    {user?.nome_completo.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <h2 className="text-xl font-bold">{user?.nome_completo}</h2>
                <p className="text-muted-foreground">{user?.email}</p>
                <div className="flex justify-center gap-2 mt-4">
                  <Badge variant="outline">{user?.numero_utilizador}</Badge>
                  <Badge className={cn(
                    statusPagamento === 'regular' && 'bg-green-100 text-green-800',
                    statusPagamento === 'pendente' && 'bg-amber-100 text-amber-800',
                    statusPagamento === 'bloqueado' && 'bg-red-100 text-red-800'
                  )}>
                    {statusPagamento === 'regular' && 'Pagamento Regular'}
                    {statusPagamento === 'pendente' && 'Pagamento Pendente'}
                    {statusPagamento === 'bloqueado' && 'Conta Bloqueada'}
                  </Badge>
                </div>
              </CardContent>
            </Card>

            {/* Encarregado de Educação */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Encarregado de Educação
                </CardTitle>
              </CardHeader>
              <CardContent>
                {estudanteData?.encarregado ? (
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <User className="h-5 w-5 text-muted-foreground" />
                      <span>{estudanteData.encarregado.nome_completo}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <Phone className="h-5 w-5 text-muted-foreground" />
                      <span>{estudanteData.encarregado.telefone}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <Mail className="h-5 w-5 text-muted-foreground" />
                      <span>{estudanteData.encarregado.email}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <UserCircle className="h-5 w-5 text-muted-foreground" />
                      <span>{estudanteData.encarregado.grau_parentesco}</span>
                    </div>
                    <Dialog open={showEncarregadoDialog} onOpenChange={setShowEncarregadoDialog}>
                      <DialogTrigger asChild>
                        <Button variant="outline" className="w-full mt-4">
                          <Eye className="h-4 w-4 mr-2" />
                          Aceder como Encarregado
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Acesso do Encarregado</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4 pt-4">
                          <div className="bg-muted p-4 rounded-lg">
                            <p className="text-sm text-muted-foreground">
                              Como encarregado de educação, você pode:
                            </p>
                            <ul className="text-sm mt-2 space-y-1">
                              <li>• Consultar notas do estudante</li>
                              <li>• Visualizar pagamentos pendentes</li>
                              <li>• Receber avisos da escola</li>
                              <li>• Comunicar com a secretaria</li>
                            </ul>
                          </div>
                          <div>
                            <Label>Senha de Acesso do Encarregado</Label>
                            <Input type="password" placeholder="Digite a senha" />
                          </div>
                          <Button className="w-full">Entrar como Encarregado</Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                ) : (
                  <div className="text-center py-4 text-muted-foreground">
                    <AlertCircle className="h-8 w-8 mx-auto mb-2" />
                    <p>Nenhum encarregado registrado</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Resumo Financeiro */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CreditCard className="h-5 w-5" />
                  Resumo Financeiro
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Mensalidade</span>
                    <span className="font-medium">45.000 Kz</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Status</span>
                    <Badge variant={statusPagamento === 'regular' ? 'default' : 'destructive'}>
                      {statusPagamento === 'regular' ? 'Em Dia' : 'Pendente'}
                    </Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Próximo Vencimento</span>
                    <span className="font-medium">10/03/2025</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Details */}
          <div className="lg:col-span-2 space-y-6">
            <Tabs defaultValue="info" className="space-y-6">
              <TabsList>
                <TabsTrigger value="info">Informações Pessoais</TabsTrigger>
                <TabsTrigger value="pagamentos">Pagamentos</TabsTrigger>
                <TabsTrigger value="seguranca">Segurança</TabsTrigger>
              </TabsList>

              <TabsContent value="info" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Dados Pessoais</CardTitle>
                    <CardDescription>
                      Estas informações são geridas pela secretaria. 
                      Para alterações, contacte a secretaria.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {infoFields.map((field) => (
                        <div key={field.label} className="flex items-start gap-3 p-3 rounded-lg border">
                          <field.icon className="h-5 w-5 text-muted-foreground mt-0.5" />
                          <div>
                            <p className="text-sm text-muted-foreground">{field.label}</p>
                            <p className="font-medium">{field.value || '-'}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="pagamentos" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Histórico de Pagamentos</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {mensalidades.map((mensalidade) => (
                        <div 
                          key={mensalidade.id}
                          className="flex items-center justify-between p-4 rounded-lg border"
                        >
                          <div>
                            <p className="font-medium">
                              {new Date(2025, mensalidade.mes_referencia - 1).toLocaleString('pt-AO', { month: 'long' })}
                              {' / '}{mensalidade.ano_letivo}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              Vencimento: {new Date(mensalidade.data_vencimento).toLocaleDateString('pt-AO')}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="font-medium">{mensalidade.valor_final.toLocaleString('pt-AO')} Kz</p>
                            <Badge className={cn(
                              mensalidade.status === 'pago' && 'bg-green-100 text-green-800',
                              mensalidade.status === 'pendente' && 'bg-amber-100 text-amber-800',
                              mensalidade.status === 'atrasado' && 'bg-red-100 text-red-800'
                            )}>
                              {mensalidade.status === 'pago' && 'Pago'}
                              {mensalidade.status === 'pendente' && 'Pendente'}
                              {mensalidade.status === 'atrasado' && 'Atrasado'}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="seguranca" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Segurança da Conta</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between p-4 rounded-lg border">
                      <div className="flex items-center gap-3">
                        <Lock className="h-5 w-5 text-muted-foreground" />
                        <div>
                          <p className="font-medium">Palavra-passe</p>
                          <p className="text-sm text-muted-foreground">Última alteração: há 3 meses</p>
                        </div>
                      </div>
                      <Button variant="outline">Alterar</Button>
                    </div>
                    <div className="flex items-center justify-between p-4 rounded-lg border">
                      <div className="flex items-center gap-3">
                        <Bell className="h-5 w-5 text-muted-foreground" />
                        <div>
                          <p className="font-medium">Notificações</p>
                          <p className="text-sm text-muted-foreground">Receber notificações por email</p>
                        </div>
                      </div>
                      <Button variant="outline">Configurar</Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
