import { Controller, Get, Post, Put, Body, Param, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { SubjectsService } from './subjects.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { Role } from '@prisma/client';

@ApiTags('subjects')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('subjects')
export class SubjectsController {
  constructor(private subjectsService: SubjectsService) {}

  @Get()
  findAll() { return this.subjectsService.findAll(); }

  @Get(':id')
  findOne(@Param('id') id: string) { return this.subjectsService.findOne(id); }

  @Post()
  @Roles(Role.ADMIN, Role.SECRETARY)
  create(@Body() dto: any) { return this.subjectsService.create(dto); }

  @Put(':id')
  @Roles(Role.ADMIN, Role.SECRETARY)
  update(@Param('id') id: string, @Body() dto: any) { return this.subjectsService.update(id, dto); }
}