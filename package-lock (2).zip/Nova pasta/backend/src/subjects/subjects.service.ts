import { Injectable, NotFoundException, ConflictException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class SubjectsService {
  constructor(private prisma: PrismaService) {}

  async findAll() {
    return this.prisma.subject.findMany({
      where: { ativo: true },
      orderBy: { nome: 'asc' },
    });
  }

  async findOne(id: string) {
    const subject = await this.prisma.subject.findUnique({ where: { id } });
    if (!subject) throw new NotFoundException('Disciplina não encontrada');
    return subject;
  }

  async create(dto: any) {
    const exists = await this.prisma.subject.findUnique({ where: { codigo: dto.codigo } });
    if (exists) throw new ConflictException('Código de disciplina já existe');
    return this.prisma.subject.create({ data: dto });
  }

  async update(id: string, dto: any) {
    await this.findOne(id);
    return this.prisma.subject.update({ where: { id }, data: dto });
  }
}