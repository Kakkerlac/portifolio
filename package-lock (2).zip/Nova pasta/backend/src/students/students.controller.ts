import { Controller, Get, Post, Put, Body, Param, Query, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { StudentsService } from './students.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { Role } from '@prisma/client';

@ApiTags('students')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('students')
export class StudentsController {
  constructor(private studentsService: StudentsService) {}

  @Get()
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY, Role.TEACHER)
  findAll(
    @Query('turmaId') turmaId?: string,
    @Query('statusPagamento') statusPagamento?: any,
    @Query('anoLetivo') anoLetivo?: number,
  ) {
    return this.studentsService.findAll({ turmaId, statusPagamento, anoLetivo });
  }

  @Get('me')
  @Roles(Role.STUDENT)
  getMyProfile(@Request() req: any) {
    return this.studentsService.findByUserId(req.user.sub);
  }

  @Get('me/dashboard')
  @Roles(Role.STUDENT)
  getMyDashboard(@Request() req: any) {
    return this.studentsService.findByUserId(req.user.sub).then(s =>
      this.studentsService.getDashboard(s.id),
    );
  }

  @Get('me/notas')
  @Roles(Role.STUDENT)
  getMyNotas(@Request() req: any, @Query('anoLetivo') ano?: number, @Query('trimestre') trim?: number) {
    return this.studentsService.findByUserId(req.user.sub).then(s =>
      this.studentsService.getNotas(s.id, ano, trim),
    );
  }

  @Get('me/presencas')
  @Roles(Role.STUDENT)
  getMyPresencas(@Request() req: any, @Query('mes') mes?: number) {
    return this.studentsService.findByUserId(req.user.sub).then(s =>
      this.studentsService.getPresencas(s.id, mes),
    );
  }

  @Get('me/testes')
  @Roles(Role.STUDENT)
  getMyTestes(@Request() req: any) {
    return this.studentsService.findByUserId(req.user.sub).then(s =>
      this.studentsService.getTestesDisponiveis(s.id),
    );
  }

  @Get(':id')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY, Role.TEACHER)
  findOne(@Param('id') id: string) {
    return this.studentsService.findOne(id);
  }

  @Post()
  @Roles(Role.ADMIN, Role.SECRETARY)
  create(@Body() dto: any) {
    return this.studentsService.create(dto);
  }

  @Put(':id')
  @Roles(Role.ADMIN, Role.SECRETARY)
  update(@Param('id') id: string, @Body() dto: any) {
    return this.studentsService.update(id, dto);
  }

  @Get(':id/notas')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY, Role.TEACHER)
  getNotas(@Param('id') id: string, @Query('anoLetivo') ano?: number) {
    return this.studentsService.getNotas(id, ano);
  }

  @Get(':id/presencas')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY, Role.TEACHER)
  getPresencas(@Param('id') id: string, @Query('mes') mes?: number) {
    return this.studentsService.getPresencas(id, mes);
  }
}