import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { PaymentStatus } from '@prisma/client';

@Injectable()
export class StudentsService {
  constructor(private prisma: PrismaService) {}

  async findAll(filters?: { turmaId?: string; statusPagamento?: PaymentStatus; anoLetivo?: number }) {
    return this.prisma.student.findMany({
      where: {
        turmaId: filters?.turmaId,
        statusPagamento: filters?.statusPagamento,
        anoLetivo: filters?.anoLetivo,
      },
      include: {
        user: { select: { nome: true, apelido: true, email: true, telefone: true, fotoUrl: true, ativo: true, bloqueado: true } },
        turma: { select: { nome: true, turno: true } },
        encarregado: { select: { nome: true, apelido: true, telefone: true, relacao: true } },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async findOne(id: string) {
    const student = await this.prisma.student.findUnique({
      where: { id },
      include: {
        user: { select: { nome: true, apelido: true, email: true, telefone: true, fotoUrl: true, genero: true, dataNascimento: true } },
        turma: true,
        encarregado: true,
        grades: { include: { classSubject: { include: { subject: true } } } },
        attendances: { take: 30, orderBy: { data: 'desc' } },
        payments: { take: 12, orderBy: { dataTransacao: 'desc' } },
        feeAssignments: { include: { fee: true }, orderBy: { dataVencimento: 'desc' } },
      },
    });
    if (!student) throw new NotFoundException('Estudante não encontrado');
    return student;
  }

  async findByUserId(userId: string) {
    const student = await this.prisma.student.findUnique({
      where: { userId },
      include: {
        user: { select: { nome: true, apelido: true, email: true, fotoUrl: true } },
        turma: { include: { classSubjects: { include: { subject: true, teacher: { include: { user: { select: { nome: true, apelido: true } } } } } } } },
        encarregado: true,
        feeAssignments: { where: { pago: false }, include: { fee: true } },
      },
    });
    if (!student) throw new NotFoundException('Estudante não encontrado');
    return student;
  }

  async create(dto: any) {
    return this.prisma.student.create({
      data: dto,
      include: { user: { select: { nome: true, apelido: true, email: true } } },
    });
  }

  async update(id: string, dto: any) {
    await this.findOne(id);
    return this.prisma.student.update({ where: { id }, data: dto });
  }

  async getNotas(studentId: string, anoLetivo?: number, trimestre?: number) {
    return this.prisma.grade.findMany({
      where: { studentId, anoLetivo, trimestre },
      include: { classSubject: { include: { subject: true } }, teacher: { include: { user: { select: { nome: true, apelido: true } } } } },
      orderBy: [{ anoLetivo: 'desc' }, { trimestre: 'desc' }],
    });
  }

  async getPresencas(studentId: string, mes?: number, anoLetivo?: number) {
    const now = new Date();
    const ano = anoLetivo || now.getFullYear();
    const startDate = mes ? new Date(ano, mes - 1, 1) : new Date(ano, 0, 1);
    const endDate = mes ? new Date(ano, mes, 0) : new Date(ano, 11, 31);

    return this.prisma.attendance.findMany({
      where: { studentId, data: { gte: startDate, lte: endDate } },
      include: { classSubject: { include: { subject: true } } },
      orderBy: { data: 'desc' },
    });
  }

  async getTestesDisponiveis(studentId: string) {
    const student = await this.prisma.student.findUnique({
      where: { id: studentId },
      select: { turmaId: true, statusPagamento: true },
    });
    if (!student) throw new NotFoundException('Estudante não encontrado');
    if (student.statusPagamento === PaymentStatus.BLOCKED) {
      throw new BadRequestException('Conta bloqueada por inadimplência. Regularize o pagamento.');
    }

    return this.prisma.test.findMany({
      where: {
        status: 'PUBLISHED',
        dataInicio: { lte: new Date() },
        dataFim: { gte: new Date() },
        classSubject: { classId: student.turmaId },
      },
      include: {
        classSubject: { include: { subject: true } },
        _count: { select: { questions: true } },
      },
    });
  }

  async getDashboard(studentId: string) {
    const [student, notas, presencas, pagamentos] = await Promise.all([
      this.findOne(studentId),
      this.getNotas(studentId, new Date().getFullYear()),
      this.getPresencas(studentId),
      this.prisma.feeAssignment.findMany({
        where: { studentId, pago: false },
        include: { fee: true },
        orderBy: { dataVencimento: 'asc' },
      }),
    ]);

    const totalPresencas = presencas.length;
    const totalFaltas = presencas.filter(p => p.status === 'ABSENT').length;
    const percentagemPresenca = totalPresencas > 0 ? ((totalPresencas - totalFaltas) / totalPresencas * 100).toFixed(1) : '100';
    const mediaGeral = notas.length > 0 ? (notas.reduce((acc, n) => acc + (n.notaFinal || 0), 0) / notas.length).toFixed(1) : '0';

    return {
      student,
      resumo: {
        mediaGeral,
        percentagemPresenca,
        totalDisciplinas: notas.length,
        pagamentosPendentes: pagamentos.length,
        totalEmDivida: pagamentos.reduce((acc, p) => acc + p.valorTotal, 0),
      },
      notasRecentes: notas.slice(0, 5),
      pagamentosPendentes: pagamentos.slice(0, 3),
    };
  }
}