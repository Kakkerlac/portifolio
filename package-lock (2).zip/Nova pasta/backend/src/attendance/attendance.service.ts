import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { AttendanceStatus } from '@prisma/client';

@Injectable()
export class AttendanceService {
  constructor(private prisma: PrismaService) {}

  async registerBulk(dto: {
    classSubjectId: string;
    teacherId: string;
    data: string;
    registros: { studentId: string; status: AttendanceStatus; observacoes?: string }[];
  }) {
    const date = new Date(dto.data);
    return Promise.all(
      dto.registros.map(r =>
        this.prisma.attendance.upsert({
          where: { studentId_classSubjectId_data: { studentId: r.studentId, classSubjectId: dto.classSubjectId, data: date } },
          update: { status: r.status, observacoes: r.observacoes, teacherId: dto.teacherId },
          create: { studentId: r.studentId, classSubjectId: dto.classSubjectId, teacherId: dto.teacherId, data: date, status: r.status, observacoes: r.observacoes },
        }),
      ),
    );
  }

  async getByClassSubject(classSubjectId: string, mes?: number, anoLetivo?: number) {
    const ano = anoLetivo || new Date().getFullYear();
    const startDate = mes ? new Date(ano, mes - 1, 1) : new Date(ano, 0, 1);
    const endDate = mes ? new Date(ano, mes, 0, 23, 59, 59) : new Date(ano, 11, 31, 23, 59, 59);

    return this.prisma.attendance.findMany({
      where: { classSubjectId, data: { gte: startDate, lte: endDate } },
      include: {
        student: { include: { user: { select: { nome: true, apelido: true, fotoUrl: true } } } },
      },
      orderBy: [{ data: 'desc' }, { student: { user: { nome: 'asc' } } }],
    });
  }

  async getResumoByStudent(studentId: string, anoLetivo?: number) {
    const ano = anoLetivo || new Date().getFullYear();
    const registros = await this.prisma.attendance.findMany({
      where: { studentId, data: { gte: new Date(ano, 0, 1), lte: new Date(ano, 11, 31) } },
      include: { classSubject: { include: { subject: true } } },
    });

    // Agrupar por disciplina
    const bySubject: Record<string, any> = {};
    for (const r of registros) {
      const nome = r.classSubject.subject.nome;
      if (!bySubject[nome]) bySubject[nome] = { nome, presencas: 0, faltas: 0, atrasos: 0, justificadas: 0 };
      if (r.status === 'PRESENT') bySubject[nome].presencas++;
      else if (r.status === 'ABSENT') bySubject[nome].faltas++;
      else if (r.status === 'LATE') bySubject[nome].atrasos++;
      else if (r.status === 'JUSTIFIED') bySubject[nome].justificadas++;
    }

    return Object.values(bySubject).map((s: any) => ({
      ...s,
      total: s.presencas + s.faltas + s.atrasos + s.justificadas,
      percentagem: s.presencas + s.faltas + s.atrasos + s.justificadas > 0
        ? ((s.presencas / (s.presencas + s.faltas + s.atrasos + s.justificadas)) * 100).toFixed(1)
        : '100',
    }));
  }

  async justifyAbsence(attendanceId: string, justificativa: string) {
    return this.prisma.attendance.update({
      where: { id: attendanceId },
      data: { status: 'JUSTIFIED', justificativa },
    });
  }
}