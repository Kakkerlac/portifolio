import { Controller, Get, Post, Patch, Body, Param, Query, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AttendanceService } from './attendance.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { Role } from '@prisma/client';

@ApiTags('attendance')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('attendance')
export class AttendanceController {
  constructor(private attendanceService: AttendanceService) {}

  @Post('bulk')
  @Roles(Role.TEACHER, Role.ADMIN)
  @ApiOperation({ summary: 'Registar presenças em massa (turma completa)' })
  registerBulk(@Body() dto: any, @Request() req: any) {
    return this.attendanceService.registerBulk({ ...dto, teacherId: req.user.sub });
  }

  @Get('class-subject/:id')
  @Roles(Role.TEACHER, Role.ADMIN, Role.DIRECTOR, Role.SECRETARY)
  getByClassSubject(
    @Param('id') id: string,
    @Query('mes') mes?: number,
    @Query('anoLetivo') anoLetivo?: number,
  ) {
    return this.attendanceService.getByClassSubject(id, mes, anoLetivo);
  }

  @Get('student/:studentId/resumo')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY, Role.TEACHER, Role.STUDENT)
  getResumo(@Param('studentId') studentId: string, @Query('anoLetivo') anoLetivo?: number) {
    return this.attendanceService.getResumoByStudent(studentId, anoLetivo);
  }

  @Patch(':id/justify')
  @Roles(Role.ADMIN, Role.SECRETARY, Role.TEACHER)
  justifyAbsence(@Param('id') id: string, @Body() body: { justificativa: string }) {
    return this.attendanceService.justifyAbsence(id, body.justificativa);
  }
}