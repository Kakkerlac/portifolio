import { Injectable } from '@nestjs/common';

@Injectable()
export class FinanceService {
  getStatus() {
    return 'finance service ready';
  }
}