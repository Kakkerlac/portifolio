import { Controller, Get } from '@nestjs/common';

@Controller('finance')
export class FinanceController {
  @Get()
  getFinanceBase() {
    return { module: 'finance ready' };
  }
}