import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { NotificationType } from '@prisma/client';

@Injectable()
export class NotificationsService {
  constructor(private prisma: PrismaService) {}

  async create(dto: {
    userId: string;
    tipo: NotificationType;
    titulo: string;
    mensagem: string;
    dados?: any;
  }) {
    return this.prisma.notification.create({ data: dto });
  }

  async createBulk(userIds: string[], dto: Omit<Parameters<typeof this.create>[0], 'userId'>) {
    return this.prisma.notification.createMany({
      data: userIds.map(userId => ({ userId, ...dto })),
    });
  }

  async findByUser(userId: string, page = 1, limit = 20) {
    const skip = (page - 1) * limit;
    const [notifications, total, unread] = await Promise.all([
      this.prisma.notification.findMany({
        where: { userId },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      this.prisma.notification.count({ where: { userId } }),
      this.prisma.notification.count({ where: { userId, lida: false } }),
    ]);
    return { notifications, total, unread, page, totalPages: Math.ceil(total / limit) };
  }

  async markAsRead(id: string, userId: string) {
    return this.prisma.notification.updateMany({
      where: { id, userId },
      data: { lida: true, lidaEm: new Date() },
    });
  }

  async markAllAsRead(userId: string) {
    return this.prisma.notification.updateMany({
      where: { userId, lida: false },
      data: { lida: true, lidaEm: new Date() },
    });
  }

  async getUnreadCount(userId: string) {
    return this.prisma.notification.count({ where: { userId, lida: false } });
  }

  // Notificações de sistema automáticas
  async notifyPaymentDue(studentUserId: string, valor: number, vencimento: Date) {
    return this.create({
      userId: studentUserId,
      tipo: NotificationType.PAYMENT_DUE,
      titulo: 'Propina a vencer',
      mensagem: `A sua propina de ${valor} AOA vence em ${vencimento.toLocaleDateString('pt-AO')}`,
      dados: { valor, vencimento },
    });
  }

  async notifyAccountBlocked(studentUserId: string) {
    return this.create({
      userId: studentUserId,
      tipo: NotificationType.ACCOUNT_BLOCKED,
      titulo: 'Conta bloqueada',
      mensagem: 'A sua conta foi bloqueada por inadimplência. Regularize o pagamento para continuar a aceder ao sistema.',
    });
  }

  async notifyNewGrade(studentUserId: string, disciplina: string, nota: number) {
    return this.create({
      userId: studentUserId,
      tipo: NotificationType.NEW_GRADE,
      titulo: 'Nova nota lançada',
      mensagem: `Foi lançada uma nova nota em ${disciplina}: ${nota} valores`,
      dados: { disciplina, nota },
    });
  }

  async notifyNewTest(studentUserIds: string[], titulo: string, dataFim: Date) {
    return this.createBulk(studentUserIds, {
      tipo: NotificationType.NEW_TEST,
      titulo: 'Novo teste disponível',
      mensagem: `O teste "${titulo}" está disponível. Prazo: ${dataFim.toLocaleDateString('pt-AO')}`,
      dados: { titulo, dataFim },
    });
  }
}