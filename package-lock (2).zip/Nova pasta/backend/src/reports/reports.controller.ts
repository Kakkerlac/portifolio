import { Controller, Get, Query, Param, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { ReportsService } from './reports.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { Role } from '@prisma/client';

@ApiTags('reports')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('reports')
export class ReportsController {
  constructor(private reportsService: ReportsService) {}

  @Get('director-dashboard')
  @Roles(Role.ADMIN, Role.DIRECTOR)
  @ApiOperation({ summary: 'Dashboard estratégico da direção' })
  getDirectorDashboard(@Query('anoLetivo') anoLetivo?: number) {
    return this.reportsService.getDirectorDashboard(anoLetivo);
  }

  @Get('students')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY)
  @ApiOperation({ summary: 'Relatório de desempenho dos alunos' })
  getStudentReport(
    @Query('turmaId') turmaId?: string,
    @Query('anoLetivo') anoLetivo?: number,
    @Query('trimestre') trimestre?: number,
  ) {
    return this.reportsService.getStudentReport({ turmaId, anoLetivo, trimestre });
  }

  @Get('class-performance/:classId')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY, Role.TEACHER)
  @ApiOperation({ summary: 'Desempenho por turma e disciplina' })
  getClassPerformance(@Param('classId') classId: string, @Query('anoLetivo') anoLetivo?: number) {
    return this.reportsService.getClassPerformance(classId, anoLetivo);
  }

  @Get('financial')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY)
  @ApiOperation({ summary: 'Relatório financeiro completo' })
  getFinancialReport(@Query('anoLetivo') anoLetivo?: number) {
    return this.reportsService.getFinancialReport(anoLetivo);
  }

  @Get('attendance/:classId')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY, Role.TEACHER)
  @ApiOperation({ summary: 'Relatório de presenças por turma' })
  getAttendanceReport(
    @Param('classId') classId: string,
    @Query('mes') mes?: number,
    @Query('anoLetivo') anoLetivo?: number,
  ) {
    return this.reportsService.getAttendanceReport(classId, mes, anoLetivo);
  }

  @Get('students-at-risk')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY, Role.TEACHER)
  @ApiOperation({ summary: 'Alunos em risco de reprovação' })
  getStudentsAtRisk(@Query('anoLetivo') anoLetivo?: number) {
    return this.reportsService.getStudentsAtRisk(anoLetivo);
  }
}