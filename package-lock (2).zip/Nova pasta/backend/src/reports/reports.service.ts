import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class ReportsService {
  constructor(private prisma: PrismaService) {}

  // ─── DASHBOARD DIREÇÃO ───────────────────────────────────

  async getDirectorDashboard(anoLetivo?: number) {
    const ano = anoLetivo || new Date().getFullYear();

    const [
      totalStudents, totalTeachers, totalClasses,
      studentsBlocked, studentsRegular,
      avgGrade, passRate,
      financialSummary,
    ] = await Promise.all([
      this.prisma.student.count({ where: { anoLetivo: ano } }),
      this.prisma.teacher.count({ where: { user: { ativo: true } } }),
      this.prisma.class.count({ where: { anoLetivo: ano, ativo: true } }),
      this.prisma.student.count({ where: { statusPagamento: 'BLOCKED' } }),
      this.prisma.student.count({ where: { statusPagamento: 'REGULAR' } }),
      this.prisma.grade.aggregate({ where: { anoLetivo: ano }, _avg: { notaFinal: true } }),
      this.prisma.grade.groupBy({
        by: ['aprovado'],
        where: { anoLetivo: ano, aprovado: { not: null } },
        _count: { id: true },
      }),
      this.prisma.transaction.groupBy({
        by: ['tipo'],
        where: { anoLetivo: ano },
        _sum: { valor: true },
      }),
    ]);

    const aprovados = passRate.find(r => r.aprovado === true)?._count.id || 0;
    const reprovados = passRate.find(r => r.aprovado === false)?._count.id || 0;
    const totalAvaliados = aprovados + reprovados;

    const receitas = financialSummary.find(f => f.tipo === 'INCOME')?._sum.valor || 0;
    const despesas = financialSummary.find(f => f.tipo === 'EXPENSE')?._sum.valor || 0;

    return {
      academico: {
        totalAlunos: totalStudents,
        totalProfessores: totalTeachers,
        totalTurmas: totalClasses,
        mediaGeral: avgGrade._avg.notaFinal?.toFixed(1) || '0',
        taxaAprovacao: totalAvaliados > 0 ? ((aprovados / totalAvaliados) * 100).toFixed(1) : '0',
        aprovados,
        reprovados,
      },
      financeiro: {
        receitas,
        despesas,
        saldo: receitas - despesas,
        alunosBloqueados: studentsBlocked,
        alunosRegulares: studentsRegular,
        taxaCobranca: totalStudents > 0 ? ((studentsRegular / totalStudents) * 100).toFixed(1) : '0',
      },
    };
  }

  // ─── RELATÓRIO DE ALUNOS ─────────────────────────────────

  async getStudentReport(filters: { turmaId?: string; anoLetivo?: number; trimestre?: number }) {
    const ano = filters.anoLetivo || new Date().getFullYear();
    const students = await this.prisma.student.findMany({
      where: { turmaId: filters.turmaId, anoLetivo: ano },
      include: {
        user: { select: { nome: true, apelido: true, email: true } },
        turma: { select: { nome: true, turno: true } },
        grades: {
          where: { anoLetivo: ano, trimestre: filters.trimestre },
          include: { classSubject: { include: { subject: true } } },
        },
      },
      orderBy: { user: { nome: 'asc' } },
    });

    return students.map(s => {
      const notas = s.grades.map(g => g.notaFinal || 0);
      const media = notas.length ? (notas.reduce((a, b) => a + b, 0) / notas.length).toFixed(1) : '0';
      const aprovado = notas.length > 0 && notas.every(n => n >= 10);
      return {
        id: s.id,
        nome: `${s.user.nome} ${s.user.apelido}`,
        turma: s.turma?.nome,
        numeroMatricula: s.numeroMatricula,
        media,
        aprovado,
        notas: s.grades,
        statusPagamento: s.statusPagamento,
      };
    });
  }

  // ─── RELATÓRIO DE DESEMPENHO POR TURMA ───────────────────

  async getClassPerformance(classId: string, anoLetivo?: number) {
    const ano = anoLetivo || new Date().getFullYear();
    const subjects = await this.prisma.classSubject.findMany({
      where: { classId, anoLetivo: ano },
      include: {
        subject: true,
        grades: { where: { anoLetivo: ano } },
      },
    });

    return subjects.map(cs => {
      const notas = cs.grades.map(g => g.notaFinal || 0);
      const media = notas.length ? (notas.reduce((a, b) => a + b, 0) / notas.length).toFixed(1) : '0';
      const aprovados = notas.filter(n => n >= 10).length;
      return {
        disciplina: cs.subject.nome,
        totalAlunos: notas.length,
        media,
        aprovados,
        reprovados: notas.length - aprovados,
        taxaAprovacao: notas.length > 0 ? ((aprovados / notas.length) * 100).toFixed(1) : '0',
      };
    });
  }

  // ─── RELATÓRIO FINANCEIRO ────────────────────────────────

  async getFinancialReport(anoLetivo?: number) {
    const ano = anoLetivo || new Date().getFullYear();
    const [propinas, transactions, inadimplentes] = await Promise.all([
      this.prisma.feeAssignment.groupBy({
        by: ['pago'],
        where: { anoLetivo: ano },
        _sum: { valorTotal: true },
        _count: { id: true },
      }),
      this.prisma.transaction.findMany({
        where: { anoLetivo: ano },
        include: { account: { select: { nome: true } } },
        orderBy: { data: 'desc' },
        take: 50,
      }),
      this.prisma.student.findMany({
        where: { statusPagamento: { in: ['OVERDUE', 'BLOCKED'] } },
        include: {
          user: { select: { nome: true, apelido: true, email: true, telefone: true } },
          feeAssignments: { where: { pago: false, anoLetivo: ano }, include: { fee: true } },
        },
      }),
    ]);

    const pagas = propinas.find(p => p.pago === true);
    const pendentes = propinas.find(p => p.pago === false);

    return {
      propinas: {
        totalPago: pagas?._sum.valorTotal || 0,
        totalPendente: pendentes?._sum.valorTotal || 0,
        pagasCount: pagas?._count.id || 0,
        pendentesCount: pendentes?._count.id || 0,
      },
      transacoesRecentes: transactions,
      inadimplentes: inadimplentes.map(i => ({
        nome: `${i.user.nome} ${i.user.apelido}`,
        email: i.user.email,
        telefone: i.user.telefone,
        status: i.statusPagamento,
        totalEmDivida: i.feeAssignments.reduce((a, f) => a + f.valorTotal, 0),
        parcelas: i.feeAssignments.length,
      })),
    };
  }

  // ─── RELATÓRIO DE PRESENÇAS ──────────────────────────────

  async getAttendanceReport(classId: string, mes?: number, anoLetivo?: number) {
    const ano = anoLetivo || new Date().getFullYear();
    const startDate = mes ? new Date(ano, mes - 1, 1) : new Date(ano, 0, 1);
    const endDate = mes ? new Date(ano, mes, 0, 23, 59, 59) : new Date(ano, 11, 31, 23, 59, 59);

    const students = await this.prisma.student.findMany({
      where: { turmaId: classId },
      include: {
        user: { select: { nome: true, apelido: true } },
        attendances: {
          where: { data: { gte: startDate, lte: endDate } },
        },
      },
    });

    return students.map(s => {
      const total = s.attendances.length;
      const presencas = s.attendances.filter(a => a.status === 'PRESENT').length;
      const faltas = s.attendances.filter(a => a.status === 'ABSENT').length;
      const atrasos = s.attendances.filter(a => a.status === 'LATE').length;
      return {
        nome: `${s.user.nome} ${s.user.apelido}`,
        total,
        presencas,
        faltas,
        atrasos,
        percentagem: total > 0 ? ((presencas / total) * 100).toFixed(1) : '100',
        emRisco: total > 0 && (faltas / total) > 0.25, // Mais de 25% de faltas
      };
    });
  }

  // ─── ALUNOS EM RISCO ─────────────────────────────────────

  async getStudentsAtRisk(anoLetivo?: number) {
    const ano = anoLetivo || new Date().getFullYear();
    const grades = await this.prisma.grade.findMany({
      where: { anoLetivo: ano, notaFinal: { lt: 10 } },
      include: {
        student: { include: { user: { select: { nome: true, apelido: true } }, turma: true } },
        classSubject: { include: { subject: true } },
      },
      distinct: ['studentId'],
    });

    const byStudent: Record<string, any> = {};
    for (const g of grades) {
      const key = g.studentId;
      if (!byStudent[key]) {
        byStudent[key] = {
          id: g.student.id,
          nome: `${g.student.user.nome} ${g.student.user.apelido}`,
          turma: g.student.turma?.nome,
          disciplinasEmRisco: [],
        };
      }
      byStudent[key].disciplinasEmRisco.push({
        disciplina: g.classSubject.subject.nome,
        nota: g.notaFinal,
      });
    }

    return Object.values(byStudent);
  }
}