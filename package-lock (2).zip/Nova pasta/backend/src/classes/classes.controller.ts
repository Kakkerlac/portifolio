import { Controller, Get, Post, Put, Body, Param, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { ClassesService } from './classes.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { Role } from '@prisma/client';

@ApiTags('classes')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('classes')
export class ClassesController {
  constructor(private classesService: ClassesService) {}

  @Get()
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY, Role.TEACHER)
  findAll(@Query('anoLetivo') anoLetivo?: number) {
    return this.classesService.findAll(anoLetivo);
  }

  @Get(':id')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY, Role.TEACHER)
  findOne(@Param('id') id: string) {
    return this.classesService.findOne(id);
  }

  @Get(':id/schedule')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY, Role.TEACHER, Role.STUDENT)
  getSchedule(@Param('id') id: string) {
    return this.classesService.getSchedule(id);
  }

  @Get(':id/stats')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY)
  getStats(@Param('id') id: string) {
    return this.classesService.getStatsByClass(id);
  }

  @Post()
  @Roles(Role.ADMIN, Role.SECRETARY)
  create(@Body() dto: any) {
    return this.classesService.create(dto);
  }

  @Put(':id')
  @Roles(Role.ADMIN, Role.SECRETARY)
  update(@Param('id') id: string, @Body() dto: any) {
    return this.classesService.update(id, dto);
  }

  @Post(':id/subjects')
  @Roles(Role.ADMIN, Role.SECRETARY)
  @ApiOperation({ summary: 'Atribuir disciplina a uma turma' })
  assignSubject(@Param('id') id: string, @Body() dto: any) {
    return this.classesService.assignSubject(id, dto);
  }

  @Post(':id/schedule')
  @Roles(Role.ADMIN, Role.SECRETARY)
  createSchedule(@Param('id') id: string, @Body() dto: any) {
    return this.classesService.createSchedule(id, dto);
  }
}