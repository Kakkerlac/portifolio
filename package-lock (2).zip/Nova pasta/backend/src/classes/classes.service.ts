import { Injectable, NotFoundException, ConflictException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class ClassesService {
  constructor(private prisma: PrismaService) {}

  async findAll(anoLetivo?: number) {
    return this.prisma.class.findMany({
      where: { anoLetivo: anoLetivo || new Date().getFullYear(), ativo: true },
      include: {
        _count: { select: { students: true, classSubjects: true } },
        classSubjects: {
          include: {
            subject: true,
            teacher: { include: { user: { select: { nome: true, apelido: true } } } },
          },
        },
      },
      orderBy: { nome: 'asc' },
    });
  }

  async findOne(id: string) {
    const turma = await this.prisma.class.findUnique({
      where: { id },
      include: {
        students: {
          include: {
            user: { select: { nome: true, apelido: true, email: true, fotoUrl: true } },
          },
        },
        classSubjects: {
          include: {
            subject: true,
            teacher: { include: { user: { select: { nome: true, apelido: true } } } },
          },
        },
        schedules: { include: { subject: true }, orderBy: [{ diaSemana: 'asc' }, { horaInicio: 'asc' }] },
      },
    });
    if (!turma) throw new NotFoundException('Turma não encontrada');
    return turma;
  }

  async create(dto: any) {
    const exists = await this.prisma.class.findFirst({
      where: { nome: dto.nome, anoLetivo: dto.anoLetivo, turno: dto.turno },
    });
    if (exists) throw new ConflictException('Turma já existe com este nome, ano e turno');
    return this.prisma.class.create({ data: dto });
  }

  async update(id: string, dto: any) {
    await this.findOne(id);
    return this.prisma.class.update({ where: { id }, data: dto });
  }

  async assignSubject(classId: string, dto: { subjectId: string; teacherId: string; anoLetivo: number }) {
    return this.prisma.classSubject.upsert({
      where: { classId_subjectId_anoLetivo: { classId, subjectId: dto.subjectId, anoLetivo: dto.anoLetivo } },
      update: { teacherId: dto.teacherId },
      create: { classId, ...dto },
    });
  }

  async createSchedule(classId: string, dto: any) {
    return this.prisma.schedule.create({ data: { classId, ...dto } });
  }

  async getSchedule(classId: string) {
    return this.prisma.schedule.findMany({
      where: { classId },
      include: { subject: true },
      orderBy: [{ diaSemana: 'asc' }, { horaInicio: 'asc' }],
    });
  }

  async getStatsByClass(classId: string) {
    const [students, grades, attendances] = await Promise.all([
      this.prisma.student.count({ where: { turmaId: classId } }),
      this.prisma.grade.findMany({ where: { classSubject: { classId } } }),
      this.prisma.attendance.findMany({ where: { classSubject: { classId } } }),
    ]);

    const mediaGeral = grades.length
      ? (grades.reduce((a, g) => a + (g.notaFinal || 0), 0) / grades.length).toFixed(1)
      : '0';

    const totalPresencas = attendances.length;
    const faltas = attendances.filter(a => a.status === 'ABSENT').length;
    const taxaPresenca = totalPresencas > 0 ? (((totalPresencas - faltas) / totalPresencas) * 100).toFixed(1) : '100';

    return { totalAlunos: students, mediaGeral, taxaPresenca };
  }
}