import { Controller, Get, Post, Body, Param, Query, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { GradesService } from './grades.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { Role } from '@prisma/client';

@ApiTags('grades')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('grades')
export class GradesController {
  constructor(private gradesService: GradesService) {}

  @Get('class/:classId')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY, Role.TEACHER)
  findByClass(
    @Param('classId') classId: string,
    @Query('subjectId') subjectId?: string,
    @Query('trimestre') trimestre?: number,
    @Query('anoLetivo') anoLetivo?: number,
  ) {
    return this.gradesService.findByClass(classId, subjectId, trimestre, anoLetivo);
  }

  @Get('boletim/:studentId')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY, Role.TEACHER, Role.STUDENT)
  getBoletim(@Param('studentId') studentId: string, @Query('anoLetivo') anoLetivo?: number) {
    return this.gradesService.getBoletim(studentId, anoLetivo);
  }

  @Post()
  @Roles(Role.TEACHER, Role.ADMIN, Role.SECRETARY)
  @ApiOperation({ summary: 'Lançar/Atualizar nota de um aluno' })
  async upsert(@Body() dto: any, @Request() req: any) {
    if (req.user.role === Role.TEACHER) {
      await this.gradesService.validateTeacherOwnership(dto.classSubjectId, req.user.sub);
    }
    return this.gradesService.upsert({ ...dto, teacherId: req.user.sub });
  }

  @Post('bulk')
  @Roles(Role.TEACHER, Role.ADMIN, Role.SECRETARY)
  @ApiOperation({ summary: 'Lançar notas em massa (pauta completa)' })
  async upsertBulk(@Body() body: { grades: any[] }, @Request() req: any) {
    return this.gradesService.upsertBulk(body.grades, req.user.sub);
  }
}