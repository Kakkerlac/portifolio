import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class GradesService {
  constructor(private prisma: PrismaService) {}

  // Fórmula angolana: MAC(40%) + NEP(40%) + NPP(20%)
  private calcularNotaFinal(mac?: number, nep?: number, npp?: number): number | null {
    if (mac === undefined || nep === undefined || npp === undefined) return null;
    return parseFloat((mac * 0.4 + nep * 0.4 + npp * 0.2).toFixed(2));
  }

  async findByClass(classId: string, subjectId?: string, trimestre?: number, anoLetivo?: number) {
    return this.prisma.grade.findMany({
      where: {
        classSubject: { classId, subjectId },
        trimestre,
        anoLetivo: anoLetivo || new Date().getFullYear(),
      },
      include: {
        student: { include: { user: { select: { nome: true, apelido: true, fotoUrl: true } } } },
        classSubject: { include: { subject: true } },
      },
      orderBy: [{ student: { user: { nome: 'asc' } } }],
    });
  }

  async upsert(dto: {
    studentId: string;
    classSubjectId: string;
    teacherId: string;
    trimestre: number;
    anoLetivo: number;
    mac?: number;
    nep?: number;
    npp?: number;
    observacoes?: string;
  }) {
    const notaFinal = this.calcularNotaFinal(dto.mac, dto.nep, dto.npp);
    const aprovado = notaFinal !== null ? notaFinal >= 10 : null;

    return this.prisma.grade.upsert({
      where: {
        studentId_classSubjectId_trimestre_anoLetivo: {
          studentId: dto.studentId,
          classSubjectId: dto.classSubjectId,
          trimestre: dto.trimestre,
          anoLetivo: dto.anoLetivo,
        },
      },
      update: { ...dto, notaFinal, aprovado },
      create: { ...dto, notaFinal, aprovado },
    });
  }

  async upsertBulk(grades: any[], teacherId: string) {
    return Promise.all(grades.map(g => this.upsert({ ...g, teacherId })));
  }

  async getBoletim(studentId: string, anoLetivo?: number) {
    const ano = anoLetivo || new Date().getFullYear();
    const grades = await this.prisma.grade.findMany({
      where: { studentId, anoLetivo: ano },
      include: { classSubject: { include: { subject: true } } },
      orderBy: [{ classSubject: { subject: { nome: 'asc' } } }, { trimestre: 'asc' }],
    });

    // Agrupar por disciplina
    const bySubject: Record<string, any> = {};
    for (const g of grades) {
      const key = g.classSubject.subject.nome;
      if (!bySubject[key]) bySubject[key] = { subject: g.classSubject.subject, trimestres: {} };
      bySubject[key].trimestres[`t${g.trimestre}`] = {
        mac: g.mac, nep: g.nep, npp: g.npp, notaFinal: g.notaFinal, aprovado: g.aprovado,
      };
    }

    return Object.values(bySubject);
  }

  async validateTeacherOwnership(classSubjectId: string, teacherId: string) {
    const cs = await this.prisma.classSubject.findUnique({ where: { id: classSubjectId } });
    if (!cs || cs.teacherId !== teacherId) {
      throw new ForbiddenException('Não tem permissão para lançar notas nesta disciplina');
    }
  }
}