// ============================================================
// guards/jwt-auth.guard.ts
// ============================================================
import { Injectable, ExecutionContext } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { Reflector } from '@nestjs/core';
import { IS_PUBLIC_KEY } from '../decorators/public.decorator';

@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {
  constructor(private reflector: Reflector) {
    super();
  }

  canActivate(context: ExecutionContext) {
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (isPublic) return true;
    return super.canActivate(context);
  }
}

// ============================================================
// guards/local-auth.guard.ts
// ============================================================
export { } // placeholder - see below

import { Injectable as InjectableLocal } from '@nestjs/common';
import { AuthGuard as AuthGuardLocal } from '@nestjs/passport';

@InjectableLocal()
export class LocalAuthGuard extends AuthGuardLocal('local') {}

// ============================================================
// guards/jwt-refresh.guard.ts
// ============================================================
import { Injectable as InjectableRefresh } from '@nestjs/common';
import { AuthGuard as AuthGuardRefresh } from '@nestjs/passport';

@InjectableRefresh()
export class JwtRefreshGuard extends AuthGuardRefresh('jwt-refresh') {}

// ============================================================
// guards/roles.guard.ts
// ============================================================
import { Injectable as InjectableRoles, CanActivate, ExecutionContext as ExecCtx } from '@nestjs/common';
import { Reflector as ReflectorRoles } from '@nestjs/core';
import { ROLES_KEY } from '../decorators/roles.decorator';
import { Role } from '@prisma/client';

@InjectableRoles()
export class RolesGuard implements CanActivate {
  constructor(private reflector: ReflectorRoles) {}

  canActivate(context: ExecCtx): boolean {
    const requiredRoles = this.reflector.getAllAndOverride<Role[]>(ROLES_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);

    if (!requiredRoles || requiredRoles.length === 0) return true;

    const { user } = context.switchToHttp().getRequest();
    return requiredRoles.some((role) => user?.role === role);
  }
}

// ============================================================
// guards/owner-or-roles.guard.ts
// ============================================================
// Permite acesso se é o próprio utilizador OU tem o papel certo
import { Injectable as InjectableOwner, CanActivate as CanActivateOwner, ExecutionContext as ExecCtxOwner } from '@nestjs/common';

@InjectableOwner()
export class OwnerOrRolesGuard implements CanActivateOwner {
  canActivate(context: ExecCtxOwner): boolean {
    const req = context.switchToHttp().getRequest();
    const user = req.user;
    const targetId = req.params.id || req.params.userId;

    // Admin e DIRECTOR têm sempre acesso
    if (['ADMIN', 'DIRECTOR', 'SECRETARY'].includes(user?.role)) return true;

    // O próprio utilizador pode aceder aos seus dados
    if (user?.sub === targetId) return true;

    return false;
  }
}
