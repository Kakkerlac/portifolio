import {
  Injectable,
  UnauthorizedException,
  BadRequestException,
  ForbiddenException,
  Logger,
  NotFoundException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../prisma/prisma.service';
import * as bcrypt from 'bcrypt';
import { v4 as uuidv4 } from 'uuid';
import { LoginDto } from './dto/login.dto';
import { ChangePasswordDto } from './dto/change-password.dto';

export interface JwtPayload {
  sub: string;
  email: string;
  role: string;
  numero: string;
}

export interface TokenPair {
  accessToken: string;
  refreshToken: string;
}

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);
  private readonly MAX_ATTEMPTS: number;
  private readonly BLOCK_MINUTES: number;

  constructor(
    private prisma: PrismaService,
    private jwtService: JwtService,
    private config: ConfigService,
  ) {
    this.MAX_ATTEMPTS = this.config.get<number>('MAX_LOGIN_ATTEMPTS', 5);
    this.BLOCK_MINUTES = this.config.get<number>('BLOCK_DURATION_MINUTES', 30);
  }

  async validateUser(email: string, password: string) {
    const user = await this.prisma.user.findUnique({ where: { email } });

    if (!user) {
      throw new UnauthorizedException('Credenciais inválidas');
    }

    if (!user.ativo) {
      throw new ForbiddenException('Conta desativada. Contacte a secretaria.');
    }

    if (user.bloqueado) {
      throw new ForbiddenException(
        `Conta bloqueada: ${user.motivoBloqueio || 'Contacte a secretaria.'}`,
      );
    }

    const valid = await bcrypt.compare(password, user.passwordHash);

    if (!valid) {
      await this.handleFailedLogin(user.id, user.loginAttempts);
      throw new UnauthorizedException('Credenciais inválidas');
    }

    // Reset login attempts on success
    await this.prisma.user.update({
      where: { id: user.id },
      data: { loginAttempts: 0, lastLoginAt: new Date() },
    });

    return user;
  }

  async login(user: any, ip?: string): Promise<TokenPair & { user: any }> {
    const payload: JwtPayload = {
      sub: user.id,
      email: user.email,
      role: user.role,
      numero: user.numero,
    };

    const [accessToken, refreshToken] = await Promise.all([
      this.jwtService.signAsync(payload),
      this.generateRefreshToken(user.id),
    ]);

    // Log audit
    await this.prisma.auditLog.create({
      data: {
        userId: user.id,
        acao: 'LOGIN',
        entidade: 'User',
        entidadeId: user.id,
        ipAddress: ip,
        sucesso: true,
      },
    });

    const { passwordHash, ...safeUser } = user;
    return { accessToken, refreshToken, user: safeUser };
  }

  async refreshTokens(userId: string, token: string): Promise<TokenPair> {
    const stored = await this.prisma.refreshToken.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!stored || stored.userId !== userId || stored.revoked || stored.expiresAt < new Date()) {
      throw new UnauthorizedException('Refresh token inválido ou expirado');
    }

    // Rotate token
    await this.prisma.refreshToken.update({ where: { token }, data: { revoked: true } });

    const payload: JwtPayload = {
      sub: stored.user.id,
      email: stored.user.email,
      role: stored.user.role,
      numero: stored.user.numero,
    };

    const [accessToken, newRefreshToken] = await Promise.all([
      this.jwtService.signAsync(payload),
      this.generateRefreshToken(userId),
    ]);

    return { accessToken, refreshToken: newRefreshToken };
  }

  async logout(userId: string, token?: string): Promise<void> {
    if (token) {
      await this.prisma.refreshToken.updateMany({
        where: { userId, token },
        data: { revoked: true },
      });
    } else {
      // Revogar todos os tokens do utilizador
      await this.prisma.refreshToken.updateMany({
        where: { userId },
        data: { revoked: true },
      });
    }

    await this.prisma.auditLog.create({
      data: {
        userId,
        acao: 'LOGOUT',
        entidade: 'User',
        entidadeId: userId,
        sucesso: true,
      },
    });
  }

  async changePassword(userId: string, dto: ChangePasswordDto): Promise<void> {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user) throw new NotFoundException('Utilizador não encontrado');

    const valid = await bcrypt.compare(dto.senhaAtual, user.passwordHash);
    if (!valid) throw new BadRequestException('Senha atual incorreta');

    if (dto.novaSenha !== dto.confirmarSenha) {
      throw new BadRequestException('As senhas não coincidem');
    }

    const hash = await bcrypt.hash(dto.novaSenha, 12);
    await this.prisma.user.update({
      where: { id: userId },
      data: { passwordHash: hash },
    });

    // Revogar todos refresh tokens por segurança
    await this.prisma.refreshToken.updateMany({
      where: { userId },
      data: { revoked: true },
    });
  }

  async requestPasswordReset(email: string): Promise<void> {
    const user = await this.prisma.user.findUnique({ where: { email } });
    if (!user) return; // Não revelar se email existe

    const token = uuidv4();
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000); // 1 hora

    await this.prisma.passwordReset.create({
      data: { email, token, expiresAt },
    });

    // TODO: Enviar email com link de reset
    this.logger.log(`Password reset token para ${email}: ${token}`);
  }

  async resetPassword(token: string, novaSenha: string): Promise<void> {
    const reset = await this.prisma.passwordReset.findUnique({ where: { token } });

    if (!reset || reset.used || reset.expiresAt < new Date()) {
      throw new BadRequestException('Token inválido ou expirado');
    }

    const hash = await bcrypt.hash(novaSenha, 12);

    await this.prisma.user.update({
      where: { email: reset.email },
      data: { passwordHash: hash, loginAttempts: 0, bloqueado: false },
    });

    await this.prisma.passwordReset.update({
      where: { token },
      data: { used: true },
    });
  }

  async getProfile(userId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        numero: true,
        email: true,
        role: true,
        nome: true,
        apelido: true,
        telefone: true,
        fotoUrl: true,
        genero: true,
        dataNascimento: true,
        ativo: true,
        lastLoginAt: true,
        createdAt: true,
        student: { select: { id: true, turmaId: true, numeroMatricula: true, statusPagamento: true } },
        teacher: { select: { id: true, especialidade: true, cargaHoraria: true } },
      },
    });
    if (!user) throw new NotFoundException('Utilizador não encontrado');
    return user;
  }

  private async generateRefreshToken(userId: string): Promise<string> {
    const token = uuidv4();
    const days = this.config.get<number>('JWT_REFRESH_DAYS', 7);
    const expiresAt = new Date(Date.now() + days * 24 * 60 * 60 * 1000);

    await this.prisma.refreshToken.create({
      data: { token, userId, expiresAt },
    });

    return token;
  }

  private async handleFailedLogin(userId: string, currentAttempts: number): Promise<void> {
    const newAttempts = currentAttempts + 1;

    if (newAttempts >= this.MAX_ATTEMPTS) {
      await this.prisma.user.update({
        where: { id: userId },
        data: {
          loginAttempts: newAttempts,
          bloqueado: true,
          motivoBloqueio: `Demasiadas tentativas de login (${newAttempts} tentativas)`,
        },
      });
      this.logger.warn(`Utilizador ${userId} bloqueado por excesso de tentativas de login`);
    } else {
      await this.prisma.user.update({
        where: { id: userId },
        data: { loginAttempts: newAttempts },
      });
    }
  }
}