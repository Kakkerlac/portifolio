import { Controller, Get, Post, Put, Patch, Body, Param, Query, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AdminService } from './admin.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { Role } from '@prisma/client';

@ApiTags('admin')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles(Role.ADMIN)
@Controller('admin')
export class AdminController {
  constructor(private adminService: AdminService) {}

  // ─── STATS ───────────────────────────────────────────────

  @Get('stats')
  @ApiOperation({ summary: 'Estatísticas gerais do sistema' })
  getSystemStats() {
    return this.adminService.getSystemStats();
  }

  // ─── CONFIGURAÇÕES ───────────────────────────────────────

  @Get('config')
  @ApiOperation({ summary: 'Listar todas as configurações' })
  findAllConfigs(@Query('categoria') categoria?: string) {
    return this.adminService.findAllConfigs(categoria);
  }

  @Get('config/:chave')
  getConfig(@Param('chave') chave: string) {
    return this.adminService.getConfig(chave);
  }

  @Put('config/:chave')
  updateConfig(@Param('chave') chave: string, @Body() body: { valor: string }, @Request() req: any) {
    return this.adminService.updateConfig(chave, body.valor, req.user.sub);
  }

  @Put('config')
  @ApiOperation({ summary: 'Atualizar múltiplas configurações de uma vez' })
  updateConfigsBulk(@Body() body: { configs: { chave: string; valor: string }[] }, @Request() req: any) {
    return this.adminService.updateConfigsBulk(body.configs, req.user.sub);
  }

  // ─── AUDIT LOGS ──────────────────────────────────────────

  @Get('audit-logs')
  @ApiOperation({ summary: 'Logs de auditoria do sistema' })
  findAuditLogs(
    @Query('userId') userId?: string,
    @Query('acao') acao?: string,
    @Query('entidade') entidade?: string,
    @Query('startDate') startDate?: string,
    @Query('endDate') endDate?: string,
    @Query('page') page?: number,
    @Query('limit') limit?: number,
  ) {
    return this.adminService.findAuditLogs({
      userId, acao, entidade,
      startDate: startDate ? new Date(startDate) : undefined,
      endDate: endDate ? new Date(endDate) : undefined,
      page, limit,
    });
  }

  // ─── UTILIZADORES BLOQUEADOS ─────────────────────────────

  @Get('blocked-users')
  @ApiOperation({ summary: 'Utilizadores bloqueados' })
  getBlockedUsers() {
    return this.adminService.getBlockedUsers();
  }

  @Patch('users/:id/reset-attempts')
  @ApiOperation({ summary: 'Desbloquear utilizador e resetar tentativas de login' })
  resetAttempts(@Param('id') id: string) {
    return this.adminService.resetLoginAttempts(id);
  }

  // ─── ANOS LETIVOS ────────────────────────────────────────

  @Get('academic-years')
  findAcademicYears() {
    return this.adminService.findAcademicYears();
  }

  @Post('academic-years')
  @ApiOperation({ summary: 'Criar novo ano letivo (ativa automaticamente)' })
  createAcademicYear(@Body() dto: any) {
    return this.adminService.createAcademicYear(dto);
  }

  @Patch('academic-years/:id/activate')
  @ApiOperation({ summary: 'Ativar um ano letivo' })
  activateAcademicYear(@Param('id') id: string) {
    return this.adminService.setActiveAcademicYear(id);
  }
}