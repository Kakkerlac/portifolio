import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class AdminService {
  constructor(private prisma: PrismaService) {}

  // ─── CONFIGURAÇÕES DO SISTEMA ────────────────────────────

  async findAllConfigs(categoria?: string) {
    return this.prisma.systemConfig.findMany({
      where: categoria ? { categoria } : undefined,
      orderBy: [{ categoria: 'asc' }, { chave: 'asc' }],
    });
  }

  async getConfig(chave: string) {
    const config = await this.prisma.systemConfig.findUnique({ where: { chave } });
    if (!config) throw new NotFoundException(`Configuração '${chave}' não encontrada`);
    return config;
  }

  async updateConfig(chave: string, valor: string, userId: string) {
    return this.prisma.systemConfig.upsert({
      where: { chave },
      update: { valor, atualizadoPor: userId, atualizadoEm: new Date() },
      create: { chave, valor, atualizadoPor: userId },
    });
  }

  async updateConfigsBulk(configs: { chave: string; valor: string }[], userId: string) {
    return Promise.all(configs.map(c => this.updateConfig(c.chave, c.valor, userId)));
  }

  // ─── LOGS DE AUDITORIA ───────────────────────────────────

  async findAuditLogs(filters?: {
    userId?: string;
    acao?: string;
    entidade?: string;
    startDate?: Date;
    endDate?: Date;
    page?: number;
    limit?: number;
  }) {
    const page = filters?.page || 1;
    const limit = filters?.limit || 50;
    const skip = (page - 1) * limit;

    const where: any = {};
    if (filters?.userId) where.userId = filters.userId;
    if (filters?.acao) where.acao = { contains: filters.acao, mode: 'insensitive' };
    if (filters?.entidade) where.entidade = filters.entidade;
    if (filters?.startDate || filters?.endDate) {
      where.createdAt = {};
      if (filters.startDate) where.createdAt.gte = filters.startDate;
      if (filters.endDate) where.createdAt.lte = filters.endDate;
    }

    const [logs, total] = await Promise.all([
      this.prisma.auditLog.findMany({
        where,
        include: { user: { select: { nome: true, apelido: true, role: true } } },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      this.prisma.auditLog.count({ where }),
    ]);

    return { logs, total, page, totalPages: Math.ceil(total / limit) };
  }

  async createAuditLog(dto: {
    userId?: string;
    acao: string;
    entidade: string;
    entidadeId?: string;
    dadosAntes?: any;
    dadosDepois?: any;
    ipAddress?: string;
    sucesso?: boolean;
    erro?: string;
  }) {
    return this.prisma.auditLog.create({ data: dto });
  }

  // ─── GESTÃO DE UTILIZADORES (ADMIN) ─────────────────────

  async getSystemStats() {
    const [users, students, teachers, classes, payments, totalTransactions] = await Promise.all([
      this.prisma.user.groupBy({ by: ['role'], _count: { id: true } }),
      this.prisma.student.count(),
      this.prisma.teacher.count(),
      this.prisma.class.count({ where: { ativo: true } }),
      this.prisma.payment.count(),
      this.prisma.transaction.aggregate({ _sum: { valor: true } }),
    ]);

    return {
      utilizadores: Object.fromEntries(users.map(u => [u.role, u._count.id])),
      totalAlunos: students,
      totalProfessores: teachers,
      totalTurmas: classes,
      totalPagamentos: payments,
      volumeTransacoes: totalTransactions._sum.valor || 0,
    };
  }

  async getBlockedUsers() {
    return this.prisma.user.findMany({
      where: { bloqueado: true },
      select: {
        id: true, nome: true, apelido: true, email: true, role: true,
        motivoBloqueio: true, lastLoginAt: true,
        student: { select: { statusPagamento: true, diasAtraso: true } },
      },
      orderBy: { updatedAt: 'desc' },
    });
  }

  async resetLoginAttempts(userId: string) {
    return this.prisma.user.update({
      where: { id: userId },
      data: { loginAttempts: 0, bloqueado: false, motivoBloqueio: null },
    });
  }

  async findAcademicYears() {
    return this.prisma.academicYear.findMany({ orderBy: { ano: 'desc' } });
  }

  async createAcademicYear(dto: { ano: number; dataInicio: Date; dataFim: Date }) {
    // Desativar anos anteriores
    await this.prisma.academicYear.updateMany({ data: { ativo: false } });
    return this.prisma.academicYear.create({ data: { ...dto, ativo: true } });
  }

  async setActiveAcademicYear(id: string) {
    await this.prisma.academicYear.updateMany({ data: { ativo: false } });
    await this.prisma.systemConfig.update({
      where: { chave: 'ano_letivo_atual' },
      data: { valor: String((await this.prisma.academicYear.findUnique({ where: { id } }))?.ano) },
    });
    return this.prisma.academicYear.update({ where: { id }, data: { ativo: true } });
  }
}