import { Injectable, NotFoundException, ConflictException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { LeaveStatus, PaymentMethod } from '@prisma/client';

@Injectable()
export class HrService {
  constructor(private prisma: PrismaService) {}

  // ─── SALÁRIOS ────────────────────────────────────────────

  async findSalaries(filters?: { teacherId?: string; anoLetivo?: number; mes?: number; pago?: boolean }) {
    return this.prisma.salary.findMany({
      where: {
        teacherId: filters?.teacherId,
        anoLetivo: filters?.anoLetivo || new Date().getFullYear(),
        mes: filters?.mes,
        pago: filters?.pago,
      },
      include: {
        teacher: {
          include: { user: { select: { nome: true, apelido: true, email: true, fotoUrl: true } } },
        },
      },
      orderBy: [{ anoLetivo: 'desc' }, { mes: 'desc' }],
    });
  }

  async generateMonthlySalaries(anoLetivo: number, mes: number) {
    const teachers = await this.prisma.teacher.findMany({
      where: { user: { ativo: true } },
      include: { user: true },
    });

    const existing = await this.prisma.salary.findMany({
      where: { anoLetivo, mes },
      select: { teacherId: true },
    });
    const existingIds = new Set(existing.map(s => s.teacherId));

    const toCreate = teachers
      .filter(t => !existingIds.has(t.id) && t.salarioBase)
      .map(t => {
        const salarioBase = t.salarioBase!;
        const impostos = salarioBase * 0.11; // IRT 11%
        const salarioLiquido = salarioBase + 0 - impostos;
        return {
          teacherId: t.id,
          anoLetivo,
          mes,
          salarioBase,
          subsidios: 0,
          descontos: 0,
          impostos: parseFloat(impostos.toFixed(2)),
          salarioLiquido: parseFloat(salarioLiquido.toFixed(2)),
        };
      });

    if (toCreate.length === 0) {
      throw new ConflictException('Salários já gerados para este mês ou não há professores com salário base definido');
    }

    await this.prisma.salary.createMany({ data: toCreate });
    return { gerados: toCreate.length, mes, anoLetivo };
  }

  async processSalaryPayment(salaryId: string, dto: { metodo: PaymentMethod; comprovativo?: string; notas?: string }) {
    const salary = await this.prisma.salary.findUnique({ where: { id: salaryId } });
    if (!salary) throw new NotFoundException('Salário não encontrado');
    if (salary.pago) throw new ConflictException('Salário já processado');

    return this.prisma.salary.update({
      where: { id: salaryId },
      data: {
        pago: true,
        dataPagamento: new Date(),
        metodoPagamento: dto.metodo,
        comprovativo: dto.comprovativo,
        notas: dto.notas,
      },
    });
  }

  async updateSalary(id: string, dto: any) {
    const salary = await this.prisma.salary.findUnique({ where: { id } });
    if (!salary) throw new NotFoundException('Salário não encontrado');

    const salarioLiquido = dto.salarioBase + (dto.subsidios || 0) - (dto.descontos || 0) - (dto.impostos || 0);
    return this.prisma.salary.update({
      where: { id },
      data: { ...dto, salarioLiquido: parseFloat(salarioLiquido.toFixed(2)) },
    });
  }

  async getSalaryDashboard(anoLetivo?: number) {
    const ano = anoLetivo || new Date().getFullYear();
    const [totalPago, totalPendente, totalProfessores] = await Promise.all([
      this.prisma.salary.aggregate({ where: { anoLetivo: ano, pago: true }, _sum: { salarioLiquido: true } }),
      this.prisma.salary.aggregate({ where: { anoLetivo: ano, pago: false }, _sum: { salarioLiquido: true } }),
      this.prisma.teacher.count({ where: { user: { ativo: true } } }),
    ]);

    const porMes = await this.prisma.salary.groupBy({
      by: ['mes'],
      where: { anoLetivo: ano },
      _sum: { salarioLiquido: true },
      _count: { id: true },
      orderBy: { mes: 'asc' },
    });

    return {
      totalPago: totalPago._sum.salarioLiquido || 0,
      totalPendente: totalPendente._sum.salarioLiquido || 0,
      totalProfessores,
      porMes: porMes.map(m => ({
        mes: m.mes,
        total: m._sum.salarioLiquido || 0,
        count: m._count.id,
      })),
    };
  }

  // ─── LICENÇAS / FALTAS ───────────────────────────────────

  async findLeaves(filters?: { teacherId?: string; status?: LeaveStatus; anoLetivo?: number }) {
    return this.prisma.leave.findMany({
      where: {
        teacherId: filters?.teacherId,
        status: filters?.status,
        dataInicio: filters?.anoLetivo
          ? { gte: new Date(filters.anoLetivo, 0, 1) }
          : undefined,
      },
      include: {
        teacher: {
          include: { user: { select: { nome: true, apelido: true, fotoUrl: true } } },
        },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async requestLeave(dto: any, teacherId: string) {
    const dataInicio = new Date(dto.dataInicio);
    const dataFim = new Date(dto.dataFim);
    const dias = Math.ceil((dataFim.getTime() - dataInicio.getTime()) / 86400000) + 1;

    return this.prisma.leave.create({
      data: { ...dto, teacherId, dias, status: LeaveStatus.PENDING },
    });
  }

  async processLeave(id: string, status: LeaveStatus, aprovadoPor: string) {
    const leave = await this.prisma.leave.findUnique({ where: { id } });
    if (!leave) throw new NotFoundException('Licença não encontrada');

    return this.prisma.leave.update({
      where: { id },
      data: { status, aprovadoPor, dataAprovacao: new Date() },
    });
  }

  // ─── RELATÓRIO RH ────────────────────────────────────────

  async getHrDashboard() {
    const [totalTeachers, totalActive, totalLeavesPending, salariesThisMonth] = await Promise.all([
      this.prisma.teacher.count(),
      this.prisma.teacher.count({ where: { user: { ativo: true } } }),
      this.prisma.leave.count({ where: { status: LeaveStatus.PENDING } }),
      this.prisma.salary.aggregate({
        where: {
          anoLetivo: new Date().getFullYear(),
          mes: new Date().getMonth() + 1,
        },
        _sum: { salarioLiquido: true },
        _count: { id: true },
      }),
    ]);

    return {
      totalTeachers,
      totalActive,
      totalInactive: totalTeachers - totalActive,
      totalLeavesPending,
      salariosMesAtual: {
        total: salariesThisMonth._sum.salarioLiquido || 0,
        count: salariesThisMonth._count.id,
      },
    };
  }
}