import { Controller, Get, Post, Put, Patch, Body, Param, Query, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { HrService } from './hr.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { LeaveStatus, Role } from '@prisma/client';

@ApiTags('hr')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('hr')
export class HrController {
  constructor(private hrService: HrService) {}

  @Get('dashboard')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY)
  getDashboard() {
    return this.hrService.getHrDashboard();
  }

  // ─── SALÁRIOS ────────────────────────────────────────────

  @Get('salaries')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY)
  findSalaries(
    @Query('teacherId') teacherId?: string,
    @Query('anoLetivo') anoLetivo?: number,
    @Query('mes') mes?: number,
    @Query('pago') pago?: boolean,
  ) {
    return this.hrService.findSalaries({ teacherId, anoLetivo, mes, pago });
  }

  @Get('salaries/dashboard')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY)
  getSalaryDashboard(@Query('anoLetivo') anoLetivo?: number) {
    return this.hrService.getSalaryDashboard(anoLetivo);
  }

  @Post('salaries/generate')
  @Roles(Role.ADMIN, Role.SECRETARY)
  @ApiOperation({ summary: 'Gerar folha de salários para um mês' })
  generateSalaries(@Body() body: { anoLetivo: number; mes: number }) {
    return this.hrService.generateMonthlySalaries(body.anoLetivo, body.mes);
  }

  @Put('salaries/:id')
  @Roles(Role.ADMIN, Role.SECRETARY)
  updateSalary(@Param('id') id: string, @Body() dto: any) {
    return this.hrService.updateSalary(id, dto);
  }

  @Patch('salaries/:id/pay')
  @Roles(Role.ADMIN, Role.SECRETARY)
  @ApiOperation({ summary: 'Marcar salário como pago' })
  processSalary(@Param('id') id: string, @Body() dto: any) {
    return this.hrService.processSalaryPayment(id, dto);
  }

  // ─── LICENÇAS ────────────────────────────────────────────

  @Get('leaves')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY)
  findLeaves(
    @Query('teacherId') teacherId?: string,
    @Query('status') status?: LeaveStatus,
    @Query('anoLetivo') anoLetivo?: number,
  ) {
    return this.hrService.findLeaves({ teacherId, status, anoLetivo });
  }

  @Post('leaves')
  @Roles(Role.TEACHER, Role.ADMIN)
  @ApiOperation({ summary: 'Solicitar licença/férias' })
  requestLeave(@Body() dto: any, @Request() req: any) {
    // Teacher pede pelo userId, admin especifica teacherId no body
    const teacherId = req.user.role === Role.TEACHER ? req.user.sub : dto.teacherId;
    return this.hrService.requestLeave(dto, teacherId);
  }

  @Patch('leaves/:id/approve')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY)
  approveLeave(@Param('id') id: string, @Request() req: any) {
    return this.hrService.processLeave(id, LeaveStatus.APPROVED, req.user.sub);
  }

  @Patch('leaves/:id/reject')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY)
  rejectLeave(@Param('id') id: string, @Request() req: any) {
    return this.hrService.processLeave(id, LeaveStatus.REJECTED, req.user.sub);
  }
}