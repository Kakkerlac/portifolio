import { Controller, Get, Post, Delete, Body, Param, Query, UseGuards, Request, UseInterceptors, UploadedFile } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiConsumes } from '@nestjs/swagger';
import { MaterialsService } from './materials.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { Role } from '@prisma/client';

@ApiTags('materials')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('materials')
export class MaterialsController {
  constructor(private materialsService: MaterialsService) {}

  @Get()
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY)
  findAll(@Query('anoLetivo') anoLetivo?: number) {
    return this.materialsService.findAll(anoLetivo);
  }

  @Get('class-subject/:id')
  @ApiOperation({ summary: 'Materiais de uma disciplina-turma' })
  findByClassSubject(@Param('id') id: string) {
    return this.materialsService.findByClassSubject(id);
  }

  @Get('student/:studentId')
  @Roles(Role.STUDENT, Role.ADMIN, Role.SECRETARY)
  findByStudent(@Param('studentId') studentId: string) {
    return this.materialsService.findByStudent(studentId);
  }

  @Post()
  @Roles(Role.TEACHER, Role.ADMIN)
  @UseInterceptors(FileInterceptor('file'))
  @ApiConsumes('multipart/form-data')
  @ApiOperation({ summary: 'Enviar material (ficheiro ou link)' })
  create(
    @Body() dto: any,
    @Request() req: any,
    @UploadedFile() file?: Express.Multer.File,
  ) {
    const fileUrl = file ? `/uploads/materials/${file.filename}` : undefined;
    return this.materialsService.create(dto, req.user.sub, fileUrl);
  }

  @Delete(':id')
  @Roles(Role.TEACHER, Role.ADMIN)
  delete(@Param('id') id: string, @Request() req: any) {
    const isAdmin = req.user.role === Role.ADMIN;
    return this.materialsService.delete(id, req.user.sub, isAdmin);
  }
}