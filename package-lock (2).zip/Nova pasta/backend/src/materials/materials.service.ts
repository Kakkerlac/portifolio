import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class MaterialsService {
  constructor(private prisma: PrismaService) {}

  async findByClassSubject(classSubjectId: string) {
    return this.prisma.material.findMany({
      where: { classSubjectId },
      include: {
        teacher: { include: { user: { select: { nome: true, apelido: true } } } },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async findByStudent(studentId: string) {
    const student = await this.prisma.student.findUnique({
      where: { id: studentId },
      select: { turmaId: true },
    });
    if (!student) throw new NotFoundException('Estudante não encontrado');

    return this.prisma.material.findMany({
      where: {
        publico: true,
        classSubject: { classId: student.turmaId },
        anoLetivo: new Date().getFullYear(),
      },
      include: {
        classSubject: { include: { subject: true } },
        teacher: { include: { user: { select: { nome: true, apelido: true } } } },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async create(dto: any, teacherId: string, fileUrl?: string) {
    return this.prisma.material.create({
      data: {
        ...dto,
        teacherId,
        url: fileUrl || dto.url,
        anoLetivo: dto.anoLetivo || new Date().getFullYear(),
      },
    });
  }

  async delete(id: string, teacherId: string, isAdmin: boolean) {
    const material = await this.prisma.material.findUnique({ where: { id } });
    if (!material) throw new NotFoundException('Material não encontrado');
    if (!isAdmin && material.teacherId !== teacherId) {
      throw new ForbiddenException('Sem permissão para eliminar este material');
    }
    return this.prisma.material.delete({ where: { id } });
  }

  async findAll(anoLetivo?: number) {
    return this.prisma.material.findMany({
      where: { anoLetivo: anoLetivo || new Date().getFullYear() },
      include: {
        classSubject: { include: { class: true, subject: true } },
        teacher: { include: { user: { select: { nome: true, apelido: true } } } },
      },
      orderBy: { createdAt: 'desc' },
    });
  }
}