import { Controller, Get } from '@nestjs/common';

@Controller('roles')
export class RolesController {
  @Get()
  getRolesBase() {
    return { module: 'roles ready' };
  }
}