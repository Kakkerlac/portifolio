import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { TransactionType, TransactionCategory } from '@prisma/client';

@Injectable()
export class FinancialService {
  constructor(private prisma: PrismaService) {}

  // ─── CONTAS ──────────────────────────────────────────────

  async findAllAccounts() {
    const accounts = await this.prisma.account.findMany({ where: { ativo: true } });
    const totalSaldo = accounts.reduce((a, c) => a + c.saldo, 0);
    return { accounts, totalSaldo };
  }

  async createAccount(dto: any) {
    return this.prisma.account.create({ data: dto });
  }

  // ─── TRANSAÇÕES ──────────────────────────────────────────

  async findTransactions(filters?: {
    accountId?: string;
    tipo?: TransactionType;
    categoria?: TransactionCategory;
    mes?: number;
    anoLetivo?: number;
  }) {
    const ano = filters?.anoLetivo || new Date().getFullYear();
    return this.prisma.transaction.findMany({
      where: {
        accountId: filters?.accountId,
        tipo: filters?.tipo,
        categoria: filters?.categoria,
        mes: filters?.mes,
        anoLetivo: ano,
      },
      include: { account: true },
      orderBy: { data: 'desc' },
    });
  }

  async createTransaction(dto: any, registadoPor: string) {
    const account = await this.prisma.account.findUnique({ where: { id: dto.accountId } });
    if (!account) throw new NotFoundException('Conta não encontrada');

    return this.prisma.$transaction(async (tx) => {
      const transaction = await tx.transaction.create({
        data: {
          ...dto,
          registadoPor,
          anoLetivo: dto.anoLetivo || new Date().getFullYear(),
          mes: dto.mes || new Date().getMonth() + 1,
        },
      });

      // Atualizar saldo
      const delta = dto.tipo === TransactionType.INCOME ? dto.valor : -dto.valor;
      await tx.account.update({
        where: { id: dto.accountId },
        data: { saldo: { increment: delta } },
      });

      return transaction;
    });
  }

  // ─── ORÇAMENTO ───────────────────────────────────────────

  async findBudgets(anoLetivo?: number) {
    const ano = anoLetivo || new Date().getFullYear();
    return this.prisma.budget.findMany({
      where: { anoLetivo: ano },
      orderBy: [{ tipo: 'asc' }, { categoria: 'asc' }],
    });
  }

  async upsertBudget(dto: any) {
    return this.prisma.budget.upsert({
      where: {
        anoLetivo_categoria_tipo_mes: {
          anoLetivo: dto.anoLetivo,
          categoria: dto.categoria,
          tipo: dto.tipo,
          mes: dto.mes ?? null,
        },
      },
      update: { valorPrevisto: dto.valorPrevisto, notas: dto.notas },
      create: dto,
    });
  }

  // ─── RELATÓRIOS ──────────────────────────────────────────

  async getDashboard(anoLetivo?: number) {
    const ano = anoLetivo || new Date().getFullYear();
    const mesAtual = new Date().getMonth() + 1;

    const [receitas, despesas, receitasMes, despesasMes, saldoContas] = await Promise.all([
      this.prisma.transaction.aggregate({
        where: { tipo: TransactionType.INCOME, anoLetivo: ano },
        _sum: { valor: true },
      }),
      this.prisma.transaction.aggregate({
        where: { tipo: TransactionType.EXPENSE, anoLetivo: ano },
        _sum: { valor: true },
      }),
      this.prisma.transaction.aggregate({
        where: { tipo: TransactionType.INCOME, anoLetivo: ano, mes: mesAtual },
        _sum: { valor: true },
      }),
      this.prisma.transaction.aggregate({
        where: { tipo: TransactionType.EXPENSE, anoLetivo: ano, mes: mesAtual },
        _sum: { valor: true },
      }),
      this.prisma.account.aggregate({ where: { ativo: true }, _sum: { saldo: true } }),
    ]);

    const totalReceitas = receitas._sum.valor || 0;
    const totalDespesas = despesas._sum.valor || 0;

    return {
      anoLetivo: ano,
      saldoTotal: saldoContas._sum.saldo || 0,
      totalReceitas,
      totalDespesas,
      lucroLiquido: totalReceitas - totalDespesas,
      mesAtual: {
        receitas: receitasMes._sum.valor || 0,
        despesas: despesasMes._sum.valor || 0,
        saldo: (receitasMes._sum.valor || 0) - (despesasMes._sum.valor || 0),
      },
    };
  }

  async getMensalEvolution(anoLetivo?: number) {
    const ano = anoLetivo || new Date().getFullYear();
    const meses = Array.from({ length: 12 }, (_, i) => i + 1);
    const nomesMeses = ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'];

    const data = await Promise.all(
      meses.map(async (mes) => {
        const [r, d] = await Promise.all([
          this.prisma.transaction.aggregate({ where: { tipo: 'INCOME', anoLetivo: ano, mes }, _sum: { valor: true } }),
          this.prisma.transaction.aggregate({ where: { tipo: 'EXPENSE', anoLetivo: ano, mes }, _sum: { valor: true } }),
        ]);
        return {
          mes: nomesMeses[mes - 1],
          receitas: r._sum.valor || 0,
          despesas: d._sum.valor || 0,
          saldo: (r._sum.valor || 0) - (d._sum.valor || 0),
        };
      }),
    );
    return data;
  }

  async getCategoriaBreakdown(tipo: TransactionType, anoLetivo?: number) {
    const ano = anoLetivo || new Date().getFullYear();
    const result = await this.prisma.transaction.groupBy({
      by: ['categoria'],
      where: { tipo, anoLetivo: ano },
      _sum: { valor: true },
      orderBy: { _sum: { valor: 'desc' } },
    });
    return result.map(r => ({ categoria: r.categoria, total: r._sum.valor || 0 }));
  }
}