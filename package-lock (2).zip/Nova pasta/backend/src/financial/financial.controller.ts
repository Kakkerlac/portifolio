import { Controller, Get, Post, Body, Query, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { FinancialService } from './financial.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { Role, TransactionType } from '@prisma/client';

@ApiTags('financial')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('financial')
export class FinancialController {
  constructor(private financialService: FinancialService) {}

  @Get('dashboard')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY)
  @ApiOperation({ summary: 'Dashboard financeiro geral' })
  getDashboard(@Query('anoLetivo') anoLetivo?: number) {
    return this.financialService.getDashboard(anoLetivo);
  }

  @Get('accounts')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY)
  findAllAccounts() {
    return this.financialService.findAllAccounts();
  }

  @Post('accounts')
  @Roles(Role.ADMIN, Role.SECRETARY)
  createAccount(@Body() dto: any) {
    return this.financialService.createAccount(dto);
  }

  @Get('transactions')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY)
  findTransactions(
    @Query('accountId') accountId?: string,
    @Query('tipo') tipo?: TransactionType,
    @Query('categoria') categoria?: any,
    @Query('mes') mes?: number,
    @Query('anoLetivo') anoLetivo?: number,
  ) {
    return this.financialService.findTransactions({ accountId, tipo, categoria, mes, anoLetivo });
  }

  @Post('transactions')
  @Roles(Role.ADMIN, Role.SECRETARY)
  @ApiOperation({ summary: 'Registar receita ou despesa' })
  createTransaction(@Body() dto: any, @Request() req: any) {
    return this.financialService.createTransaction(dto, req.user.sub);
  }

  @Get('budget')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY)
  findBudgets(@Query('anoLetivo') anoLetivo?: number) {
    return this.financialService.findBudgets(anoLetivo);
  }

  @Post('budget')
  @Roles(Role.ADMIN, Role.SECRETARY)
  upsertBudget(@Body() dto: any) {
    return this.financialService.upsertBudget(dto);
  }

  @Get('evolution')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY)
  @ApiOperation({ summary: 'Evolução mensal de receitas e despesas' })
  getEvolution(@Query('anoLetivo') anoLetivo?: number) {
    return this.financialService.getMensalEvolution(anoLetivo);
  }

  @Get('breakdown')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY)
  @ApiOperation({ summary: 'Breakdown por categoria' })
  getBreakdown(@Query('tipo') tipo: TransactionType, @Query('anoLetivo') anoLetivo?: number) {
    return this.financialService.getCategoriaBreakdown(tipo, anoLetivo);
  }
}