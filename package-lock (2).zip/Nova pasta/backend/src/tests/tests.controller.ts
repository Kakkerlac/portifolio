import { Controller, Get, Post, Put, Patch, Body, Param, Query, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { TestsService } from './tests.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { Role } from '@prisma/client';

@ApiTags('tests')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('tests')
export class TestsController {
  constructor(private testsService: TestsService) {}

  // ─── PROFESSOR ───────────────────────────────────────────

  @Get('my-tests')
  @Roles(Role.TEACHER, Role.ADMIN)
  getMyTests(@Request() req: any) {
    return this.testsService.findByTeacher(req.user.sub);
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.testsService.findOne(id);
  }

  @Post()
  @Roles(Role.TEACHER, Role.ADMIN)
  @ApiOperation({ summary: 'Criar novo teste com questões' })
  create(@Body() dto: any, @Request() req: any) {
    return this.testsService.create(dto, req.user.sub);
  }

  @Put(':id')
  @Roles(Role.TEACHER, Role.ADMIN)
  update(@Param('id') id: string, @Body() dto: any, @Request() req: any) {
    return this.testsService.update(id, dto, req.user.sub);
  }

  @Patch(':id/publish')
  @Roles(Role.TEACHER, Role.ADMIN)
  @ApiOperation({ summary: 'Publicar teste (torna disponível para alunos)' })
  publish(@Param('id') id: string, @Request() req: any) {
    return this.testsService.publish(id, req.user.sub);
  }

  @Patch(':id/close')
  @Roles(Role.TEACHER, Role.ADMIN)
  @ApiOperation({ summary: 'Fechar teste' })
  close(@Param('id') id: string, @Request() req: any) {
    return this.testsService.close(id, req.user.sub);
  }

  @Get(':id/results')
  @Roles(Role.TEACHER, Role.ADMIN, Role.DIRECTOR, Role.SECRETARY)
  @ApiOperation({ summary: 'Ver resultados do teste' })
  getResults(@Param('id') id: string) {
    return this.testsService.getResults(id);
  }

  // ─── ESTUDANTE ───────────────────────────────────────────

  @Get('student/available')
  @Roles(Role.STUDENT)
  @ApiOperation({ summary: 'Testes disponíveis para o aluno' })
  async getAvailable(@Request() req: any) {
    // Obtém o studentId pelo userId
    // (em produção usa um pipe ou decorator)
    return this.testsService.findAvailableForStudent(req.user.sub);
  }

  @Get('student/my-attempts')
  @Roles(Role.STUDENT)
  getMyAttempts(@Request() req: any) {
    return this.testsService.getMyAttempts(req.user.sub);
  }

  @Post(':id/start')
  @Roles(Role.STUDENT)
  @ApiOperation({ summary: 'Iniciar tentativa de um teste' })
  startAttempt(@Param('id') id: string, @Request() req: any) {
    return this.testsService.startAttempt(id, req.user.sub, req.ip);
  }

  @Post('attempts/:attemptId/submit')
  @Roles(Role.STUDENT)
  @ApiOperation({ summary: 'Submeter respostas do teste' })
  submitAttempt(
    @Param('attemptId') attemptId: string,
    @Body() body: { answers: any[] },
    @Request() req: any,
  ) {
    return this.testsService.submitAttempt(attemptId, req.user.sub, body.answers);
  }
}