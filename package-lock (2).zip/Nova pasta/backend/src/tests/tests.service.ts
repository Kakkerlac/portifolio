import {
  Injectable, NotFoundException, BadRequestException, ForbiddenException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { PaymentStatus } from '@prisma/client';

@Injectable()
export class TestsService {
  constructor(private prisma: PrismaService) {}

  // ─── PROFESSOR ───────────────────────────────────────────

  async findByTeacher(teacherId: string) {
    return this.prisma.test.findMany({
      where: { teacherId },
      include: {
        classSubject: { include: { class: true, subject: true } },
        _count: { select: { questions: true, attempts: true } },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async findOne(id: string) {
    const test = await this.prisma.test.findUnique({
      where: { id },
      include: {
        questions: { include: { options: true }, orderBy: { ordem: 'asc' } },
        classSubject: { include: { class: true, subject: true } },
        _count: { select: { attempts: true } },
      },
    });
    if (!test) throw new NotFoundException('Teste não encontrado');
    return test;
  }

  async create(dto: any, teacherId: string) {
    const { questions, ...testData } = dto;
    return this.prisma.test.create({
      data: {
        ...testData,
        teacherId,
        questions: questions
          ? {
              create: questions.map((q: any, i: number) => ({
                enunciado: q.enunciado,
                tipo: q.tipo,
                pontuacao: q.pontuacao || 1,
                ordem: i,
                imagemUrl: q.imagemUrl,
                options: q.options
                  ? { create: q.options.map((o: any, j: number) => ({ texto: o.texto, correta: o.correta, ordem: j })) }
                  : undefined,
              })),
            }
          : undefined,
      },
      include: { questions: { include: { options: true } } },
    });
  }

  async update(id: string, dto: any, teacherId: string) {
    const test = await this.findOne(id);
    if (test.teacherId !== teacherId) throw new ForbiddenException('Sem permissão');
    if (test.status === 'ACTIVE') throw new BadRequestException('Não é possível editar um teste ativo');

    const { questions, ...testData } = dto;
    return this.prisma.test.update({ where: { id }, data: testData });
  }

  async publish(id: string, teacherId: string) {
    const test = await this.findOne(id);
    if (test.teacherId !== teacherId) throw new ForbiddenException('Sem permissão');
    if (test.questions.length === 0) throw new BadRequestException('O teste precisa de ter pelo menos 1 questão');
    return this.prisma.test.update({ where: { id }, data: { status: 'PUBLISHED' } });
  }

  async close(id: string, teacherId: string) {
    const test = await this.findOne(id);
    if (test.teacherId !== teacherId) throw new ForbiddenException('Sem permissão');
    return this.prisma.test.update({ where: { id }, data: { status: 'CLOSED' } });
  }

  async getResults(testId: string) {
    const attempts = await this.prisma.testAttempt.findMany({
      where: { testId, concluido: true },
      include: {
        student: { include: { user: { select: { nome: true, apelido: true } } } },
        answers: { include: { question: true } },
      },
      orderBy: { nota: 'desc' },
    });

    const total = attempts.length;
    const mediaNotas = total > 0 ? (attempts.reduce((a, t) => a + (t.nota || 0), 0) / total).toFixed(2) : '0';
    const aprovados = attempts.filter(a => (a.nota || 0) >= 10).length;

    return { attempts, estatisticas: { total, mediaNotas, aprovados, reprovados: total - aprovados } };
  }

  // ─── ESTUDANTE ───────────────────────────────────────────

  async findAvailableForStudent(studentId: string) {
    const student = await this.prisma.student.findUnique({
      where: { id: studentId },
      select: { turmaId: true, statusPagamento: true },
    });
    if (!student) throw new NotFoundException('Estudante não encontrado');
    if (student.statusPagamento === PaymentStatus.BLOCKED) {
      throw new BadRequestException('Conta bloqueada. Regularize o pagamento para aceder aos testes.');
    }

    return this.prisma.test.findMany({
      where: {
        status: 'PUBLISHED',
        dataInicio: { lte: new Date() },
        dataFim: { gte: new Date() },
        classSubject: { classId: student.turmaId },
      },
      include: {
        classSubject: { include: { subject: true } },
        _count: { select: { questions: true } },
      },
    });
  }

  async startAttempt(testId: string, studentId: string, ipAddress?: string) {
    const test = await this.findOne(testId);
    if (test.status !== 'PUBLISHED') throw new BadRequestException('Teste não está disponível');
    if (test.dataFim && new Date() > test.dataFim) throw new BadRequestException('O prazo do teste expirou');

    // Verificar tentativas anteriores
    const existingAttempts = await this.prisma.testAttempt.count({ where: { testId, studentId } });
    if (existingAttempts >= test.tentativasMax) {
      throw new BadRequestException(`Atingiu o limite de ${test.tentativasMax} tentativa(s)`);
    }

    // Verificar se há tentativa em curso
    const inProgress = await this.prisma.testAttempt.findFirst({
      where: { testId, studentId, concluido: false },
    });
    if (inProgress) return inProgress;

    return this.prisma.testAttempt.create({
      data: { testId, studentId, ipAddress },
      include: {
        test: {
          include: {
            questions: {
              include: {
                options: { select: { id: true, texto: true, ordem: true } }, // Não enviar 'correta'
              },
              orderBy: test.embaralharQ
                ? { enunciado: 'asc' } // placeholder; shuffle no frontend
                : { ordem: 'asc' },
            },
          },
        },
      },
    });
  }

  async submitAttempt(attemptId: string, studentId: string, answers: { questionId: string; opcaoId?: string; resposta?: string }[]) {
    const attempt = await this.prisma.testAttempt.findUnique({
      where: { id: attemptId },
      include: { test: { include: { questions: { include: { options: true } } } } },
    });
    if (!attempt) throw new NotFoundException('Tentativa não encontrada');
    if (attempt.studentId !== studentId) throw new ForbiddenException('Sem permissão');
    if (attempt.concluido) throw new BadRequestException('Esta tentativa já foi submetida');

    // Verificar tempo
    if (attempt.test.duracao) {
      const elapsed = (Date.now() - attempt.iniciouEm.getTime()) / 60000;
      if (elapsed > attempt.test.duracao + 2) throw new BadRequestException('Tempo esgotado');
    }

    // Calcular pontuação
    let totalPontos = 0;
    let pontuacaoObtida = 0;

    const savedAnswers = await Promise.all(
      answers.map(async (ans) => {
        const question = attempt.test.questions.find(q => q.id === ans.questionId);
        if (!question) return null;

        totalPontos += question.pontuacao;
        let correta: boolean | null = null;
        let pontuacao = 0;

        if (ans.opcaoId) {
          const opcao = question.options.find(o => o.id === ans.opcaoId);
          correta = opcao?.correta || false;
          pontuacao = correta ? question.pontuacao : 0;
        } else if (ans.resposta) {
          // Resposta aberta: professor corrige manualmente
          correta = null;
        }

        pontuacaoObtida += pontuacao;

        return this.prisma.answer.create({
          data: {
            attemptId,
            questionId: ans.questionId,
            opcaoId: ans.opcaoId,
            resposta: ans.resposta,
            correta,
            pontuacao,
          },
        });
      }),
    );

    // Nota: 0-20
    const percentagem = totalPontos > 0 ? (pontuacaoObtida / totalPontos) * 100 : 0;
    const nota = parseFloat(((percentagem / 100) * 20).toFixed(2));

    return this.prisma.testAttempt.update({
      where: { id: attemptId },
      data: { concluido: true, terminouEm: new Date(), nota, percentagem },
    });
  }

  async getMyAttempts(studentId: string) {
    return this.prisma.testAttempt.findMany({
      where: { studentId },
      include: {
        test: { include: { classSubject: { include: { subject: true } } } },
      },
      orderBy: { iniciouEm: 'desc' },
    });
  }
}