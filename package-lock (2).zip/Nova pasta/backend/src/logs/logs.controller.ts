import { Controller, Get } from '@nestjs/common';

@Controller('logs')
export class LogsController {
  @Get()
  getLogsBase() {
    return { module: 'logs ready' };
  }
}