import { Controller, Get, Post, Put, Body, Param, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { TeachersService } from './teachers.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { Role } from '@prisma/client';

@ApiTags('teachers')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('teachers')
export class TeachersController {
  constructor(private teachersService: TeachersService) {}

  @Get()
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY)
  findAll() {
    return this.teachersService.findAll();
  }

  @Get('me')
  @Roles(Role.TEACHER)
  getMyProfile(@Request() req: any) {
    return this.teachersService.findByUserId(req.user.sub);
  }

  @Get('me/dashboard')
  @Roles(Role.TEACHER)
  getMyDashboard(@Request() req: any) {
    return this.teachersService.findByUserId(req.user.sub).then(t =>
      this.teachersService.getDashboard(t.id),
    );
  }

  @Get(':id')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY)
  findOne(@Param('id') id: string) {
    return this.teachersService.findOne(id);
  }

  @Post()
  @Roles(Role.ADMIN, Role.SECRETARY)
  create(@Body() dto: any) {
    return this.teachersService.create(dto);
  }

  @Put(':id')
  @Roles(Role.ADMIN, Role.SECRETARY)
  update(@Param('id') id: string, @Body() dto: any) {
    return this.teachersService.update(id, dto);
  }
}