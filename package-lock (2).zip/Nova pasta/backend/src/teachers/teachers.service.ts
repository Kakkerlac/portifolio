import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class TeachersService {
  constructor(private prisma: PrismaService) {}

  async findAll() {
    return this.prisma.teacher.findMany({
      include: {
        user: { select: { nome: true, apelido: true, email: true, telefone: true, fotoUrl: true, ativo: true } },
        classSubjects: { include: { class: true, subject: true } },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async findOne(id: string) {
    const teacher = await this.prisma.teacher.findUnique({
      where: { id },
      include: {
        user: true,
        classSubjects: { include: { class: true, subject: true } },
        salaries: { take: 12, orderBy: { mes: 'desc' } },
        leaves: { take: 10, orderBy: { createdAt: 'desc' } },
      },
    });
    if (!teacher) throw new NotFoundException('Professor não encontrado');
    return teacher;
  }

  async findByUserId(userId: string) {
    const teacher = await this.prisma.teacher.findUnique({
      where: { userId },
      include: {
        user: { select: { nome: true, apelido: true, email: true, fotoUrl: true } },
        classSubjects: {
          include: {
            class: { include: { students: { include: { user: { select: { nome: true, apelido: true } } } } } },
            subject: true,
          },
        },
      },
    });
    if (!teacher) throw new NotFoundException('Professor não encontrado');
    return teacher;
  }

  async create(dto: any) {
    return this.prisma.teacher.create({ data: dto });
  }

  async update(id: string, dto: any) {
    await this.findOne(id);
    return this.prisma.teacher.update({ where: { id }, data: dto });
  }

  async getDashboard(teacherId: string) {
    const teacher = await this.findOne(teacherId);
    const anoAtual = new Date().getFullYear();

    const [totalAlunos, testsCount, materiaisCount] = await Promise.all([
      this.prisma.student.count({ where: { turmaId: { in: teacher.classSubjects.map(cs => cs.classId) } } }),
      this.prisma.test.count({ where: { teacherId, anoLetivo: anoAtual } }),
      this.prisma.material.count({ where: { teacherId, anoLetivo: anoAtual } }),
    ]);

    return {
      teacher,
      resumo: {
        totalTurmas: teacher.classSubjects.length,
        totalAlunos,
        totalTestes: testsCount,
        totalMateriais: materiaisCount,
      },
    };
  }
}