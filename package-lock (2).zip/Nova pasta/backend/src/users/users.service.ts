import { Injectable, NotFoundException, ConflictException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { Role } from '@prisma/client';
import * as bcrypt from 'bcrypt';

@Injectable()
export class UsersService {
  constructor(private prisma: PrismaService) {}

  async findAll(role?: Role) {
    return this.prisma.user.findMany({
      where: role ? { role } : undefined,
      select: {
        id: true, numero: true, email: true, role: true,
        nome: true, apelido: true, telefone: true, fotoUrl: true,
        genero: true, ativo: true, bloqueado: true, lastLoginAt: true, createdAt: true,
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async findOne(id: string) {
    const user = await this.prisma.user.findUnique({
      where: { id },
      select: {
        id: true, numero: true, email: true, role: true,
        nome: true, apelido: true, telefone: true, fotoUrl: true,
        genero: true, dataNascimento: true, ativo: true, bloqueado: true,
        motivoBloqueio: true, lastLoginAt: true, createdAt: true,
        student: { select: { id: true, numeroMatricula: true, turmaId: true, statusPagamento: true } },
        teacher: { select: { id: true, especialidade: true, salarioBase: true } },
      },
    });
    if (!user) throw new NotFoundException('Utilizador não encontrado');
    return user;
  }

  async findByEmail(email: string) {
    return this.prisma.user.findUnique({ where: { email } });
  }

  async create(dto: any) {
    const exists = await this.prisma.user.findUnique({ where: { email: dto.email } });
    if (exists) throw new ConflictException('Email já registado');

    const passwordHash = await bcrypt.hash(dto.password || 'Pirilampo@2025', 12);
    const numero = await this.generateNumero(dto.role);

    return this.prisma.user.create({
      data: { ...dto, passwordHash, numero, password: undefined },
      select: {
        id: true, numero: true, email: true, role: true,
        nome: true, apelido: true, ativo: true, createdAt: true,
      },
    });
  }

  async update(id: string, dto: any) {
    await this.findOne(id);
    const { password, ...rest } = dto;
    const data: any = { ...rest };
    if (password) data.passwordHash = await bcrypt.hash(password, 12);

    return this.prisma.user.update({
      where: { id },
      data,
      select: {
        id: true, numero: true, email: true, role: true,
        nome: true, apelido: true, telefone: true, ativo: true,
      },
    });
  }

  async toggleBlock(id: string, bloqueado: boolean, motivo?: string) {
    await this.findOne(id);
    return this.prisma.user.update({
      where: { id },
      data: { bloqueado, motivoBloqueio: bloqueado ? motivo : null },
    });
  }

  async toggleActive(id: string, ativo: boolean) {
    await this.findOne(id);
    return this.prisma.user.update({ where: { id }, data: { ativo } });
  }

  private async generateNumero(role: Role): Promise<string> {
    const prefixes: Record<Role, string> = {
      STUDENT: 'EST', TEACHER: 'PROF', SECRETARY: 'SEC',
      DIRECTOR: 'DIR', ADMIN: 'ADMIN',
    };
    const prefix = prefixes[role];
    const year = new Date().getFullYear();
    const count = await this.prisma.user.count({ where: { role } });
    return `${prefix}-${year}-${String(count + 1).padStart(3, '0')}`;
  }
}