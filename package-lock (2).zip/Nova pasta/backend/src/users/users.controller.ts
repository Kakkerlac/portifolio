import { Controller, Get, Post, Put, Patch, Body, Param, Query, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { UsersService } from './users.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { Role } from '@prisma/client';

@ApiTags('users')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('users')
export class UsersController {
  constructor(private usersService: UsersService) {}

  @Get()
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY)
  @ApiOperation({ summary: 'Listar todos os utilizadores' })
  findAll(@Query('role') role?: Role) {
    return this.usersService.findAll(role);
  }

  @Get('me')
  @ApiOperation({ summary: 'Perfil do utilizador autenticado' })
  getMe(@Request() req: any) {
    return this.usersService.findOne(req.user.sub);
  }

  @Get(':id')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY)
  @ApiOperation({ summary: 'Obter utilizador por ID' })
  findOne(@Param('id') id: string) {
    return this.usersService.findOne(id);
  }

  @Post()
  @Roles(Role.ADMIN, Role.SECRETARY)
  @ApiOperation({ summary: 'Criar novo utilizador' })
  create(@Body() dto: any) {
    return this.usersService.create(dto);
  }

  @Put(':id')
  @Roles(Role.ADMIN, Role.SECRETARY)
  @ApiOperation({ summary: 'Atualizar utilizador' })
  update(@Param('id') id: string, @Body() dto: any) {
    return this.usersService.update(id, dto);
  }

  @Patch(':id/block')
  @Roles(Role.ADMIN, Role.SECRETARY)
  @ApiOperation({ summary: 'Bloquear/Desbloquear utilizador' })
  toggleBlock(
    @Param('id') id: string,
    @Body() body: { bloqueado: boolean; motivo?: string },
  ) {
    return this.usersService.toggleBlock(id, body.bloqueado, body.motivo);
  }

  @Patch(':id/active')
  @Roles(Role.ADMIN)
  @ApiOperation({ summary: 'Ativar/Desativar utilizador' })
  toggleActive(@Param('id') id: string, @Body() body: { ativo: boolean }) {
    return this.usersService.toggleActive(id, body.ativo);
  }
}