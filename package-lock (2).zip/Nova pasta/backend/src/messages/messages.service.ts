import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class MessagesService {
  constructor(private prisma: PrismaService) {}

  async sendMessage(dto: {
    senderId: string;
    recipientIds?: string[];
    grupoAlvo?: string;
    assunto?: string;
    corpo: string;
    tipo?: string;
  }) {
    let recipientIds = dto.recipientIds || [];

    // Se for para um grupo, buscar destinatários automaticamente
    if (dto.grupoAlvo && !dto.recipientIds?.length) {
      if (dto.grupoAlvo === 'all') {
        const users = await this.prisma.user.findMany({ where: { ativo: true }, select: { id: true } });
        recipientIds = users.map(u => u.id);
      } else if (dto.grupoAlvo === 'students') {
        const students = await this.prisma.user.findMany({ where: { role: 'STUDENT', ativo: true }, select: { id: true } });
        recipientIds = students.map(u => u.id);
      } else if (dto.grupoAlvo === 'teachers') {
        const teachers = await this.prisma.user.findMany({ where: { role: 'TEACHER', ativo: true }, select: { id: true } });
        recipientIds = teachers.map(u => u.id);
      } else if (dto.grupoAlvo.startsWith('class:')) {
        const classId = dto.grupoAlvo.split(':')[1];
        const students = await this.prisma.student.findMany({ where: { turmaId: classId }, include: { user: true } });
        recipientIds = students.map(s => s.userId);
      }
    }

    return this.prisma.$transaction(async (tx) => {
      const message = await tx.message.create({
        data: {
          senderId: dto.senderId,
          assunto: dto.assunto,
          corpo: dto.corpo,
          tipo: dto.tipo || 'DIRECT',
          grupoAlvo: dto.grupoAlvo,
        },
      });

      if (recipientIds.length > 0) {
        await tx.messageRecipient.createMany({
          data: recipientIds.map(userId => ({ messageId: message.id, userId })),
          skipDuplicates: true,
        });
      }

      return message;
    });
  }

  async getInbox(userId: string, page = 1, limit = 20) {
    const skip = (page - 1) * limit;
    const [messages, total] = await Promise.all([
      this.prisma.messageRecipient.findMany({
        where: { userId },
        include: {
          message: {
            include: { sender: { select: { nome: true, apelido: true, fotoUrl: true, role: true } } },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      this.prisma.messageRecipient.count({ where: { userId } }),
    ]);

    return { messages, total, page, limit, totalPages: Math.ceil(total / limit) };
  }

  async getSent(userId: string) {
    return this.prisma.message.findMany({
      where: { senderId: userId },
      include: {
        recipients: {
          include: { user: { select: { nome: true, apelido: true, role: true } } },
          take: 5,
        },
        _count: { select: { recipients: true } },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async markAsRead(messageId: string, userId: string) {
    return this.prisma.messageRecipient.updateMany({
      where: { messageId, userId },
      data: { lido: true, lidoEm: new Date() },
    });
  }

  async getUnreadCount(userId: string) {
    return this.prisma.messageRecipient.count({ where: { userId, lido: false } });
  }

  async getAnnouncements() {
    return this.prisma.announcement.findMany({
      where: { ativo: true, OR: [{ dataExpiracao: null }, { dataExpiracao: { gte: new Date() } }] },
      orderBy: [{ importante: 'desc' }, { publicadoEm: 'desc' }],
    });
  }

  async createAnnouncement(dto: any) {
    return this.prisma.announcement.create({ data: dto });
  }
}