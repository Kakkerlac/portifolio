import { Controller, Get, Post, Patch, Body, Param, Query, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { MessagesService } from './messages.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { Role } from '@prisma/client';

@ApiTags('messages')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('messages')
export class MessagesController {
  constructor(private messagesService: MessagesService) {}

  @Get('inbox')
  @ApiOperation({ summary: 'Caixa de entrada' })
  getInbox(@Request() req: any, @Query('page') page?: number, @Query('limit') limit?: number) {
    return this.messagesService.getInbox(req.user.sub, page, limit);
  }

  @Get('sent')
  @ApiOperation({ summary: 'Mensagens enviadas' })
  getSent(@Request() req: any) {
    return this.messagesService.getSent(req.user.sub);
  }

  @Get('unread-count')
  getUnreadCount(@Request() req: any) {
    return this.messagesService.getUnreadCount(req.user.sub);
  }

  @Post()
  @ApiOperation({ summary: 'Enviar mensagem ou circular' })
  sendMessage(@Body() dto: any, @Request() req: any) {
    return this.messagesService.sendMessage({ ...dto, senderId: req.user.sub });
  }

  @Patch(':id/read')
  markAsRead(@Param('id') id: string, @Request() req: any) {
    return this.messagesService.markAsRead(id, req.user.sub);
  }

  @Get('announcements')
  @ApiOperation({ summary: 'Avisos e comunicados ativos' })
  getAnnouncements() {
    return this.messagesService.getAnnouncements();
  }

  @Post('announcements')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY)
  @ApiOperation({ summary: 'Criar aviso/comunicado' })
  createAnnouncement(@Body() dto: any, @Request() req: any) {
    return this.messagesService.createAnnouncement({ ...dto, autor: req.user.sub });
  }
}