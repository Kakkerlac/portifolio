import {
  WebSocketGateway, WebSocketServer, SubscribeMessage,
  OnGatewayConnection, OnGatewayDisconnect, MessageBody, ConnectedSocket,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { Logger } from '@nestjs/common';
import { MessagesService } from './messages.service';

@WebSocketGateway({ cors: { origin: '*' }, namespace: '/chat' })
export class MessagesGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer() server: Server;
  private readonly logger = new Logger(MessagesGateway.name);
  private connectedUsers = new Map<string, string>(); // userId -> socketId

  constructor(private messagesService: MessagesService) {}

  handleConnection(client: Socket) {
    this.logger.log(`Cliente conectado: ${client.id}`);
  }

  handleDisconnect(client: Socket) {
    for (const [userId, socketId] of this.connectedUsers) {
      if (socketId === client.id) {
        this.connectedUsers.delete(userId);
        break;
      }
    }
    this.logger.log(`Cliente desconectado: ${client.id}`);
  }

  @SubscribeMessage('join')
  handleJoin(@ConnectedSocket() client: Socket, @MessageBody() data: { userId: string }) {
    this.connectedUsers.set(data.userId, client.id);
    client.join(`user:${data.userId}`);
    this.logger.log(`User ${data.userId} entrou`);
    return { event: 'joined', data: { userId: data.userId } };
  }

  @SubscribeMessage('send_message')
  async handleMessage(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: { senderId: string; recipientIds: string[]; corpo: string; assunto?: string },
  ) {
    const message = await this.messagesService.sendMessage(data);

    // Notificar destinatários online
    for (const recipientId of data.recipientIds) {
      const socketId = this.connectedUsers.get(recipientId);
      if (socketId) {
        this.server.to(`user:${recipientId}`).emit('new_message', {
          messageId: message.id,
          senderId: data.senderId,
          corpo: data.corpo,
          assunto: data.assunto,
          timestamp: new Date(),
        });
      }
    }

    return { event: 'message_sent', data: message };
  }

  @SubscribeMessage('mark_read')
  async handleMarkRead(
    @MessageBody() data: { messageId: string; userId: string },
  ) {
    await this.messagesService.markAsRead(data.messageId, data.userId);
    return { event: 'marked_read', data };
  }

  // Método para enviar notificação a um utilizador específico (chamado de outros serviços)
  sendNotificationToUser(userId: string, event: string, data: any) {
    this.server.to(`user:${userId}`).emit(event, data);
  }
}