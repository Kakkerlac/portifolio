import { Module } from '@nestjs/common';
import { SecretariaController } from './secretaria.controller';
import { SecretariaService } from './secretaria.service';

@Module({
  controllers: [SecretariaController],
  providers: [SecretariaService]
})
export class SecretariaModule {}
