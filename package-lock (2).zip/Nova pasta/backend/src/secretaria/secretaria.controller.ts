import { Controller, Get } from '@nestjs/common';

@Controller('secretaria')
export class SecretariaController {
  @Get()
  getSecretariaBase() {
    return { module: 'secretaria ready' };
  }
}