import { Controller, Get } from '@nestjs/common';
import { ApiTags, ApiOperation } from '@nestjs/swagger';

@ApiTags('health')
@Controller()
export class AppController {
  @Get('health')
  @ApiOperation({ summary: 'Health check' })
  health() {
    return {
      status: 'ok',
      timestamp: new Date().toISOString(),
      service: 'Pirilampo API',
      version: '1.0.0',
    };
  }

  @Get()
  root() {
    return { message: 'Pirilampo API - Secretaria Virtual Escolar', docs: '/api/docs' };
  }
}