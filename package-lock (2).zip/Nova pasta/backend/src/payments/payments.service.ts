import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { PaymentMethod, PaymentStatus, TransactionCategory } from '@prisma/client';
import { Cron, CronExpression } from '@nestjs/schedule';

@Injectable()
export class PaymentsService {
  constructor(private prisma: PrismaService) {}

  // ─── TAXAS/PROPINAS ──────────────────────────────────────

  async findAllFees(anoLetivo?: number) {
    return this.prisma.fee.findMany({
      where: { ativo: true, academicYear: { ano: anoLetivo || new Date().getFullYear() } },
      include: { academicYear: true },
    });
  }

  async createFee(dto: any) {
    return this.prisma.fee.create({ data: dto });
  }

  async assignFeesToAll(feeId: string, anoLetivo: number) {
    const [fee, students] = await Promise.all([
      this.prisma.fee.findUnique({ where: { id: feeId } }),
      this.prisma.student.findMany({ where: { anoLetivo } }),
    ]);
    if (!fee) throw new NotFoundException('Taxa não encontrada');

    const now = new Date();
    const assignments = students.flatMap(s => {
      if (fee.frequencia === 'MONTHLY') {
        // Gerar 10 meses (Feb-Nov)
        return Array.from({ length: 10 }, (_, i) => ({
          studentId: s.id,
          feeId,
          anoLetivo,
          mes: i + 2, // Fev=2 ... Nov=11
          valorOriginal: fee.valor,
          valorTotal: fee.valor,
          dataVencimento: new Date(anoLetivo, i + 1, fee.vencimentoDia || 10),
        }));
      }
      return [{
        studentId: s.id,
        feeId,
        anoLetivo,
        mes: null,
        valorOriginal: fee.valor,
        valorTotal: fee.valor,
        dataVencimento: new Date(anoLetivo, 1, 1),
      }];
    });

    return this.prisma.feeAssignment.createMany({ data: assignments, skipDuplicates: true });
  }

  // ─── PAGAMENTOS ──────────────────────────────────────────

  async findByStudent(studentId: string) {
    return this.prisma.feeAssignment.findMany({
      where: { studentId },
      include: { fee: true, payment: true },
      orderBy: [{ anoLetivo: 'desc' }, { mes: 'asc' }],
    });
  }

  async getPendingByStudent(studentId: string) {
    return this.prisma.feeAssignment.findMany({
      where: { studentId, pago: false },
      include: { fee: true },
      orderBy: { dataVencimento: 'asc' },
    });
  }

  async registerPayment(dto: {
    studentId: string;
    feeAssignmentIds: string[];
    valor: number;
    metodo: PaymentMethod;
    comprovativo?: string;
    observacoes?: string;
    processadoPor: string;
  }) {
    // Verificar assignments
    const assignments = await this.prisma.feeAssignment.findMany({
      where: { id: { in: dto.feeAssignmentIds }, studentId: dto.studentId, pago: false },
    });
    if (assignments.length !== dto.feeAssignmentIds.length) {
      throw new BadRequestException('Algumas parcelas já estão pagas ou não pertencem a este aluno');
    }

    const totalDevido = assignments.reduce((acc, a) => acc + a.valorTotal, 0);
    if (Math.abs(dto.valor - totalDevido) > 1) {
      throw new BadRequestException(`Valor incorreto. Total em dívida: ${totalDevido} AOA`);
    }

    // Gerar referência
    const referencia = `PAG-${Date.now()}`;

    // Criar pagamento e marcar assignments como pagos
    const payment = await this.prisma.$transaction(async (tx) => {
      const p = await tx.payment.create({
        data: {
          studentId: dto.studentId,
          referencia,
          valor: dto.valor,
          metodo: dto.metodo,
          comprovativo: dto.comprovativo,
          observacoes: dto.observacoes,
          processadoPor: dto.processadoPor,
        },
      });
      await tx.feeAssignment.updateMany({
        where: { id: { in: dto.feeAssignmentIds } },
        data: { pago: true, dataPagamento: new Date(), paymentId: p.id },
      });
      // Desbloquear aluno se estava bloqueado por inadimplência
      const pendentes = await tx.feeAssignment.count({ where: { studentId: dto.studentId, pago: false } });
      if (pendentes === 0) {
        await tx.student.update({ where: { id: dto.studentId }, data: { statusPagamento: 'REGULAR', diasAtraso: 0 } });
        await tx.user.updateMany({
          where: { student: { id: dto.studentId }, bloqueado: true, motivoBloqueio: { contains: 'inadimplência' } },
          data: { bloqueado: false, motivoBloqueio: null },
        });
      }
      return p;
    });

    return payment;
  }

  async getPaymentHistory(studentId: string) {
    return this.prisma.payment.findMany({
      where: { studentId },
      include: { feeAssignments: { include: { fee: true } } },
      orderBy: { dataTransacao: 'desc' },
    });
  }

  // ─── CRON: Verificar inadimplência diariamente ────────────

  @Cron(CronExpression.EVERY_DAY_AT_MIDNIGHT)
  async verificarInadimplencia() {
    const config = await this.prisma.systemConfig.findMany({
      where: { chave: { in: ['bloqueio_inadimplencia_dias', 'juros_atraso_percentual', 'bloqueio_inadimplencia_ativo'] } },
    });
    const getConfig = (chave: string, def: any) => config.find(c => c.chave === chave)?.valor ?? def;

    const ativo = getConfig('bloqueio_inadimplencia_ativo', 'true') === 'true';
    if (!ativo) return;

    const diasBloqueio = parseInt(getConfig('bloqueio_inadimplencia_dias', '60'));
    const juros = parseFloat(getConfig('juros_atraso_percentual', '2.5'));
    const hoje = new Date();

    // Buscar assignments vencidos
    const vencidos = await this.prisma.feeAssignment.findMany({
      where: { pago: false, dataVencimento: { lt: hoje } },
      include: { student: { include: { user: true } } },
    });

    for (const assignment of vencidos) {
      const diasAtraso = Math.floor((hoje.getTime() - assignment.dataVencimento.getTime()) / 86400000);

      // Aplicar juros
      const jurosMes = Math.floor(diasAtraso / 30);
      const valorJuros = assignment.valorOriginal * (juros / 100) * jurosMes;
      const valorTotal = assignment.valorOriginal + valorJuros;

      await this.prisma.feeAssignment.update({
        where: { id: assignment.id },
        data: { valorJuros, valorTotal, student: { update: { diasAtraso } } },
      });

      // Bloquear se excedeu limite
      if (diasAtraso >= diasBloqueio && assignment.student.statusPagamento !== PaymentStatus.BLOCKED) {
        await this.prisma.$transaction([
          this.prisma.student.update({
            where: { id: assignment.studentId },
            data: { statusPagamento: PaymentStatus.BLOCKED },
          }),
          this.prisma.user.update({
            where: { id: assignment.student.userId },
            data: { bloqueado: true, motivoBloqueio: `Bloqueado por inadimplência (${diasAtraso} dias de atraso)` },
          }),
        ]);
      } else if (diasAtraso > 0 && assignment.student.statusPagamento === PaymentStatus.REGULAR) {
        await this.prisma.student.update({
          where: { id: assignment.studentId },
          data: { statusPagamento: diasAtraso > 30 ? PaymentStatus.OVERDUE : PaymentStatus.PENDING },
        });
      }
    }
  }

  async getFinancialSummary(anoLetivo?: number) {
    const ano = anoLetivo || new Date().getFullYear();
    const [totalEsperado, totalPago, totalEmDivida, totalBloqueados] = await Promise.all([
      this.prisma.feeAssignment.aggregate({ where: { anoLetivo: ano }, _sum: { valorTotal: true } }),
      this.prisma.feeAssignment.aggregate({ where: { anoLetivo: ano, pago: true }, _sum: { valorTotal: true } }),
      this.prisma.feeAssignment.aggregate({ where: { anoLetivo: ano, pago: false }, _sum: { valorTotal: true } }),
      this.prisma.student.count({ where: { statusPagamento: PaymentStatus.BLOCKED } }),
    ]);

    return {
      totalEsperado: totalEsperado._sum.valorTotal || 0,
      totalPago: totalPago._sum.valorTotal || 0,
      totalEmDivida: totalEmDivida._sum.valorTotal || 0,
      totalBloqueados,
      percentagemCobranca: totalEsperado._sum.valorTotal
        ? ((totalPago._sum.valorTotal || 0) / totalEsperado._sum.valorTotal * 100).toFixed(1)
        : '0',
    };
  }
}