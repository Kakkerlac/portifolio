import { Controller, Get, Post, Body, Param, Query, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { PaymentsService } from './payments.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { Role } from '@prisma/client';

@ApiTags('payments')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('payments')
export class PaymentsController {
  constructor(private paymentsService: PaymentsService) {}

  @Get('fees')
  @ApiOperation({ summary: 'Listar todas as taxas/propinas' })
  findAllFees(@Query('anoLetivo') anoLetivo?: number) {
    return this.paymentsService.findAllFees(anoLetivo);
  }

  @Post('fees')
  @Roles(Role.ADMIN, Role.SECRETARY)
  @ApiOperation({ summary: 'Criar nova taxa/propina' })
  createFee(@Body() dto: any) {
    return this.paymentsService.createFee(dto);
  }

  @Post('fees/:feeId/assign-all')
  @Roles(Role.ADMIN, Role.SECRETARY)
  @ApiOperation({ summary: 'Atribuir taxa a todos os alunos do ano letivo' })
  assignFeesToAll(@Param('feeId') feeId: string, @Body() body: { anoLetivo: number }) {
    return this.paymentsService.assignFeesToAll(feeId, body.anoLetivo);
  }

  @Get('summary')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY)
  @ApiOperation({ summary: 'Resumo financeiro das propinas' })
  getSummary(@Query('anoLetivo') anoLetivo?: number) {
    return this.paymentsService.getFinancialSummary(anoLetivo);
  }

  @Get('student/:studentId')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY, Role.STUDENT)
  findByStudent(@Param('studentId') studentId: string) {
    return this.paymentsService.findByStudent(studentId);
  }

  @Get('student/:studentId/pending')
  @Roles(Role.ADMIN, Role.SECRETARY, Role.STUDENT)
  getPending(@Param('studentId') studentId: string) {
    return this.paymentsService.getPendingByStudent(studentId);
  }

  @Get('student/:studentId/history')
  @Roles(Role.ADMIN, Role.DIRECTOR, Role.SECRETARY, Role.STUDENT)
  getHistory(@Param('studentId') studentId: string) {
    return this.paymentsService.getPaymentHistory(studentId);
  }

  @Post('register')
  @Roles(Role.ADMIN, Role.SECRETARY)
  @ApiOperation({ summary: 'Registar pagamento de propinas' })
  registerPayment(@Body() dto: any, @Request() req: any) {
    return this.paymentsService.registerPayment({ ...dto, processadoPor: req.user.sub });
  }
}