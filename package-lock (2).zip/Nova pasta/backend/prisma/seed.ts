import { PrismaClient, Role, Gender } from '@prisma/client';
import * as bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 A iniciar seed...');

  const senha = await bcrypt.hash('Pirilampo@2025', 10);

  // Ano letivo
  await prisma.academicYear.upsert({
    where: { ano: 2025 },
    update: {},
    create: { ano: 2025, dataInicio: new Date('2025-02-01'), dataFim: new Date('2025-11-30'), ativo: true },
  });

  // Admin
  const admin = await prisma.user.upsert({
    where: { email: 'admin@pirilampo.ao' },
    update: {},
    create: { email: 'admin@pirilampo.ao', password: senha, nome: 'Super', apelido: 'Admin', role: Role.ADMIN },
  });

  // Directora
  const diretora = await prisma.user.upsert({
    where: { email: 'diretora@pirilampo.ao' },
    update: {},
    create: { email: 'diretora@pirilampo.ao', password: senha, nome: 'Maria', apelido: 'Silva', role: Role.DIRECTOR },
  });
  await prisma.director.upsert({
    where: { userId: diretora.id },
    update: {},
    create: { userId: diretora.id },
  });

  // Secretária
  const secretaria = await prisma.user.upsert({
    where: { email: 'secretaria@pirilampo.ao' },
    update: {},
    create: { email: 'secretaria@pirilampo.ao', password: senha, nome: 'Ana', apelido: 'Santos', role: Role.SECRETARY },
  });
  await prisma.secretary.upsert({
    where: { userId: secretaria.id },
    update: {},
    create: { userId: secretaria.id },
  });

  // Professor
  const professor = await prisma.user.upsert({
    where: { email: 'prof.joao@pirilampo.ao' },
    update: {},
    create: { email: 'prof.joao@pirilampo.ao', password: senha, nome: 'João', apelido: 'Costa', role: Role.TEACHER },
  });
  await prisma.teacher.upsert({
    where: { userId: professor.id },
    update: {},
    create: { userId: professor.id, salarioBase: 150000 },
  });

  // Turma
  const turma = await prisma.class.upsert({
    where: { nome_turno_anoLetivo: { nome: '10ª A', turno: 'Manhã', anoLetivo: 2025 } },
    update: {},
    create: { nome: '10ª A', turno: 'Manhã', anoLetivo: 2025 },
  });

  // Aluno
  const aluno = await prisma.user.upsert({
    where: { email: 'aluno@pirilampo.ao' },
    update: {},
    create: { email: 'aluno@pirilampo.ao', password: senha, nome: 'Pedro', apelido: 'Alves', role: Role.STUDENT },
  });
  await prisma.student.upsert({
    where: { userId: aluno.id },
    update: {},
    create: {
      userId: aluno.id,
      turmaId: turma.id,
      numeroMatricula: 'PRI-2025-001',
      anoLetivo: 2025,
      genero: Gender.MALE,
    },
  });

  // Configurações do sistema
  const configs = [
    { chave: 'escola_nome', valor: 'Colégio Pirilampo', categoria: 'escola' },
    { chave: 'escola_morada', valor: 'Luanda, Angola', categoria: 'escola' },
    { chave: 'escola_telefone', valor: '+244 900 000 000', categoria: 'escola' },
    { chave: 'ano_letivo_atual', valor: '2025', categoria: 'sistema' },
    { chave: 'max_faltas_percent', valor: '25', categoria: 'academico' },
    { chave: 'nota_minima_aprovacao', valor: '10', categoria: 'academico' },
  ];

  for (const config of configs) {
    await prisma.systemConfig.upsert({
      where: { chave: config.chave },
      update: {},
      create: config,
    });
  }

  // Conta principal
  await prisma.account.upsert({
    where: { id: 'conta-principal' },
    update: {},
    create: { id: 'conta-principal', nome: 'Caixa Principal', tipo: 'CAIXA', saldo: 0 },
  });

  console.log('✅ Seed concluído!');
  console.log('');
  console.log('📋 Credenciais:');
  console.log('   admin@pirilampo.ao    → Pirilampo@2025  (Admin)');
  console.log('   diretora@pirilampo.ao → Pirilampo@2025  (Directora)');
  console.log('   secretaria@pirilampo.ao → Pirilampo@2025 (Secretaria)');
  console.log('   prof.joao@pirilampo.ao → Pirilampo@2025  (Professor)');
  console.log('   aluno@pirilampo.ao    → Pirilampo@2025  (Aluno)');
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });