import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import { Toaster } from '@/components/ui/sonner';
import { Loading } from '@/components/common/Loading';
import type { UserRole } from '@/types';

// Auth Pages
import Login from '@/pages/auth/Login';

// Estudante Pages
import EstudanteDashboard from '@/pages/estudante/Dashboard';
import Disciplinas from '@/pages/estudante/Disciplinas';
import DisciplinaDetail from '@/pages/estudante/DisciplinaDetail';
import Calendario from '@/pages/estudante/Calendario';
import Notas from '@/pages/estudante/Notas';
import Testes from '@/pages/estudante/Testes';
import Classificacao from '@/pages/estudante/Classificacao';
import Perfil from '@/pages/estudante/Perfil';

// Professor Pages
import ProfessorDashboard from '@/pages/professor/Dashboard';

// Secretaria Pages
import SecretariaDashboard from '@/pages/secretaria/Dashboard';

// Diretora Pages
import DiretoraDashboard from '@/pages/diretora/Dashboard';

// TI Pages
import TIDashboard from '@/pages/ti/Dashboard';

// Protected Route Component
interface ProtectedRouteProps {
  children: React.ReactNode;
  allowedRoles?: UserRole[];
}

function ProtectedRoute({ children, allowedRoles }: ProtectedRouteProps) {
  const { isAuthenticated, user, isLoading } = useAuth();

  if (isLoading) {
    return <Loading fullScreen text="Verificando autenticação..." />;
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles && user && !allowedRoles.includes(user.role)) {
    // Redirecionar para a página apropriada baseada no role
    switch (user.role) {
      case 'estudante':
        return <Navigate to="/estudante" replace />;
      case 'professor':
        return <Navigate to="/professor" replace />;
      case 'secretaria':
        return <Navigate to="/secretaria" replace />;
      case 'diretora':
        return <Navigate to="/diretora" replace />;
      case 'ti_admin':
        return <Navigate to="/ti" replace />;
      default:
        return <Navigate to="/login" replace />;
    }
  }

  return <>{children}</>;
}

// Role-based redirect component
function RoleRedirect() {
  const { isAuthenticated, user, isLoading } = useAuth();

  if (isLoading) {
    return <Loading fullScreen text="Carregando..." />;
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  switch (user?.role) {
    case 'estudante':
      return <Navigate to="/estudante" replace />;
    case 'professor':
      return <Navigate to="/professor" replace />;
    case 'secretaria':
      return <Navigate to="/secretaria" replace />;
    case 'diretora':
      return <Navigate to="/diretora" replace />;
    case 'ti_admin':
      return <Navigate to="/ti" replace />;
    default:
      return <Navigate to="/login" replace />;
  }
}

function AppRoutes() {
  return (
    <Routes>
      {/* Public Routes */}
      <Route path="/login" element={<Login />} />
      
      {/* Root Redirect */}
      <Route path="/" element={<RoleRedirect />} />

      {/* Estudante Routes */}
      <Route
        path="/estudante"
        element={
          <ProtectedRoute allowedRoles={['estudante']}>
            <EstudanteDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/estudante/disciplinas"
        element={
          <ProtectedRoute allowedRoles={['estudante']}>
            <Disciplinas />
          </ProtectedRoute>
        }
      />
      <Route
        path="/estudante/disciplinas/:id"
        element={
          <ProtectedRoute allowedRoles={['estudante']}>
            <DisciplinaDetail />
          </ProtectedRoute>
        }
      />
      <Route
        path="/estudante/calendario"
        element={
          <ProtectedRoute allowedRoles={['estudante']}>
            <Calendario />
          </ProtectedRoute>
        }
      />
      <Route
        path="/estudante/notas"
        element={
          <ProtectedRoute allowedRoles={['estudante']}>
            <Notas />
          </ProtectedRoute>
        }
      />
      <Route
        path="/estudante/testes"
        element={
          <ProtectedRoute allowedRoles={['estudante']}>
            <Testes />
          </ProtectedRoute>
        }
      />
      <Route
        path="/estudante/classificacao"
        element={
          <ProtectedRoute allowedRoles={['estudante']}>
            <Classificacao />
          </ProtectedRoute>
        }
      />
      <Route
        path="/estudante/perfil"
        element={
          <ProtectedRoute allowedRoles={['estudante']}>
            <Perfil />
          </ProtectedRoute>
        }
      />

      {/* Professor Routes */}
      <Route
        path="/professor"
        element={
          <ProtectedRoute allowedRoles={['professor']}>
            <ProfessorDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/professor/turmas"
        element={
          <ProtectedRoute allowedRoles={['professor']}>
            <ProfessorDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/professor/notas"
        element={
          <ProtectedRoute allowedRoles={['professor']}>
            <ProfessorDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/professor/presencas"
        element={
          <ProtectedRoute allowedRoles={['professor']}>
            <ProfessorDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/professor/testes"
        element={
          <ProtectedRoute allowedRoles={['professor']}>
            <ProfessorDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/professor/materiais"
        element={
          <ProtectedRoute allowedRoles={['professor']}>
            <ProfessorDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/professor/relatorios"
        element={
          <ProtectedRoute allowedRoles={['professor']}>
            <ProfessorDashboard />
          </ProtectedRoute>
        }
      />

      {/* Secretaria Routes */}
      <Route
        path="/secretaria"
        element={
          <ProtectedRoute allowedRoles={['secretaria', 'diretora', 'ti_admin']}>
            <SecretariaDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/secretaria/alunos"
        element={
          <ProtectedRoute allowedRoles={['secretaria', 'diretora', 'ti_admin']}>
            <SecretariaDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/secretaria/alunos/novo"
        element={
          <ProtectedRoute allowedRoles={['secretaria', 'diretora', 'ti_admin']}>
            <SecretariaDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/secretaria/inadimplentes"
        element={
          <ProtectedRoute allowedRoles={['secretaria', 'diretora', 'ti_admin']}>
            <SecretariaDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/secretaria/professores"
        element={
          <ProtectedRoute allowedRoles={['secretaria', 'diretora', 'ti_admin']}>
            <SecretariaDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/secretaria/professores/novo"
        element={
          <ProtectedRoute allowedRoles={['secretaria', 'diretora', 'ti_admin']}>
            <SecretariaDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/secretaria/turmas"
        element={
          <ProtectedRoute allowedRoles={['secretaria', 'diretora', 'ti_admin']}>
            <SecretariaDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/secretaria/horarios"
        element={
          <ProtectedRoute allowedRoles={['secretaria', 'diretora', 'ti_admin']}>
            <SecretariaDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/secretaria/pagamentos"
        element={
          <ProtectedRoute allowedRoles={['secretaria', 'diretora', 'ti_admin']}>
            <SecretariaDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/secretaria/pagamentos/historico"
        element={
          <ProtectedRoute allowedRoles={['secretaria', 'diretora', 'ti_admin']}>
            <SecretariaDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/secretaria/relatorios"
        element={
          <ProtectedRoute allowedRoles={['secretaria', 'diretora', 'ti_admin']}>
            <SecretariaDashboard />
          </ProtectedRoute>
        }
      />

      {/* Diretora Routes */}
      <Route
        path="/diretora"
        element={
          <ProtectedRoute allowedRoles={['diretora', 'ti_admin']}>
            <DiretoraDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/diretora/indicadores"
        element={
          <ProtectedRoute allowedRoles={['diretora', 'ti_admin']}>
            <DiretoraDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/diretora/auditoria"
        element={
          <ProtectedRoute allowedRoles={['diretora', 'ti_admin']}>
            <DiretoraDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/diretora/relatorios"
        element={
          <ProtectedRoute allowedRoles={['diretora', 'ti_admin']}>
            <DiretoraDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/diretora/gestao"
        element={
          <ProtectedRoute allowedRoles={['diretora', 'ti_admin']}>
            <SecretariaDashboard />
          </ProtectedRoute>
        }
      />

      {/* TI Admin Routes */}
      <Route
        path="/ti"
        element={
          <ProtectedRoute allowedRoles={['ti_admin']}>
            <TIDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/ti/usuarios"
        element={
          <ProtectedRoute allowedRoles={['ti_admin']}>
            <TIDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/ti/permissoes"
        element={
          <ProtectedRoute allowedRoles={['ti_admin']}>
            <TIDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/ti/configuracoes"
        element={
          <ProtectedRoute allowedRoles={['ti_admin']}>
            <TIDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/ti/logs"
        element={
          <ProtectedRoute allowedRoles={['ti_admin']}>
            <TIDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/ti/manutencao"
        element={
          <ProtectedRoute allowedRoles={['ti_admin']}>
            <TIDashboard />
          </ProtectedRoute>
        }
      />

      {/* Catch all - 404 */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
      <Toaster position="top-right" />
    </AuthProvider>
  );
}

export default App;
