import { useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  BookOpen, 
  Search, 
  GraduationCap, 
  Clock, 
  ChevronRight,
  MessageSquare,
  FileText,
  PlayCircle,
  User
} from 'lucide-react';
import { mockDisciplinas, mockProfessoresLista, mockChatMessages } from '@/data/mockData';
import { Link } from 'react-router-dom';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

export default function Disciplinas() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProfessor, setSelectedProfessor] = useState<string | null>(null);
  const [messageText, setMessageText] = useState('');

  const filteredDisciplinas = mockDisciplinas.filter(d => 
    d.nome.toLowerCase().includes(searchQuery.toLowerCase()) ||
    d.codigo.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredProfessores = mockProfessoresLista.filter(p =>
    p.nome.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.disciplina.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">Disciplinas</h1>
            <p className="text-muted-foreground">Aceda às suas disciplinas e materiais de estudo</p>
          </div>
          <div className="relative max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Pesquisar disciplina ou professor..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        <Tabs defaultValue="disciplinas" className="space-y-6">
          <TabsList>
            <TabsTrigger value="disciplinas">Disciplinas</TabsTrigger>
            <TabsTrigger value="professores">Professores</TabsTrigger>
          </TabsList>

          <TabsContent value="disciplinas" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredDisciplinas.map((disciplina) => (
                <Card key={disciplina.id} className="hover:shadow-md transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="p-2 bg-primary/10 rounded-lg">
                        <BookOpen className="h-5 w-5 text-primary" />
                      </div>
                      <Badge variant="outline">{disciplina.codigo}</Badge>
                    </div>
                    <CardTitle className="text-lg mt-2">{disciplina.nome}</CardTitle>
                    <CardDescription>{disciplina.descricao}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <User className="h-4 w-4" />
                      <span>{disciplina.professor_nome || 'Professor não atribuído'}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Clock className="h-4 w-4" />
                      <span>{disciplina.carga_horaria}h/ano</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <FileText className="h-4 w-4" />
                      <span>{disciplina.temas?.length || 0} temas</span>
                    </div>
                    <Button className="w-full" asChild>
                      <Link to={`/estudante/disciplinas/${disciplina.id}`}>
                        Aceder à Disciplina
                        <ChevronRight className="h-4 w-4 ml-2" />
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="professores" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredProfessores.map((professor) => (
                <Card key={professor.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={professor.foto} />
                        <AvatarFallback>{professor.nome.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-medium truncate">{professor.nome}</h3>
                        <p className="text-sm text-muted-foreground">{professor.disciplina}</p>
                        <div className="flex items-center gap-2 mt-2">
                          <div className={cn(
                            'w-2 h-2 rounded-full',
                            professor.online ? 'bg-green-500' : 'bg-gray-400'
                          )} />
                          <span className="text-xs text-muted-foreground">
                            {professor.online ? 'Online' : 'Offline'}
                          </span>
                        </div>
                      </div>
                    </div>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button 
                          variant="outline" 
                          className="w-full mt-4"
                          onClick={() => setSelectedProfessor(professor.id)}
                        >
                          <MessageSquare className="h-4 w-4 mr-2" />
                          Enviar Mensagem
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-md">
                        <DialogHeader>
                          <DialogTitle>Chat com {professor.nome}</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4 pt-4">
                          <ScrollArea className="h-64 border rounded-lg p-4">
                            <div className="space-y-3">
                              {mockChatMessages.map((msg) => (
                                <div 
                                  key={msg.id} 
                                  className={cn(
                                    'flex flex-col max-w-[80%]',
                                    msg.remetente_id === 'u1' ? 'ml-auto items-end' : 'items-start'
                                  )}
                                >
                                  <div className={cn(
                                    'p-3 rounded-lg text-sm',
                                    msg.remetente_id === 'u1' 
                                      ? 'bg-primary text-primary-foreground' 
                                      : 'bg-muted'
                                  )}>
                                    {msg.conteudo}
                                  </div>
                                  <span className="text-xs text-muted-foreground mt-1">
                                    {new Date(msg.data_envio).toLocaleTimeString('pt-AO', { 
                                      hour: '2-digit', 
                                      minute: '2-digit' 
                                    })}
                                  </span>
                                </div>
                              ))}
                            </div>
                          </ScrollArea>
                          <div className="flex gap-2">
                            <Input 
                              placeholder="Escreva sua mensagem..."
                              value={messageText}
                              onChange={(e) => setMessageText(e.target.value)}
                            />
                            <Button>Enviar</Button>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}

import { cn } from '@/lib/utils';
