import { useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Clock,
  MapPin,
  BookOpen,
  User
} from 'lucide-react';
import { mockHorarios, mockAulas } from '@/data/mockData';
import { cn } from '@/lib/utils';

const diasSemana = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
const diasSemanaCurto = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

export default function Calendario() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [view, setView] = useState<'semana' | 'mes'>('semana');

  // Navegação
  const navigateWeek = (direction: 'prev' | 'next') => {
    const newDate = new Date(currentDate);
    newDate.setDate(currentDate.getDate() + (direction === 'next' ? 7 : -7));
    setCurrentDate(newDate);
  };

  // Obter início da semana
  const getWeekStart = (date: Date) => {
    const d = new Date(date);
    const day = d.getDay();
    const diff = d.getDate() - day;
    return new Date(d.setDate(diff));
  };

  const weekStart = getWeekStart(currentDate);
  const weekDays = Array.from({ length: 6 }, (_, i) => {
    const day = new Date(weekStart);
    day.setDate(weekStart.getDate() + i);
    return day;
  });

  // Horários do dia
  const getHorariosDia = (diaSemana: number) => {
    return mockHorarios.filter(h => h.dia_semana === diaSemana).sort((a, b) => 
      a.hora_inicio.localeCompare(b.hora_inicio)
    );
  };

  // Formatar data
  const formatDate = (date: Date) => {
    return date.toLocaleDateString('pt-AO', { day: '2-digit', month: 'short' });
  };

  const isToday = (date: Date) => {
    const today = new Date();
    return date.toDateString() === today.toDateString();
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">Calendário</h1>
            <p className="text-muted-foreground">Visualize seu horário de aulas</p>
          </div>
          <div className="flex items-center gap-2">
            <Tabs value={view} onValueChange={(v) => setView(v as 'semana' | 'mes')}>
              <TabsList>
                <TabsTrigger value="semana">Semana</TabsTrigger>
                <TabsTrigger value="mes">Mês</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-between">
          <Button variant="outline" size="sm" onClick={() => navigateWeek('prev')}>
            <ChevronLeft className="h-4 w-4 mr-2" />
            Semana Anterior
          </Button>
          <div className="text-center">
            <h2 className="text-lg font-semibold">
              Semana de {formatDate(weekDays[0])} a {formatDate(weekDays[5])}
            </h2>
            <p className="text-sm text-muted-foreground">Ano Letivo 2024/2025</p>
          </div>
          <Button variant="outline" size="sm" onClick={() => navigateWeek('next')}>
            Próxima Semana
            <ChevronRight className="h-4 w-4 ml-2" />
          </Button>
        </div>

        {/* Weekly Schedule */}
        <div className="grid grid-cols-1 lg:grid-cols-6 gap-4">
          {weekDays.slice(1).map((day, index) => {
            const diaSemana = index + 1;
            const horariosDia = getHorariosDia(diaSemana);
            
            return (
              <Card key={day.toISOString()} className={cn(
                'min-h-[400px]',
                isToday(day) && 'ring-2 ring-primary'
              )}>
                <CardHeader className="pb-3">
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground">{diasSemanaCurto[diaSemana]}</p>
                    <p className={cn(
                      'text-lg font-bold',
                      isToday(day) ? 'text-primary' : ''
                    )}>
                      {day.getDate()}
                    </p>
                    {isToday(day) && (
                      <Badge variant="secondary" className="mt-1">Hoje</Badge>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-2">
                  {horariosDia.length > 0 ? (
                    horariosDia.map((horario, idx) => (
                      <div 
                        key={horario.id}
                        className="p-2 rounded-lg bg-primary/5 border border-primary/10 text-sm"
                      >
                        <div className="flex items-center gap-1 text-xs text-muted-foreground mb-1">
                          <Clock className="h-3 w-3" />
                          {horario.hora_inicio} - {horario.hora_fim}
                        </div>
                        <p className="font-medium text-xs">{horario.disciplina_nome}</p>
                        <div className="flex items-center gap-1 text-xs text-muted-foreground mt-1">
                          <MapPin className="h-3 w-3" />
                          {horario.sala}
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8 text-muted-foreground text-sm">
                      Sem aulas
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Legend */}
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Legenda</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-4 text-sm">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-primary/20 border border-primary" />
                <span>Aula Normal</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-green-100 border border-green-300" />
                <span>Aula Realizada</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-amber-100 border border-amber-300" />
                <span>Aula Cancelada</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-blue-100 border border-blue-300" />
                <span>Teste/Exame</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Interval Info */}
        <Card className="bg-amber-50 border-amber-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Clock className="h-5 w-5 text-amber-600" />
              <div>
                <p className="font-medium text-amber-900">Intervalos</p>
                <p className="text-sm text-amber-700">
                  Manhã: 09:50 - 10:10 | Tarde: 15:30 - 15:50
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
