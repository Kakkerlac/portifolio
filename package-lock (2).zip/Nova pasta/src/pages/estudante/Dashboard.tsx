import { useAuth } from '@/context/AuthContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { StatCard } from '@/components/common/StatCard';
import { ChartCard } from '@/components/common/ChartCard';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Progress } from '@/components/ui/progress';
import { 
  BookOpen, 
  Calendar, 
  FileText, 
  Award, 
  Clock, 
  Bell, 
  TrendingUp, 
  TrendingDown,
  Plus,
  MessageSquare,
  AlertCircle,
  CheckCircle2,
  GraduationCap,
  ChevronRight
} from 'lucide-react';
import { mockAulas, mockAvisos, mockNotas, mockDisciplinas, mockTestes, mockBlocoNotas } from '@/data/mockData';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line
} from 'recharts';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';

export default function EstudanteDashboard() {
  const { user } = useAuth();
  const [showNewNoteDialog, setShowNewNoteDialog] = useState(false);
  const [newNote, setNewNote] = useState({ content: '', etiquetas: '' });

  // Dados para gráfico de desempenho
  const notasPorDisciplina = mockDisciplinas.slice(0, 6).map(d => {
    const notasDisciplina = mockNotas.filter(n => n.disciplina_id === d.id);
    const media = notasDisciplina.length > 0 
      ? notasDisciplina.reduce((acc, n) => acc + n.nota, 0) / notasDisciplina.length 
      : 0;
    return {
      name: d.nome.substring(0, 3),
      nota: Number(media.toFixed(1)),
      fullName: d.nome
    };
  });

  // Dados para gráfico de evolução trimestral
  const evolucaoTrimestral = [
    { trimestre: '1º Trim', media: 13.5 },
    { trimestre: '2º Trim', media: 14.2 },
    { trimestre: '3º Trim', media: 0 },
  ];

  // Estatísticas
  const totalNotas = mockNotas.length;
  const notasPositivas = mockNotas.filter(n => n.nota >= 10).length;
  const notasNegativas = mockNotas.filter(n => n.nota < 10).length;
  const mediaGeral = mockNotas.length > 0 
    ? (mockNotas.reduce((acc, n) => acc + n.nota, 0) / mockNotas.length).toFixed(1)
    : '0.0';

  // Aulas de hoje
  const aulasHoje = mockAulas.filter(a => a.data === '2025-02-20');

  // Próximos testes
  const proximosTestes = mockTestes.filter(t => t.status === 'publicado');

  // Avisos não lidos
  const avisosNaoLidos = mockAvisos.filter(a => !a.lido);

  const COLORS = ['#10B981', '#EF4444'];

  return (
    <DashboardLayout>
      {/* Welcome Section */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Bem-vindo, {user?.nome_completo.split(' ')[0]}!</h1>
        <p className="text-muted-foreground">Aqui está o resumo da sua atividade académica</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard
          title="Média Geral"
          value={mediaGeral}
          description="de 20 valores"
          icon={Award}
          trend="up"
          trendValue="+0.7"
          variant="primary"
        />
        <StatCard
          title="Disciplinas"
          value={mockDisciplinas.length}
          description="este ano letivo"
          icon={BookOpen}
          variant="default"
        />
        <StatCard
          title="Notas Positivas"
          value={notasPositivas}
          description={`de ${totalNotas} avaliações`}
          icon={CheckCircle2}
          trend="up"
          trendValue={`${((notasPositivas/totalNotas)*100).toFixed(0)}%`}
          variant="success"
        />
        <StatCard
          title="Notas Negativas"
          value={notasNegativas}
          description={`de ${totalNotas} avaliações`}
          icon={AlertCircle}
          trend="down"
          trendValue={`${((notasNegativas/totalNotas)*100).toFixed(0)}%`}
          variant="danger"
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column - 2/3 */}
        <div className="lg:col-span-2 space-y-6">
          {/* Aulas de Hoje */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  Aulas de Hoje
                </CardTitle>
                <CardDescription>Quarta-feira, 20 de Fevereiro de 2025</CardDescription>
              </div>
              <Button variant="outline" size="sm" asChild>
                <Link to="/estudante/calendario">Ver Calendário</Link>
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {aulasHoje.map((aula, index) => (
                  <div 
                    key={aula.id} 
                    className="flex items-center gap-4 p-3 rounded-lg border hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex flex-col items-center min-w-[60px]">
                      <span className="text-sm font-medium">{aula.hora_inicio}</span>
                      <span className="text-xs text-muted-foreground">{aula.hora_fim}</span>
                    </div>
                    <div className="w-px h-10 bg-border" />
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{aula.disciplina_nome}</span>
                        {aula.status === 'realizada' && (
                          <Badge variant="secondary" className="text-xs">Realizada</Badge>
                        )}
                        {aula.status === 'agendada' && (
                          <Badge variant="outline" className="text-xs">Agendada</Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">Tema: {aula.tema}</p>
                    </div>
                    <div className="text-sm text-muted-foreground">{aula.sala}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Gráfico de Desempenho */}
          <ChartCard 
            title="Desempenho por Disciplina" 
            description="Média das notas em cada disciplina"
          >
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={notasPorDisciplina}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis domain={[0, 20]} />
                  <Tooltip 
                    formatter={(value: number) => [value, 'Média']}
                    labelFormatter={(label) => {
                      const item = notasPorDisciplina.find(n => n.name === label);
                      return item?.fullName || label;
                    }}
                  />
                  <Bar dataKey="nota" fill="#4F46E5" radius={[4, 4, 0, 0]}>
                    {notasPorDisciplina.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.nota >= 10 ? '#10B981' : '#EF4444'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </ChartCard>

          {/* Evolução Trimestral */}
          <ChartCard title="Evolução do Desempenho" description="Média geral por trimestre">
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={evolucaoTrimestral}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="trimestre" />
                  <YAxis domain={[0, 20]} />
                  <Tooltip formatter={(value: number) => [value, 'Média']} />
                  <Line 
                    type="monotone" 
                    dataKey="media" 
                    stroke="#4F46E5" 
                    strokeWidth={3}
                    dot={{ fill: '#4F46E5', strokeWidth: 2, r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </ChartCard>
        </div>

        {/* Right Column - 1/3 */}
        <div className="space-y-6">
          {/* Avisos */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg flex items-center gap-2">
                <Bell className="h-5 w-5 text-amber-500" />
                Avisos
                {avisosNaoLidos.length > 0 && (
                  <Badge variant="destructive" className="text-xs">{avisosNaoLidos.length}</Badge>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-48">
                <div className="space-y-3">
                  {mockAvisos.map((aviso) => (
                    <div key={aviso.id} className="p-3 rounded-lg border hover:bg-muted/50 transition-colors">
                      <div className="flex items-start gap-2">
                        <div className={cn(
                          'w-2 h-2 rounded-full mt-2',
                          aviso.prioridade === 'urgente' && 'bg-red-500',
                          aviso.prioridade === 'alta' && 'bg-amber-500',
                          aviso.prioridade === 'media' && 'bg-blue-500',
                          aviso.prioridade === 'baixa' && 'bg-gray-400'
                        )} />
                        <div className="flex-1">
                          <p className="text-sm font-medium">{aviso.titulo}</p>
                          <p className="text-xs text-muted-foreground line-clamp-2">{aviso.conteudo}</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {new Date(aviso.data_publicacao).toLocaleDateString('pt-AO')}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>

          {/* Próximos Testes */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <FileText className="h-5 w-5 text-primary" />
                Próximos Testes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {proximosTestes.length > 0 ? (
                  proximosTestes.map((teste) => (
                    <div key={teste.id} className="p-3 rounded-lg border hover:bg-muted/50 transition-colors">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-sm">{teste.titulo}</span>
                        <Badge variant="outline" className="text-xs">{teste.disciplina_nome}</Badge>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">
                        {new Date(teste.data_inicio).toLocaleDateString('pt-AO')} • {teste.duracao_minutos} min
                      </p>
                      <Button size="sm" variant="outline" className="w-full mt-2" asChild>
                        <Link to="/estudante/testes">Ver Detalhes</Link>
                      </Button>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    Nenhum teste agendado
                  </p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Bloco de Notas */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg flex items-center gap-2">
                <MessageSquare className="h-5 w-5 text-primary" />
                Bloco de Notas
              </CardTitle>
              <Dialog open={showNewNoteDialog} onOpenChange={setShowNewNoteDialog}>
                <DialogTrigger asChild>
                  <Button size="icon" variant="ghost">
                    <Plus className="h-4 w-4" />
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Nova Nota</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 pt-4">
                    <div>
                      <Label>Conteúdo</Label>
                      <Textarea 
                        value={newNote.content}
                        onChange={(e) => setNewNote({ ...newNote, content: e.target.value })}
                        placeholder="Escreva sua nota..."
                        rows={4}
                      />
                    </div>
                    <div>
                      <Label>Etiquetas (separadas por vírgula)</Label>
                      <Input 
                        value={newNote.etiquetas}
                        onChange={(e) => setNewNote({ ...newNote, etiquetas: e.target.value })}
                        placeholder="ex: tarefa, importante, matemática"
                      />
                    </div>
                    <Button 
                      className="w-full" 
                      onClick={() => {
                        // Aqui adicionaria a nota
                        setShowNewNoteDialog(false);
                        setNewNote({ content: '', etiquetas: '' });
                      }}
                    >
                      Guardar Nota
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-40">
                <div className="space-y-2">
                  {mockBlocoNotas.map((nota) => (
                    <div key={nota.id} className="p-2 rounded-lg bg-muted/50 text-sm">
                      <p className="line-clamp-2">{nota.conteudo}</p>
                      <div className="flex items-center gap-1 mt-1">
                        {nota.etiquetas.map((tag, i) => (
                          <Badge key={i} variant="secondary" className="text-xs">{tag}</Badge>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>

          {/* Distribuição de Notas */}
          <ChartCard title="Distribuição de Notas" description="Positivas vs Negativas">
            <div className="h-40">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={[
                      { name: 'Positivas', value: notasPositivas },
                      { name: 'Negativas', value: notasNegativas }
                    ]}
                    cx="50%"
                    cy="50%"
                    innerRadius={40}
                    outerRadius={60}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    <Cell fill="#10B981" />
                    <Cell fill="#EF4444" />
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex justify-center gap-4 mt-2">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-green-500" />
                <span className="text-sm text-muted-foreground">Positivas ({notasPositivas})</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-red-500" />
                <span className="text-sm text-muted-foreground">Negativas ({notasNegativas})</span>
              </div>
            </div>
          </ChartCard>
        </div>
      </div>
    </DashboardLayout>
  );
}

import { cn } from '@/lib/utils';
