import { useParams } from 'react-router-dom';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { 
  BookOpen, 
  ArrowLeft, 
  PlayCircle, 
  FileText, 
  ExternalLink,
  MessageSquare,
  CheckCircle2,
  Clock,
  User,
  Send,
  Star
} from 'lucide-react';
import { mockDisciplinas, mockNotas, mockChatMessages } from '@/data/mockData';
import { Link } from 'react-router-dom';
import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';

export default function DisciplinaDetail() {
  const { id } = useParams<{ id: string }>();
  const [messageText, setMessageText] = useState('');
  const [rating, setRating] = useState(0);
  const [showRatingDialog, setShowRatingDialog] = useState(false);

  const disciplina = mockDisciplinas.find(d => d.id === id);
  const notasDisciplina = mockNotas.filter(n => n.disciplina_id === id);
  const mediaNotas = notasDisciplina.length > 0
    ? (notasDisciplina.reduce((acc, n) => acc + n.nota, 0) / notasDisciplina.length).toFixed(1)
    : '0.0';

  if (!disciplina) {
    return (
      <DashboardLayout>
        <div className="flex flex-col items-center justify-center min-h-[400px]">
          <BookOpen className="h-16 w-16 text-muted-foreground mb-4" />
          <h2 className="text-xl font-semibold">Disciplina não encontrada</h2>
          <p className="text-muted-foreground mb-4">A disciplina que procura não existe ou foi removida.</p>
          <Button asChild>
            <Link to="/estudante/disciplinas">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Voltar às Disciplinas
            </Link>
          </Button>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Breadcrumb & Header */}
        <div className="flex flex-col gap-4">
          <Button variant="ghost" className="w-fit -ml-4" asChild>
            <Link to="/estudante/disciplinas">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Voltar às Disciplinas
            </Link>
          </Button>
          
          <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <BookOpen className="h-6 w-6 text-primary" />
                </div>
                <Badge variant="outline" className="text-sm">{disciplina.codigo}</Badge>
              </div>
              <h1 className="text-3xl font-bold">{disciplina.nome}</h1>
              <p className="text-muted-foreground mt-1">{disciplina.descricao}</p>
            </div>
            <div className="flex gap-2">
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline">
                    <MessageSquare className="h-4 w-4 mr-2" />
                    Chat com Professor
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-lg">
                  <DialogHeader>
                    <DialogTitle>Chat com {disciplina.professor_nome}</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 pt-4">
                    <ScrollArea className="h-64 border rounded-lg p-4">
                      <div className="space-y-3">
                        {mockChatMessages.map((msg) => (
                          <div 
                            key={msg.id} 
                            className={cn(
                              'flex flex-col max-w-[80%]',
                              msg.remetente_id === 'u1' ? 'ml-auto items-end' : 'items-start'
                            )}
                          >
                            <div className={cn(
                              'p-3 rounded-lg text-sm',
                              msg.remetente_id === 'u1' 
                                ? 'bg-primary text-primary-foreground' 
                                : 'bg-muted'
                            )}>
                              {msg.conteudo}
                            </div>
                            <span className="text-xs text-muted-foreground mt-1">
                              {new Date(msg.data_envio).toLocaleTimeString('pt-AO', { 
                                hour: '2-digit', 
                                minute: '2-digit' 
                              })}
                            </span>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                    <div className="flex gap-2">
                      <Input 
                        placeholder="Escreva sua mensagem..."
                        value={messageText}
                        onChange={(e) => setMessageText(e.target.value)}
                      />
                      <Button>
                        <Send className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
              
              <Dialog open={showRatingDialog} onOpenChange={setShowRatingDialog}>
                <DialogTrigger asChild>
                  <Button variant="outline">
                    <Star className="h-4 w-4 mr-2" />
                    Avaliar Professor
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Avaliar Professor</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 pt-4">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-4">
                        De 1 a 10, avalie o professor {disciplina.professor_nome}
                      </p>
                      <div className="flex justify-center gap-2">
                        {Array.from({ length: 10 }).map((_, i) => (
                          <Button
                            key={i}
                            variant={rating === i + 1 ? 'default' : 'outline'}
                            size="sm"
                            onClick={() => setRating(i + 1)}
                            className="w-8 h-8 p-0"
                          >
                            {i + 1}
                          </Button>
                        ))}
                      </div>
                      {rating > 0 && (
                        <p className="mt-4 text-lg font-medium">
                          Sua avaliação: {rating}/10
                        </p>
                      )}
                    </div>
                    <div>
                      <Label>Comentário (opcional)</Label>
                      <Textarea placeholder="Deixe seu comentário sobre o professor..." />
                    </div>
                    <Button 
                      className="w-full" 
                      disabled={rating === 0}
                      onClick={() => setShowRatingDialog(false)}
                    >
                      Enviar Avaliação
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>

        {/* Info Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <User className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Professor</p>
                  <p className="font-medium">{disciplina.professor_nome}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <Clock className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Carga Horária</p>
                  <p className="font-medium">{disciplina.carga_horaria}h/ano</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <BookOpen className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Temas</p>
                  <p className="font-medium">{disciplina.temas?.length || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Sua Média</p>
                  <p className={cn(
                    'font-medium',
                    Number(mediaNotas) >= 10 ? 'text-green-600' : 'text-red-600'
                  )}>
                    {mediaNotas}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Content Tabs */}
        <Tabs defaultValue="temas" className="space-y-6">
          <TabsList>
            <TabsTrigger value="temas">Temas e Conteúdos</TabsTrigger>
            <TabsTrigger value="tarefas">Tarefas</TabsTrigger>
            <TabsTrigger value="materiais">Materiais</TabsTrigger>
          </TabsList>

          <TabsContent value="temas" className="space-y-4">
            {disciplina.temas && disciplina.temas.length > 0 ? (
              <Accordion type="single" collapsible className="space-y-2">
                {disciplina.temas.map((tema) => (
                  <AccordionItem key={tema.id} value={tema.id} className="border rounded-lg px-4">
                    <AccordionTrigger className="hover:no-underline py-4">
                      <div className="flex items-center gap-3 text-left">
                        <div className="p-2 bg-primary/10 rounded-lg">
                          <BookOpen className="h-4 w-4 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium">{tema.titulo}</p>
                          <p className="text-sm text-muted-foreground">{tema.subtitulo}</p>
                        </div>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="pb-4">
                      <div className="pl-12 space-y-3">
                        <h4 className="text-sm font-medium">Material de Apoio:</h4>
                        {tema.materiais.map((material) => (
                          <div 
                            key={material.id} 
                            className="flex items-center gap-3 p-3 rounded-lg border hover:bg-muted/50 transition-colors"
                          >
                            {material.tipo === 'video' && <PlayCircle className="h-4 w-4 text-red-500" />}
                            {material.tipo === 'pdf' && <FileText className="h-4 w-4 text-blue-500" />}
                            {material.tipo === 'link' && <ExternalLink className="h-4 w-4 text-green-500" />}
                            <div className="flex-1">
                              <p className="text-sm font-medium">{material.titulo}</p>
                              <p className="text-xs text-muted-foreground">{material.descricao}</p>
                            </div>
                            <Button variant="ghost" size="sm" asChild>
                              <a href={material.url} target="_blank" rel="noopener noreferrer">
                                <ExternalLink className="h-4 w-4" />
                              </a>
                            </Button>
                          </div>
                        ))}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            ) : (
              <Card>
                <CardContent className="p-8 text-center">
                  <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium">Nenhum tema disponível</h3>
                  <p className="text-muted-foreground">Os temas desta disciplina ainda não foram publicados.</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="tarefas" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Tarefas Pendentes</CardTitle>
                <CardDescription>Lista de tarefas e trabalhos a entregar</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center gap-4 p-4 rounded-lg border">
                    <div className="p-2 bg-amber-100 rounded-lg">
                      <FileText className="h-5 w-5 text-amber-600" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium">Terminar os exercícios dados em aula</p>
                      <p className="text-sm text-muted-foreground">Prazo: 25/02/2025</p>
                    </div>
                    <Badge>Pendente</Badge>
                  </div>
                  <div className="flex items-center gap-4 p-4 rounded-lg border">
                    <div className="p-2 bg-amber-100 rounded-lg">
                      <FileText className="h-5 w-5 text-amber-600" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium">Fazer os exercícios das páginas 33, 34, 35 e 36 do manual</p>
                      <p className="text-sm text-muted-foreground">Prazo: 28/02/2025</p>
                    </div>
                    <Badge>Pendente</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="materiais" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Todos os Materiais</CardTitle>
                <CardDescription>Videos, PDFs e links de apoio</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {disciplina.temas?.flatMap(t => t.materiais).map((material, idx) => (
                    <div 
                      key={idx}
                      className="flex items-center gap-4 p-4 rounded-lg border hover:bg-muted/50 transition-colors"
                    >
                      {material.tipo === 'video' && <PlayCircle className="h-5 w-5 text-red-500" />}
                      {material.tipo === 'pdf' && <FileText className="h-5 w-5 text-blue-500" />}
                      {material.tipo === 'link' && <ExternalLink className="h-5 w-5 text-green-500" />}
                      <div className="flex-1">
                        <p className="font-medium">{material.titulo}</p>
                        <p className="text-sm text-muted-foreground">{material.descricao}</p>
                      </div>
                      <Button variant="outline" size="sm" asChild>
                        <a href={material.url} target="_blank" rel="noopener noreferrer">
                          Aceder
                        </a>
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
