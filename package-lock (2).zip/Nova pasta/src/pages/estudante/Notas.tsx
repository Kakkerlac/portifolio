import { useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { 
  FileText, 
  TrendingUp, 
  TrendingDown, 
  Award,
  Calendar,
  User,
  Filter,
  Download
} from 'lucide-react';
import { mockNotas, mockDisciplinas } from '@/data/mockData';
import { cn } from '@/lib/utils';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell
} from 'recharts';

export default function Notas() {
  const [trimestreSelecionado, setTrimestreSelecionState] = useState<'1' | '2' | '3'>('1');

  // Filtrar notas por trimestre
  const notasFiltradas = mockNotas.filter(n => n.trimestre === Number(trimestreSelecionado));

  // Agrupar notas por disciplina
  const notasPorDisciplina = mockDisciplinas.map(d => {
    const notasDisciplina = mockNotas.filter(n => n.disciplina_id === d.id);
    const notasPorTrimestre = {
      1: notasDisciplina.filter(n => n.trimestre === 1),
      2: notasDisciplina.filter(n => n.trimestre === 2),
      3: notasDisciplina.filter(n => n.trimestre === 3)
    };
    
    const medias = {
      1: notasPorTrimestre[1].length > 0 
        ? (notasPorTrimestre[1].reduce((acc, n) => acc + n.nota, 0) / notasPorTrimestre[1].length).toFixed(1)
        : '-',
      2: notasPorTrimestre[2].length > 0 
        ? (notasPorTrimestre[2].reduce((acc, n) => acc + n.nota, 0) / notasPorTrimestre[2].length).toFixed(1)
        : '-',
      3: notasPorTrimestre[3].length > 0 
        ? (notasPorTrimestre[3].reduce((acc, n) => acc + n.nota, 0) / notasPorTrimestre[3].length).toFixed(1)
        : '-'
    };

    const mediaFinal = notasDisciplina.length > 0
      ? (notasDisciplina.reduce((acc, n) => acc + n.nota, 0) / notasDisciplina.length).toFixed(1)
      : '-';

    return {
      disciplina: d.nome,
      professor: d.professor_nome,
      trimestre1: medias[1],
      trimestre2: medias[2],
      trimestre3: medias[3],
      mediaFinal
    };
  });

  // Dados para gráfico
  const dadosGrafico = notasPorDisciplina
    .filter(d => d.mediaFinal !== '-')
    .map(d => ({
      name: d.disciplina.substring(0, 8) + '...',
      media: Number(d.mediaFinal),
      fullName: d.disciplina
    }));

  // Estatísticas
  const todasNotas = mockNotas;
  const mediaGeral = todasNotas.length > 0
    ? (todasNotas.reduce((acc, n) => acc + n.nota, 0) / todasNotas.length).toFixed(1)
    : '0.0';
  const notasPositivas = todasNotas.filter(n => n.nota >= 10).length;
  const notasNegativas = todasNotas.filter(n => n.nota < 10).length;

  const getNotaColor = (nota: string) => {
    if (nota === '-') return 'text-muted-foreground';
    const num = Number(nota);
    if (num >= 14) return 'text-green-600 font-medium';
    if (num >= 10) return 'text-blue-600';
    return 'text-red-600 font-medium';
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">Notas</h1>
            <p className="text-muted-foreground">Consulte suas notas e avaliações</p>
          </div>
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Exportar Boletim
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <Award className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-sm text-muted-foreground">Média Geral</p>
                  <p className={cn('text-xl font-bold', getNotaColor(mediaGeral))}>
                    {mediaGeral}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <TrendingUp className="h-5 w-5 text-green-500" />
                <div>
                  <p className="text-sm text-muted-foreground">Notas Positivas</p>
                  <p className="text-xl font-bold text-green-600">{notasPositivas}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <TrendingDown className="h-5 w-5 text-red-500" />
                <div>
                  <p className="text-sm text-muted-foreground">Notas Negativas</p>
                  <p className="text-xl font-bold text-red-600">{notasNegativas}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <FileText className="h-5 w-5 text-blue-500" />
                <div>
                  <p className="text-sm text-muted-foreground">Total de Avaliações</p>
                  <p className="text-xl font-bold">{todasNotas.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="mapa" className="space-y-6">
          <TabsList>
            <TabsTrigger value="mapa">Mapa de Notas</TabsTrigger>
            <TabsTrigger value="historico">Histórico Detalhado</TabsTrigger>
            <TabsTrigger value="grafico">Gráficos</TabsTrigger>
          </TabsList>

          <TabsContent value="mapa" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Mapa Trimestral de Notas</CardTitle>
                <CardDescription>Visualize suas notas por trimestre e disciplina</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Disciplina</TableHead>
                      <TableHead>Professor</TableHead>
                      <TableHead className="text-center">I Trimestre</TableHead>
                      <TableHead className="text-center">II Trimestre</TableHead>
                      <TableHead className="text-center">III Trimestre</TableHead>
                      <TableHead className="text-center">Média Final</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {notasPorDisciplina.map((item, index) => (
                      <TableRow key={index}>
                        <TableCell className="font-medium">{item.disciplina}</TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {item.professor}
                        </TableCell>
                        <TableCell className={cn('text-center', getNotaColor(item.trimestre1))}>
                          {item.trimestre1}
                        </TableCell>
                        <TableCell className={cn('text-center', getNotaColor(item.trimestre2))}>
                          {item.trimestre2}
                        </TableCell>
                        <TableCell className={cn('text-center', getNotaColor(item.trimestre3))}>
                          {item.trimestre3}
                        </TableCell>
                        <TableCell className={cn('text-center font-bold', getNotaColor(item.mediaFinal))}>
                          {item.mediaFinal}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="historico" className="space-y-6">
            <Tabs value={trimestreSelecionado} onValueChange={(v) => setTrimestreSelecionState(v as '1' | '2' | '3')}>
              <TabsList>
                <TabsTrigger value="1">I Trimestre</TabsTrigger>
                <TabsTrigger value="2">II Trimestre</TabsTrigger>
                <TabsTrigger value="3">III Trimestre</TabsTrigger>
              </TabsList>

              {['1', '2', '3'].map((trimestre) => (
                <TabsContent key={trimestre} value={trimestre}>
                  <Card>
                    <CardHeader>
                      <CardTitle>Notas do {trimestre}º Trimestre</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {mockNotas.filter(n => n.trimestre === Number(trimestre)).length > 0 ? (
                        <div className="space-y-3">
                          {mockNotas
                            .filter(n => n.trimestre === Number(trimestre))
                            .map((nota) => (
                              <div 
                                key={nota.id} 
                                className="flex items-center justify-between p-4 rounded-lg border hover:bg-muted/50 transition-colors"
                              >
                                <div className="flex items-center gap-4">
                                  <div className={cn(
                                    'w-12 h-12 rounded-lg flex items-center justify-center',
                                    nota.nota >= 10 ? 'bg-green-100' : 'bg-red-100'
                                  )}>
                                    <span className={cn(
                                      'text-lg font-bold',
                                      nota.nota >= 10 ? 'text-green-600' : 'text-red-600'
                                    )}>
                                      {nota.nota}
                                    </span>
                                  </div>
                                  <div>
                                    <p className="font-medium">{nota.disciplina_nome}</p>
                                    <div className="flex items-center gap-3 text-sm text-muted-foreground">
                                      <span className="flex items-center gap-1">
                                        <User className="h-3 w-3" />
                                        {nota.professor_nome}
                                      </span>
                                      <span className="flex items-center gap-1">
                                        <Calendar className="h-3 w-3" />
                                        {new Date(nota.data_avaliacao).toLocaleDateString('pt-AO')}
                                      </span>
                                    </div>
                                  </div>
                                </div>
                                <div className="text-right">
                                  <Badge variant="outline">{nota.tipo_avaliacao}</Badge>
                                  {nota.observacao && (
                                    <p className="text-sm text-muted-foreground mt-1">{nota.observacao}</p>
                                  )}
                                </div>
                              </div>
                            ))}
                        </div>
                      ) : (
                        <div className="text-center py-8 text-muted-foreground">
                          Nenhuma nota registrada neste trimestre
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>
              ))}
            </Tabs>
          </TabsContent>

          <TabsContent value="grafico" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Desempenho por Disciplina</CardTitle>
                <CardDescription>Média final em cada disciplina</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={dadosGrafico} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" domain={[0, 20]} />
                      <YAxis dataKey="name" type="category" width={100} />
                      <Tooltip 
                        formatter={(value: number) => [value, 'Média']}
                        labelFormatter={(label) => {
                          const item = dadosGrafico.find(d => d.name === label);
                          return item?.fullName || label;
                        }}
                      />
                      <Bar dataKey="media" radius={[0, 4, 4, 0]}>
                        {dadosGrafico.map((entry, index) => (
                          <Cell 
                            key={`cell-${index}`} 
                            fill={entry.media >= 10 ? '#10B981' : '#EF4444'} 
                          />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
