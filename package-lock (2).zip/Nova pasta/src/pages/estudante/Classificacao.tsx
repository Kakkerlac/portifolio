import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Award, 
  TrendingUp, 
  Star,
  Target,
  BarChart3,
  Calendar
} from 'lucide-react';
import { mockNotas, mockDisciplinas } from '@/data/mockData';
import { cn } from '@/lib/utils';
import {
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip
} from 'recharts';

export default function Classificacao() {
  // Calcular médias por disciplina
  const mediasPorDisciplina = mockDisciplinas.map(d => {
    const notasDisciplina = mockNotas.filter(n => n.disciplina_id === d.id);
    const media = notasDisciplina.length > 0
      ? notasDisciplina.reduce((acc, n) => acc + n.nota, 0) / notasDisciplina.length
      : 0;
    return {
      disciplina: d.nome,
      media: Number(media.toFixed(1)),
      fullName: d.nome
    };
  }).filter(d => d.media > 0);

  // Dados para gráfico radar
  const radarData = mediasPorDisciplina.map(d => ({
    subject: d.disciplina.substring(0, 10),
    A: d.media,
    fullMark: 20
  }));

  // Estatísticas gerais
  const todasNotas = mockNotas;
  const mediaGeral = todasNotas.length > 0
    ? (todasNotas.reduce((acc, n) => acc + n.nota, 0) / todasNotas.length)
    : 0;

  // Simular avaliações dos professores
  const avaliacoesProfessores = [
    { criterio: 'Assiduidade', nota: 18, peso: 20 },
    { criterio: 'Pontualidade', nota: 16, peso: 15 },
    { criterio: 'Participação', nota: 14, peso: 20 },
    { criterio: 'Comportamento', nota: 17, peso: 20 },
    { criterio: 'Desempenho', nota: Math.round(mediaGeral), peso: 25 }
  ];

  const mediaAvaliacao = avaliacoesProfessores.reduce((acc, a) => acc + (a.nota * a.peso / 100), 0);

  // Posição no ranking (simulado)
  const posicaoRanking = 8;
  const totalEstudantes = 32;

  // Melhorias em relação ao trimestre anterior
  const melhoria = 0.7;

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold">Classificação</h1>
          <p className="text-muted-foreground">Avaliação do seu desempenho académico</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <Award className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Média Final</p>
                  <p className={cn(
                    'text-2xl font-bold',
                    mediaGeral >= 10 ? 'text-green-600' : 'text-red-600'
                  )}>
                    {mediaGeral.toFixed(1)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-amber-100 rounded-lg">
                  <Star className="h-5 w-5 text-amber-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Avaliação Geral</p>
                  <p className="text-2xl font-bold text-amber-600">
                    {mediaAvaliacao.toFixed(1)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <Target className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Posição na Turma</p>
                  <p className="text-2xl font-bold text-blue-600">
                    {posicaoRanking}º
                  </p>
                  <p className="text-xs text-muted-foreground">de {totalEstudantes} estudantes</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className={cn(
                  'p-2 rounded-lg',
                  melhoria >= 0 ? 'bg-green-100' : 'bg-red-100'
                )}>
                  <TrendingUp className={cn(
                    'h-5 w-5',
                    melhoria >= 0 ? 'text-green-600' : 'text-red-600'
                  )} />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Evolução</p>
                  <p className={cn(
                    'text-2xl font-bold',
                    melhoria >= 0 ? 'text-green-600' : 'text-red-600'
                  )}>
                    {melhoria >= 0 ? '+' : ''}{melhoria.toFixed(1)}
                  </p>
                  <p className="text-xs text-muted-foreground">vs trimestre anterior</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Gráfico Radar - Desempenho por Disciplina */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Desempenho por Disciplina
              </CardTitle>
              <CardDescription>Visualização do seu desempenho em cada área</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart cx="50%" cy="50%" outerRadius="80%" data={radarData}>
                    <PolarGrid />
                    <PolarAngleAxis dataKey="subject" />
                    <PolarRadiusAxis angle={30} domain={[0, 20]} />
                    <Radar
                      name="Desempenho"
                      dataKey="A"
                      stroke="#4F46E5"
                      fill="#4F46E5"
                      fillOpacity={0.3}
                    />
                    <Tooltip />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Avaliação dos Professores */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Star className="h-5 w-5" />
                Avaliação dos Professores
              </CardTitle>
              <CardDescription>Critérios de avaliação do seu desempenho</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {avaliacoesProfessores.map((avaliacao) => (
                  <div key={avaliacao.criterio}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium">{avaliacao.criterio}</span>
                      <div className="flex items-center gap-2">
                        <span className={cn(
                          'text-sm font-bold',
                          avaliacao.nota >= 10 ? 'text-green-600' : 'text-red-600'
                        )}>
                          {avaliacao.nota}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          ({avaliacao.peso}%)
                        </span>
                      </div>
                    </div>
                    <Progress 
                      value={(avaliacao.nota / 20) * 100} 
                      className="h-2"
                    />
                  </div>
                ))}
              </div>
              <div className="mt-6 p-4 bg-muted rounded-lg">
                <div className="flex items-center justify-between">
                  <span className="font-medium">Média da Avaliação</span>
                  <span className={cn(
                    'text-xl font-bold',
                    mediaAvaliacao >= 10 ? 'text-green-600' : 'text-red-600'
                  )}>
                    {mediaAvaliacao.toFixed(1)}
                  </span>
                </div>
                <Progress 
                  value={(mediaAvaliacao / 20) * 100} 
                  className="h-3 mt-2"
                />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Gráfico de Barras - Comparação */}
        <Card>
          <CardHeader>
            <CardTitle>Comparativo de Desempenho</CardTitle>
            <CardDescription>Sua média comparada à média da turma (simulado)</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={mediasPorDisciplina}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="disciplina" />
                  <YAxis domain={[0, 20]} />
                  <Tooltip />
                  <Bar 
                    dataKey="media" 
                    name="Sua Média" 
                    fill="#4F46E5" 
                    radius={[4, 4, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Resumo */}
        <Card className={cn(
          'border-l-4',
          mediaGeral >= 14 ? 'border-l-green-500' :
          mediaGeral >= 10 ? 'border-l-blue-500' :
          'border-l-red-500'
        )}>
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className={cn(
                'p-3 rounded-lg',
                mediaGeral >= 14 ? 'bg-green-100' :
                mediaGeral >= 10 ? 'bg-blue-100' :
                'bg-red-100'
              )}>
                <Award className={cn(
                  'h-6 w-6',
                  mediaGeral >= 14 ? 'text-green-600' :
                  mediaGeral >= 10 ? 'text-blue-600' :
                  'text-red-600'
                )} />
              </div>
              <div>
                <h3 className="text-lg font-semibold">
                  {mediaGeral >= 14 ? 'Excelente Desempenho!' :
                   mediaGeral >= 10 ? 'Bom Desempenho' :
                   'Precisa de Melhorias'}
                </h3>
                <p className="text-muted-foreground mt-1">
                  {mediaGeral >= 14 
                    ? 'Parabéns! Seu desempenho está acima da média. Continue assim!'
                    : mediaGeral >= 10
                    ? 'Seu desempenho está satisfatório, mas há espaço para melhorias.'
                    : 'É importante dedicar mais tempo aos estudos. Procure ajuda dos professores.'}
                </p>
                <div className="flex items-center gap-4 mt-3">
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span>Atualizado em: {new Date().toLocaleDateString('pt-AO')}</span>
                  </div>
                  <Badge variant={mediaGeral >= 10 ? 'default' : 'destructive'}>
                    {mediaGeral >= 10 ? 'Aprovado' : 'Em Recuperação'}
                  </Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
