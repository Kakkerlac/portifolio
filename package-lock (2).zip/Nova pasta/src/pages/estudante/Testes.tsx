import { useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { 
  ClipboardList, 
  Clock, 
  Calendar,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Play,
  Lock,
  Eye,
  BarChart3
} from 'lucide-react';
import { mockTestes, mockTestesResultados, mockDisciplinas } from '@/data/mockData';
import { cn } from '@/lib/utils';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';

export default function Testes() {
  const [showStartDialog, setShowStartDialog] = useState(false);
  const [selectedTeste, setSelectedTeste] = useState<string | null>(null);
  const [testeIdInput, setTesteIdInput] = useState('');
  const [senhaInput, setSenhaInput] = useState('');
  const { toast } = useToast();

  const testesDisponiveis = mockTestes.filter(t => t.status === 'publicado');
  const testesEncerrados = mockTestes.filter(t => t.status === 'encerrado');

  const handleStartTeste = () => {
    if (!testeIdInput || !senhaInput) {
      toast({
        title: 'Campos obrigatórios',
        description: 'Por favor, preencha o ID do teste e a senha.',
        variant: 'destructive'
      });
      return;
    }

    const teste = mockTestes.find(t => t.id === testeIdInput);
    if (!teste) {
      toast({
        title: 'Teste não encontrado',
        description: 'Verifique o ID do teste e tente novamente.',
        variant: 'destructive'
      });
      return;
    }

    if (teste.senha_acesso !== senhaInput) {
      toast({
        title: 'Senha incorreta',
        description: 'A senha fornecida está incorreta.',
        variant: 'destructive'
      });
      return;
    }

    toast({
      title: 'Teste iniciado!',
      description: 'Boa sorte no seu teste.',
    });
    setShowStartDialog(false);
  };

  // Estatísticas dos testes
  const resultados = mockTestesResultados;
  const totalTestes = resultados.length;
  const totalCertas = resultados.reduce((acc, r) => acc + (r.nota_obtida > 10 ? 1 : 0), 0);
  const totalErradas = totalTestes - totalCertas;
  const mediaGeral = totalTestes > 0
    ? (resultados.reduce((acc, r) => acc + r.nota_obtida, 0) / totalTestes).toFixed(1)
    : '0.0';

  const COLORS = ['#10B981', '#EF4444'];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">Testes</h1>
            <p className="text-muted-foreground">Realize testes e consulte seus resultados</p>
          </div>
          <Button onClick={() => setShowStartDialog(true)}>
            <Play className="h-4 w-4 mr-2" />
            Fazer Teste
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <ClipboardList className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-sm text-muted-foreground">Testes Realizados</p>
                  <p className="text-xl font-bold">{totalTestes}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="h-5 w-5 text-green-500" />
                <div>
                  <p className="text-sm text-muted-foreground">Respostas Certas</p>
                  <p className="text-xl font-bold text-green-600">{totalCertas}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <XCircle className="h-5 w-5 text-red-500" />
                <div>
                  <p className="text-sm text-muted-foreground">Respostas Erradas</p>
                  <p className="text-xl font-bold text-red-600">{totalErradas}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <BarChart3 className="h-5 w-5 text-blue-500" />
                <div>
                  <p className="text-sm text-muted-foreground">Média Geral</p>
                  <p className="text-xl font-bold">{mediaGeral}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Testes Disponíveis */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Testes Disponíveis</CardTitle>
                <CardDescription>Testes aguardando realização</CardDescription>
              </CardHeader>
              <CardContent>
                {testesDisponiveis.length > 0 ? (
                  <div className="space-y-3">
                    {testesDisponiveis.map((teste) => (
                      <div 
                        key={teste.id}
                        className="p-4 rounded-lg border hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-start justify-between">
                          <div>
                            <div className="flex items-center gap-2">
                              <h3 className="font-medium">{teste.titulo}</h3>
                              <Badge variant="outline">{teste.disciplina_nome}</Badge>
                            </div>
                            <p className="text-sm text-muted-foreground mt-1">
                              {teste.descricao}
                            </p>
                            <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                              <span className="flex items-center gap-1">
                                <Calendar className="h-4 w-4" />
                                {new Date(teste.data_inicio).toLocaleDateString('pt-AO')}
                              </span>
                              <span className="flex items-center gap-1">
                                <Clock className="h-4 w-4" />
                                {teste.duracao_minutos} minutos
                              </span>
                              <span className="flex items-center gap-1">
                                <ClipboardList className="h-4 w-4" />
                                {teste.num_perguntas} perguntas
                              </span>
                            </div>
                          </div>
                          <Button 
                            size="sm"
                            onClick={() => {
                              setSelectedTeste(teste.id);
                              setTesteIdInput(teste.id);
                              setShowStartDialog(true);
                            }}
                          >
                            <Play className="h-4 w-4 mr-2" />
                            Iniciar
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <ClipboardList className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Nenhum teste disponível no momento</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Histórico de Testes */}
            <Card>
              <CardHeader>
                <CardTitle>Histórico de Testes</CardTitle>
                <CardDescription>Testes já realizados</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Teste</TableHead>
                      <TableHead>Disciplina</TableHead>
                      <TableHead>Data</TableHead>
                      <TableHead className="text-center">Nota</TableHead>
                      <TableHead className="text-center">Certas</TableHead>
                      <TableHead className="text-center">Erradas</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {mockTestesResultados.map((resultado) => {
                      const teste = mockTestes.find(t => t.id === resultado.teste_id);
                      return (
                        <TableRow key={resultado.id}>
                          <TableCell className="font-medium">{teste?.titulo}</TableCell>
                          <TableCell>{teste?.disciplina_nome}</TableCell>
                          <TableCell>
                            {new Date(resultado.data_realizacao).toLocaleDateString('pt-AO')}
                          </TableCell>
                          <TableCell className={cn(
                            'text-center font-bold',
                            resultado.nota_obtida >= 10 ? 'text-green-600' : 'text-red-600'
                          )}>
                            {resultado.nota_obtida}
                          </TableCell>
                          <TableCell className="text-center text-green-600">
                            {Math.round((resultado.nota_obtida / 20) * (teste?.num_perguntas || 10))}
                          </TableCell>
                          <TableCell className="text-center text-red-600">
                            {(teste?.num_perguntas || 10) - Math.round((resultado.nota_obtida / 20) * (teste?.num_perguntas || 10))}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>

          {/* Gráficos */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Desempenho nos Testes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={[
                          { name: 'Certas', value: totalCertas },
                          { name: 'Erradas', value: totalErradas }
                        ]}
                        cx="50%"
                        cy="50%"
                        innerRadius={40}
                        outerRadius={70}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        <Cell fill="#10B981" />
                        <Cell fill="#EF4444" />
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex justify-center gap-4 mt-4">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-green-500" />
                    <span className="text-sm">Certas ({totalCertas})</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-red-500" />
                    <span className="text-sm">Erradas ({totalErradas})</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-amber-50 border-amber-200">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 mt-0.5" />
                  <div>
                    <p className="font-medium text-amber-900">Sistema Anti-Fraude</p>
                    <p className="text-sm text-amber-700 mt-1">
                      Durante os testes, o sistema monitora atividades suspeitas. 
                      Mudar de aba ou minimizar a janela pode resultar em cancelamento do teste.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Dialog para iniciar teste */}
      <Dialog open={showStartDialog} onOpenChange={setShowStartDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Iniciar Teste</DialogTitle>
            <DialogDescription>
              Insira o ID do teste e a senha fornecida pelo professor.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <div>
              <Label>ID do Teste</Label>
              <Input 
                value={testeIdInput}
                onChange={(e) => setTesteIdInput(e.target.value)}
                placeholder="Ex: test1"
              />
            </div>
            <div>
              <Label>Senha de Acesso</Label>
              <Input 
                type="password"
                value={senhaInput}
                onChange={(e) => setSenhaInput(e.target.value)}
                placeholder="Senha fornecida pelo professor"
              />
            </div>
            <div className="bg-muted p-3 rounded-lg text-sm text-muted-foreground">
              <p className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                O teste terá início imediatamente após a validação.
              </p>
              <p className="flex items-center gap-2 mt-1">
                <Lock className="h-4 w-4" />
                Não é permitido sair da tela durante o teste.
              </p>
            </div>
            <Button className="w-full" onClick={handleStartTeste}>
              <Play className="h-4 w-4 mr-2" />
              Iniciar Teste
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
