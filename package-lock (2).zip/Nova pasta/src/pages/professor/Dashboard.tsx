import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { StatCard } from '@/components/common/StatCard';
import { ChartCard } from '@/components/common/ChartCard';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Users, 
  BookOpen, 
  FileText, 
  Calendar,
  TrendingUp,
  MessageSquare,
  Clock,
  CheckCircle2,
  AlertCircle,
  Plus,
  ChevronRight
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { mockTurmas, mockDisciplinas, mockNotas, mockAulas } from '@/data/mockData';
import { Link } from 'react-router-dom';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line
} from 'recharts';

export default function ProfessorDashboard() {
  const { user } = useAuth();

  // Estatísticas do professor
  const minhasTurmas = mockTurmas.slice(0, 3);
  const minhasDisciplinas = mockDisciplinas.filter(d => d.professor_id === user?.id);
  const totalAlunos = minhasTurmas.reduce((acc, t) => acc + (t.estudantes_count || 0), 0);
  
  // Dados para gráfico de desempenho das turmas
  const desempenhoTurmas = minhasTurmas.map(t => ({
    turma: t.nome,
    media: 13 + Math.random() * 4 // Simulado
  }));

  // Aulas de hoje
  const aulasHoje = mockAulas.filter(a => a.professor_id === user?.id && a.data === '2025-02-20');

  // Tarefas pendentes
  const tarefasPendentes = [
    { id: 1, tarefa: 'Lançar notas do teste de Matemática', prazo: 'Hoje', urgencia: 'alta' },
    { id: 2, tarefa: 'Preparar material para aula de amanhã', prazo: 'Amanhã', urgencia: 'media' },
    { id: 3, tarefa: 'Revisar trabalhos de casa', prazo: '23/02', urgencia: 'baixa' },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Welcome */}
        <div>
          <h1 className="text-2xl font-bold">Bem-vindo, Prof. {user?.nome_completo.split(' ')[0]}!</h1>
          <p className="text-muted-foreground">Aqui está o resumo da sua atividade</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <StatCard
            title="Minhas Turmas"
            value={minhasTurmas.length}
            description="turmas atribuídas"
            icon={Users}
            variant="primary"
          />
          <StatCard
            title="Total de Alunos"
            value={totalAlunos}
            description="em todas as turmas"
            icon={Users}
            variant="default"
          />
          <StatCard
            title="Disciplinas"
            value={minhasDisciplinas.length || 1}
            description="lecionadas"
            icon={BookOpen}
            variant="success"
          />
          <StatCard
            title="Aulas Hoje"
            value={aulasHoje.length}
            description="para lecionar"
            icon={Calendar}
            variant="warning"
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column */}
          <div className="lg:col-span-2 space-y-6">
            {/* Minhas Turmas */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Minhas Turmas</CardTitle>
                  <CardDescription>Turmas sob sua responsabilidade</CardDescription>
                </div>
                <Button variant="outline" size="sm" asChild>
                  <Link to="/professor/turmas">Ver Todas</Link>
                </Button>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {minhasTurmas.map((turma) => (
                    <Card key={turma.id} className="border-dashed">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="font-semibold">{turma.nome}</h3>
                          <Badge variant="outline">{turma.turno}</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {turma.estudantes_count} alunos
                        </p>
                        <p className="text-sm text-muted-foreground">
                          Sala {turma.sala}
                        </p>
                        <div className="flex gap-2 mt-3">
                          <Button variant="outline" size="sm" className="flex-1" asChild>
                            <Link to={`/professor/notas?turma=${turma.id}`}>Notas</Link>
                          </Button>
                          <Button variant="outline" size="sm" className="flex-1" asChild>
                            <Link to={`/professor/presencas?turma=${turma.id}`}>Presenças</Link>
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Desempenho das Turmas */}
            <ChartCard title="Desempenho das Turmas" description="Média geral por turma">
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={desempenhoTurmas}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="turma" />
                    <YAxis domain={[0, 20]} />
                    <Tooltip />
                    <Bar dataKey="media" fill="#4F46E5" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </ChartCard>

            {/* Aulas de Hoje */}
            <Card>
              <CardHeader>
                <CardTitle>Aulas de Hoje</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {aulasHoje.length > 0 ? (
                    aulasHoje.map((aula) => (
                      <div 
                        key={aula.id}
                        className="flex items-center gap-4 p-3 rounded-lg border"
                      >
                        <div className="flex flex-col items-center min-w-[60px]">
                          <span className="text-sm font-medium">{aula.hora_inicio}</span>
                          <span className="text-xs text-muted-foreground">{aula.hora_fim}</span>
                        </div>
                        <div className="w-px h-10 bg-border" />
                        <div className="flex-1">
                          <p className="font-medium">{aula.disciplina_nome}</p>
                          <p className="text-sm text-muted-foreground">{aula.tema}</p>
                        </div>
                        <Badge variant="outline">{aula.sala}</Badge>
                      </div>
                    ))
                  ) : (
                    <p className="text-center text-muted-foreground py-4">
                      Nenhuma aula agendada para hoje
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            {/* Tarefas Pendentes */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Tarefas Pendentes</CardTitle>
                <Badge variant="secondary">{tarefasPendentes.length}</Badge>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {tarefasPendentes.map((tarefa) => (
                    <div 
                      key={tarefa.id}
                      className="p-3 rounded-lg border hover:bg-muted/50 transition-colors"
                    >
                      <div className="flex items-start gap-2">
                        <div className={cn(
                          'w-2 h-2 rounded-full mt-2',
                          tarefa.urgencia === 'alta' && 'bg-red-500',
                          tarefa.urgencia === 'media' && 'bg-amber-500',
                          tarefa.urgencia === 'baixa' && 'bg-blue-500'
                        )} />
                        <div className="flex-1">
                          <p className="text-sm">{tarefa.tarefa}</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            Prazo: {tarefa.prazo}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Ações Rápidas */}
            <Card>
              <CardHeader>
                <CardTitle>Ações Rápidas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button className="w-full justify-between" asChild>
                  <Link to="/professor/notas">
                    Lançar Notas
                    <ChevronRight className="h-4 w-4" />
                  </Link>
                </Button>
                <Button variant="outline" className="w-full justify-between" asChild>
                  <Link to="/professor/testes">
                    Criar Teste
                    <Plus className="h-4 w-4" />
                  </Link>
                </Button>
                <Button variant="outline" className="w-full justify-between" asChild>
                  <Link to="/professor/materiais">
                    Upload de Materiais
                    <ChevronRight className="h-4 w-4" />
                  </Link>
                </Button>
                <Button variant="outline" className="w-full justify-between" asChild>
                  <Link to="/professor/presencas">
                    Lançar Presenças
                    <ChevronRight className="h-4 w-4" />
                  </Link>
                </Button>
              </CardContent>
            </Card>

            {/* Mensagens Recentes */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="h-5 w-5" />
                  Mensagens
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted/50 cursor-pointer">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                      <span className="text-sm font-medium">M</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">Maria da Conceição</p>
                      <p className="text-xs text-muted-foreground truncate">
                        Dúvida sobre o exercício...
                      </p>
                    </div>
                    <span className="text-xs text-muted-foreground">10m</span>
                  </div>
                  <div className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted/50 cursor-pointer">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                      <span className="text-sm font-medium">P</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">Pedro Neto</p>
                      <p className="text-xs text-muted-foreground truncate">
                        Professor, posso entregar amanhã?
                      </p>
                    </div>
                    <span className="text-xs text-muted-foreground">1h</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}

import { cn } from '@/lib/utils';
