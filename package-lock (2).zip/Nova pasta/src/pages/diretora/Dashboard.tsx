import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { StatCard } from '@/components/common/StatCard';
import { ChartCard } from '@/components/common/ChartCard';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Users, 
  GraduationCap, 
  School,
  TrendingUp,
  TrendingDown,
  Eye,
  FileBarChart,
  Target,
  Award,
  AlertTriangle,
  Calendar,
  ChevronRight
} from 'lucide-react';
import { mockDashboardStats } from '@/data/mockData';
import { Link } from 'react-router-dom';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area
} from 'recharts';
import { cn } from '@/lib/utils';

export default function DiretoraDashboard() {
  // Indicadores de desempenho
  const indicadores = [
    { nome: 'Taxa de Aprovação', valor: 87, meta: 90, unidade: '%' },
    { nome: 'Taxa de Retenção', valor: 8, meta: 5, unidade: '%' },
    { nome: 'Média Geral', valor: 13.5, meta: 14, unidade: '' },
    { nome: 'Taxa de Presença', valor: 92, meta: 95, unidade: '%' },
  ];

  // Dados para gráficos
  const evolucaoDesempenho = [
    { ano: '2021', aprovacao: 82, media: 12.8 },
    { ano: '2022', aprovacao: 84, media: 13.1 },
    { ano: '2023', aprovacao: 85, media: 13.3 },
    { ano: '2024', aprovacao: 87, media: 13.5 },
    { ano: '2025', aprovacao: 89, media: 13.8 },
  ];

  const desempenhoPorTurma = [
    { turma: '10ª A', media: 14.2 },
    { turma: '10ª B', media: 13.8 },
    { turma: '11ª A', media: 13.5 },
    { turma: '11ª B', media: 13.1 },
    { turma: '12ª A', media: 14.5 },
    { turma: '12ª B', media: 14.0 },
  ];

  const fluxoFinanceiro = [
    { mes: 'Jan', receitas: 7200000, despesas: 6500000 },
    { mes: 'Fev', receitas: 6800000, despesas: 6400000 },
    { mes: 'Mar', receitas: 0, despesas: 6200000 },
  ];

  // Auditoria recente
  const auditoriaRecente = [
    { acao: 'Nota alterada', usuario: 'Prof. João Martins', data: '20/02/2025 14:30', detalhes: 'Matemática - Maria Silva: 12 → 14' },
    { acao: 'Aluno matriculado', usuario: 'Sec. Ana Pereira', data: '19/02/2025 10:15', detalhes: 'Novo aluno: Pedro António' },
    { acao: 'Pagamento registrado', usuario: 'Sec. Ana Pereira', data: '19/02/2025 09:45', detalhes: 'Mensalidade: 45.000 Kz' },
    { acao: 'Horário alterado', usuario: 'Sec. Ana Pereira', data: '18/02/2025 16:20', detalhes: '10ª A - Quinta-feira' },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">Visão Estratégica</h1>
            <p className="text-muted-foreground">Dashboard da Direção</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" asChild>
              <Link to="/diretora/relatorios">
                <FileBarChart className="h-4 w-4 mr-2" />
                Relatórios Globais
              </Link>
            </Button>
            <Button variant="outline" asChild>
              <Link to="/diretora/auditoria">
                <Eye className="h-4 w-4 mr-2" />
                Auditoria
              </Link>
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="Total de Alunos"
            value={mockDashboardStats.totalEstudantes}
            description="matriculados"
            icon={GraduationCap}
            trend="up"
            trendValue="+12%"
            variant="primary"
          />
          <StatCard
            title="Professores"
            value={mockDashboardStats.totalProfessores}
            description="ativos"
            icon={Users}
            variant="default"
          />
          <StatCard
            title="Média Geral"
            value={mockDashboardStats.mediaGeral}
            description="de todos os alunos"
            icon={Target}
            trend="up"
            trendValue="+0.3"
            variant="success"
          />
          <StatCard
            title="Taxa de Presença"
            value={`${mockDashboardStats.taxaPresenca}%`}
            description="este mês"
            icon={Award}
            trend="up"
            trendValue="+2%"
            variant="warning"
          />
        </div>

        {/* Indicadores */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5" />
              Indicadores de Desempenho
            </CardTitle>
            <CardDescription>Comparativo com metas estabelecidas</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {indicadores.map((ind) => (
                <div key={ind.nome} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">{ind.nome}</span>
                    <span className={cn(
                      'text-sm font-medium',
                      ind.valor >= ind.meta ? 'text-green-600' : 'text-amber-600'
                    )}>
                      Meta: {ind.meta}{ind.unidade}
                    </span>
                  </div>
                  <div className="flex items-end gap-2">
                    <span className={cn(
                      'text-2xl font-bold',
                      ind.valor >= ind.meta ? 'text-green-600' : 'text-amber-600'
                    )}>
                      {ind.valor}{ind.unidade}
                    </span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div 
                      className={cn(
                        'h-full rounded-full transition-all',
                        ind.valor >= ind.meta ? 'bg-green-500' : 'bg-amber-500'
                      )}
                      style={{ width: `${Math.min((ind.valor / ind.meta) * 100, 100)}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Evolução do Desempenho */}
          <ChartCard title="Evolução do Desempenho" description="Taxa de aprovação ao longo dos anos">
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={evolucaoDesempenho}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="ano" />
                  <YAxis yAxisId="left" domain={[70, 100]} />
                  <YAxis yAxisId="right" orientation="right" domain={[10, 16]} />
                  <Tooltip />
                  <Line yAxisId="left" type="monotone" dataKey="aprovacao" stroke="#10B981" strokeWidth={2} name="Aprovação (%)" />
                  <Line yAxisId="right" type="monotone" dataKey="media" stroke="#4F46E5" strokeWidth={2} name="Média Geral" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </ChartCard>

          {/* Desempenho por Turma */}
          <ChartCard title="Desempenho por Turma" description="Média geral de cada turma">
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={desempenhoPorTurma}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="turma" />
                  <YAxis domain={[10, 16]} />
                  <Tooltip />
                  <Bar dataKey="media" fill="#4F46E5" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </ChartCard>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Fluxo Financeiro */}
          <ChartCard title="Fluxo Financeiro" description="Receitas vs Despesas (Kz)">
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={fluxoFinanceiro}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="mes" />
                  <YAxis />
                  <Tooltip formatter={(value: number) => `${(value / 1000000).toFixed(1)}M Kz`} />
                  <Area type="monotone" dataKey="receitas" stroke="#10B981" fill="#10B981" fillOpacity={0.2} />
                  <Area type="monotone" dataKey="despesas" stroke="#EF4444" fill="#EF4444" fillOpacity={0.2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </ChartCard>

          {/* Auditoria Recentemente */}
          <Card className="lg:col-span-2">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Eye className="h-5 w-5" />
                  Auditoria Recente
                </CardTitle>
                <CardDescription>Registro de alterações importantes</CardDescription>
              </div>
              <Button variant="outline" size="sm" asChild>
                <Link to="/diretora/auditoria">Ver Tudo</Link>
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {auditoriaRecente.map((item, index) => (
                  <div 
                    key={index}
                    className="flex items-start gap-4 p-3 rounded-lg border hover:bg-muted/50 transition-colors"
                  >
                    <div className="w-2 h-2 rounded-full bg-primary mt-2" />
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <p className="font-medium">{item.acao}</p>
                        <span className="text-xs text-muted-foreground">{item.data}</span>
                      </div>
                      <p className="text-sm text-muted-foreground">{item.usuario}</p>
                      <p className="text-sm mt-1">{item.detalhes}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}

import { Cell } from 'recharts';
