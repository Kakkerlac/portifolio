import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { 
  GraduationCap, 
  Eye, 
  EyeOff, 
  Lock, 
  User,
  AlertCircle,
  Info
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';

export default function Login() {
  const [numeroUtilizador, setNumeroUtilizador] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [error, setError] = useState('');
  const [showNewUserDialog, setShowNewUserDialog] = useState(false);
  const { login, isLoading } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!numeroUtilizador || !password) {
      setError('Por favor, preencha todos os campos');
      return;
    }

    const result = await login(numeroUtilizador, password);
    
    if (result.success) {
      // Redirecionar baseado no role
      const userStr = localStorage.getItem('pirilampo_user');
      if (userStr) {
        const user = JSON.parse(userStr);
        switch (user.role) {
          case 'estudante':
            navigate('/estudante');
            break;
          case 'professor':
            navigate('/professor');
            break;
          case 'secretaria':
            navigate('/secretaria');
            break;
          case 'diretora':
            navigate('/diretora');
            break;
          case 'ti_admin':
            navigate('/ti');
            break;
          default:
            navigate('/estudante');
        }
      }
    } else {
      setError(result.error || 'Erro ao fazer login');
    }
  };

  // Credenciais de teste
  const testCredentials = [
    { role: 'Estudante', user: 'EST2025001', pass: 'estudante123' },
    { role: 'Professor', user: 'PROF2024001', pass: 'professor123' },
    { role: 'Secretaria', user: 'SEC2023001', pass: 'secretaria123' },
    { role: 'Diretora', user: 'DIR2022001', pass: 'diretora123' },
    { role: 'TI Admin', user: 'TI2022001', pass: 'admin123' },
  ];

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/5 via-background to-primary/10 p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-primary rounded-xl mb-4">
            <GraduationCap className="h-10 w-10 text-primary-foreground" />
          </div>
          <h1 className="text-2xl font-bold">O Pirilampo</h1>
          <p className="text-muted-foreground">Secretaria Virtual Escolar</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Iniciar Sessão</CardTitle>
            <CardDescription>
              Insira suas credenciais para aceder ao sistema
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <div className="flex items-center gap-2 p-3 rounded-lg bg-destructive/10 text-destructive text-sm">
                  <AlertCircle className="h-4 w-4" />
                  {error}
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="numero">Número de Utilizador</Label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="numero"
                    placeholder="Ex: EST2025001"
                    value={numeroUtilizador}
                    onChange={(e) => setNumeroUtilizador(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Palavra-passe</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Sua palavra-passe"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10 pr-10"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="absolute right-0 top-0 h-full px-3"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4 text-muted-foreground" />
                    ) : (
                      <Eye className="h-4 w-4 text-muted-foreground" />
                    )}
                  </Button>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="remember"
                    checked={rememberMe}
                    onCheckedChange={(checked) => setRememberMe(checked as boolean)}
                  />
                  <Label htmlFor="remember" className="text-sm font-normal">
                    Lembrar-me
                  </Label>
                </div>
                <Button variant="link" className="text-sm px-0">
                  Recuperar senha?
                </Button>
              </div>

              <Button 
                type="submit" 
                className="w-full"
                disabled={isLoading}
              >
                {isLoading ? 'A entrar...' : 'Entrar'}
              </Button>
            </form>

            <div className="mt-6 pt-6 border-t">
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => setShowNewUserDialog(true)}
              >
                <Info className="h-4 w-4 mr-2" />
                Novo Utilizador / Teste
              </Button>
              <p className="text-xs text-center text-muted-foreground mt-2">
                Para testes controlados sem comprometer dados reais
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center mt-8 text-sm text-muted-foreground">
          <p>© 2025 Colégio O Pirilampo. Todos os direitos reservados.</p>
          <p className="mt-1">Lubango, Angola</p>
        </div>
      </div>

      {/* Dialog de Novo Utilizador */}
      <Dialog open={showNewUserDialog} onOpenChange={setShowNewUserDialog}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Credenciais de Teste</DialogTitle>
            <DialogDescription>
              Use estas credenciais para testar diferentes perfis do sistema.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 pt-4">
            {testCredentials.map((cred) => (
              <div 
                key={cred.user}
                className="flex items-center justify-between p-3 rounded-lg border hover:bg-muted/50 cursor-pointer"
                onClick={() => {
                  setNumeroUtilizador(cred.user);
                  setPassword(cred.pass);
                  setShowNewUserDialog(false);
                }}
              >
                <div>
                  <p className="font-medium">{cred.role}</p>
                  <p className="text-sm text-muted-foreground">{cred.user}</p>
                </div>
                <Button variant="ghost" size="sm">
                  Usar
                </Button>
              </div>
            ))}
          </div>
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mt-4">
            <p className="text-sm text-amber-800">
              <strong>Nota:</strong> Estas credenciais são apenas para demonstração. 
              Em produção, cada utilizador terá suas próprias credenciais fornecidas pela instituição.
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
