import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { StatCard } from '@/components/common/StatCard';
import { ChartCard } from '@/components/common/ChartCard';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Users, 
  Shield,
  Settings,
  Database,
  Activity,
  AlertTriangle,
  CheckCircle2,
  Server,
  Lock,
  Eye,
  Wrench,
  Terminal,
  RefreshCw,
  Power,
  ChevronRight
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { cn } from '@/lib/utils';
import { Link } from 'react-router-dom';
import { Progress } from '@/components/ui/progress';

export default function TIDashboard() {
  // Estatísticas do sistema
  const systemStats = {
    usuariosAtivos: 187,
    usuariosOnline: 42,
    sessoesAtivas: 38,
    erros24h: 3,
    uptime: '99.9%',
    ultimoBackup: 'Há 2 horas'
  };

  // Dados para gráficos
  const acessosPorHora = [
    { hora: '00:00', acessos: 5 },
    { hora: '04:00', acessos: 2 },
    { hora: '08:00', acessos: 45 },
    { hora: '12:00', acessos: 78 },
    { hora: '16:00', acessos: 65 },
    { hora: '20:00', acessos: 32 },
  ];

  const usuariosPorRole = [
    { name: 'Estudantes', value: 165, color: '#4F46E5' },
    { name: 'Professores', value: 24, color: '#10B981' },
    { name: 'Secretaria', value: 4, color: '#F59E0B' },
    { name: 'Direção', value: 2, color: '#EF4444' },
    { name: 'TI', value: 2, color: '#8B5CF6' },
  ];

  const usoRecursos = [
    { recurso: 'CPU', usado: 45, total: 100 },
    { recurso: 'Memória', usado: 62, total: 100 },
    { recurso: 'Disco', usado: 78, total: 100 },
    { recurso: 'Rede', usado: 35, total: 100 },
  ];

  // Logs recentes
  const logsRecentes = [
    { tipo: 'info', mensagem: 'Backup automático concluído', tempo: '10 minutos atrás', origem: 'Sistema' },
    { tipo: 'warning', mensagem: 'Tentativa de login falhada', tempo: '25 minutos atrás', origem: '192.168.1.45' },
    { tipo: 'error', mensagem: 'Erro de conexão com banco de dados', tempo: '1 hora atrás', origem: 'PostgreSQL' },
    { tipo: 'info', mensagem: 'Novo usuário criado: EST2025089', tempo: '2 horas atrás', origem: 'Admin' },
    { tipo: 'success', mensagem: 'Sistema atualizado para v2.1.0', tempo: '3 horas atrás', origem: 'Sistema' },
  ];

  // Usuários bloqueados
  const usuariosBloqueados = [
    { nome: 'Carlos Manuel Dias', motivo: 'Inadimplência', dias: 75, tipo: 'estudante' },
    { nome: 'Joana Maria Santos', motivo: 'Inadimplência', dias: 68, tipo: 'estudante' },
    { nome: 'Prof. António Vieira', motivo: 'Tentativas de login', dias: 2, tipo: 'professor' },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">Painel de Administração</h1>
            <p className="text-muted-foreground">Controle total do sistema</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" asChild>
              <Link to="/ti/logs">
                <Terminal className="h-4 w-4 mr-2" />
                Logs
              </Link>
            </Button>
            <Button variant="outline" asChild>
              <Link to="/ti/configuracoes">
                <Settings className="h-4 w-4 mr-2" />
                Configurações
              </Link>
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="Usuários Ativos"
            value={systemStats.usuariosAtivos}
            description={`${systemStats.usuariosOnline} online agora`}
            icon={Users}
            variant="primary"
          />
          <StatCard
            title="Sessões Ativas"
            value={systemStats.sessoesAtivas}
            description="usuários logados"
            icon={Activity}
            variant="success"
          />
          <StatCard
            title="Uptime"
            value={systemStats.uptime}
            description="últimos 30 dias"
            icon={Server}
            variant="default"
          />
          <StatCard
            title="Erros (24h)"
            value={systemStats.erros24h}
            description="requerem atenção"
            icon={AlertTriangle}
            variant={systemStats.erros24h > 5 ? 'danger' : 'warning'}
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column */}
          <div className="lg:col-span-2 space-y-6">
            {/* Acessos por Hora */}
            <ChartCard title="Acessos por Período" description="Número de acessos nas últimas 24 horas">
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={acessosPorHora}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="hora" />
                    <YAxis />
                    <Tooltip />
                    <Area type="monotone" dataKey="acessos" stroke="#4F46E5" fill="#4F46E5" fillOpacity={0.2} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </ChartCard>

            {/* Uso de Recursos */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  Uso de Recursos do Servidor
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {usoRecursos.map((recurso) => (
                    <div key={recurso.recurso}>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-medium">{recurso.recurso}</span>
                        <span className={cn(
                          'text-sm',
                          recurso.usado > 80 ? 'text-red-600' :
                          recurso.usado > 60 ? 'text-amber-600' :
                          'text-green-600'
                        )}>
                          {recurso.usado}%
                        </span>
                      </div>
                      <Progress 
                        value={recurso.usado} 
                        className={cn(
                          'h-2',
                          recurso.usado > 80 && '[&>div]:bg-red-500',
                          recurso.usado > 60 && recurso.usado <= 80 && '[&>div]:bg-amber-500',
                          recurso.usado <= 60 && '[&>div]:bg-green-500'
                        )}
                      />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Logs do Sistema */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Terminal className="h-5 w-5" />
                    Logs do Sistema
                  </CardTitle>
                  <CardDescription>Eventos recentes do sistema</CardDescription>
                </div>
                <Button variant="outline" size="sm" asChild>
                  <Link to="/ti/logs">Ver Todos</Link>
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {logsRecentes.map((log, index) => (
                    <div 
                      key={index}
                      className="flex items-start gap-3 p-3 rounded-lg border hover:bg-muted/50 transition-colors"
                    >
                      <div className={cn(
                        'w-2 h-2 rounded-full mt-2',
                        log.tipo === 'info' && 'bg-blue-500',
                        log.tipo === 'warning' && 'bg-amber-500',
                        log.tipo === 'error' && 'bg-red-500',
                        log.tipo === 'success' && 'bg-green-500'
                      )} />
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <p className="text-sm">{log.mensagem}</p>
                          <span className="text-xs text-muted-foreground">{log.tempo}</span>
                        </div>
                        <p className="text-xs text-muted-foreground">Origem: {log.origem}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            {/* Distribuição de Usuários */}
            <Card>
              <CardHeader>
                <CardTitle>Usuários por Perfil</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={usuariosPorRole}
                        cx="50%"
                        cy="50%"
                        innerRadius={40}
                        outerRadius={70}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {usuariosPorRole.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="space-y-2 mt-4">
                  {usuariosPorRole.map((item) => (
                    <div key={item.name} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-3 h-3 rounded-full" 
                          style={{ backgroundColor: item.color }}
                        />
                        <span className="text-sm">{item.name}</span>
                      </div>
                      <span className="text-sm font-medium">{item.value}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Usuários Bloqueados */}
            <Card className="border-red-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-red-600">
                  <Lock className="h-5 w-5" />
                  Usuários Bloqueados
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {usuariosBloqueados.map((user, index) => (
                    <div 
                      key={index}
                      className="p-3 rounded-lg bg-red-50 border border-red-100"
                    >
                      <div className="flex items-center justify-between">
                        <p className="font-medium text-sm">{user.nome}</p>
                        <Badge variant="destructive" className="text-xs">
                          {user.tipo}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground">{user.motivo}</p>
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-xs text-red-600">
                          {user.dias} dias bloqueado
                        </span>
                        <Button variant="ghost" size="sm" className="h-6 text-xs">
                          Desbloquear
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Ações Rápidas */}
            <Card>
              <CardHeader>
                <CardTitle>Ferramentas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="outline" className="w-full justify-between" asChild>
                  <Link to="/ti/usuarios">
                    Gerenciar Usuários
                    <ChevronRight className="h-4 w-4" />
                  </Link>
                </Button>
                <Button variant="outline" className="w-full justify-between" asChild>
                  <Link to="/ti/permissoes">
                    Permissões
                    <Shield className="h-4 w-4" />
                  </Link>
                </Button>
                <Button variant="outline" className="w-full justify-between">
                  <span className="flex items-center gap-2">
                    <RefreshCw className="h-4 w-4" />
                    Forçar Backup
                  </span>
                </Button>
                <Button variant="outline" className="w-full justify-between text-red-600 hover:text-red-600">
                  <span className="flex items-center gap-2">
                    <Power className="h-4 w-4" />
                    Reiniciar Sistema
                  </span>
                </Button>
              </CardContent>
            </Card>

            {/* Status do Sistema */}
            <Card>
              <CardHeader>
                <CardTitle>Status do Sistema</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Servidor Web</span>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-green-500" />
                      <span className="text-sm text-green-600">Online</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Banco de Dados</span>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-green-500" />
                      <span className="text-sm text-green-600">Online</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Cache (Redis)</span>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-green-500" />
                      <span className="text-sm text-green-600">Online</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Último Backup</span>
                    <span className="text-sm text-muted-foreground">{systemStats.ultimoBackup}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
