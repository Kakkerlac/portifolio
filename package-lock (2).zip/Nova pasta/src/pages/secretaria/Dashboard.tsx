import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { StatCard } from '@/components/common/StatCard';
import { ChartCard } from '@/components/common/ChartCard';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Users, 
  GraduationCap, 
  School,
  CreditCard,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  Plus,
  ChevronRight,
  Calendar,
  FileText,
  Bell
} from 'lucide-react';
import { mockDashboardStats, mockInadimplentes, mockAlunosSecretaria } from '@/data/mockData';
import { Link } from 'react-router-dom';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line
} from 'recharts';
import { cn } from '@/lib/utils';

export default function SecretariaDashboard() {
  // Dados para gráficos
  const matriculasPorMes = [
    { mes: 'Jan', matriculas: 45 },
    { mes: 'Fev', matriculas: 52 },
    { mes: 'Mar', matriculas: 38 },
    { mes: 'Abr', matriculas: 41 },
    { mes: 'Mai', matriculas: 35 },
    { mes: 'Jun', matriculas: 28 },
  ];

  const pagamentosStatus = [
    { name: 'Pagos', value: 142, color: '#10B981' },
    { name: 'Pendentes', value: 18, color: '#F59E0B' },
    { name: 'Atrasados', value: 8, color: '#EF4444' },
  ];

  const receitasMensais = [
    { mes: 'Jan', previsto: 7500000, realizado: 7200000 },
    { mes: 'Fev', previsto: 7500000, realizado: 6800000 },
    { mes: 'Mar', previsto: 7500000, realizado: 0 },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">Dashboard da Secretaria</h1>
            <p className="text-muted-foreground">Visão geral da gestão escolar</p>
          </div>
          <div className="flex gap-2">
            <Button asChild>
              <Link to="/secretaria/alunos/novo">
                <Plus className="h-4 w-4 mr-2" />
                Novo Aluno
              </Link>
            </Button>
            <Button variant="outline" asChild>
              <Link to="/secretaria/relatorios">
                <FileText className="h-4 w-4 mr-2" />
                Relatórios
              </Link>
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="Total de Alunos"
            value={mockDashboardStats.totalEstudantes}
            description="matriculados"
            icon={GraduationCap}
            trend="up"
            trendValue="+5%"
            variant="primary"
          />
          <StatCard
            title="Professores"
            value={mockDashboardStats.totalProfessores}
            description="ativos"
            icon={Users}
            variant="default"
          />
          <StatCard
            title="Turmas"
            value={mockDashboardStats.totalTurmas}
            description="em funcionamento"
            icon={School}
            variant="success"
          />
          <StatCard
            title="Inadimplentes"
            value={mockDashboardStats.inadimplentes}
            description="alunos com atraso"
            icon={AlertTriangle}
            trend="up"
            trendValue="+2"
            variant="danger"
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column */}
          <div className="lg:col-span-2 space-y-6">
            {/* Gráfico de Matrículas */}
            <ChartCard title="Matrículas por Mês" description="Evolução das matrículas no ano letivo">
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={matriculasPorMes}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="mes" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="matriculas" fill="#4F46E5" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </ChartCard>

            {/* Receitas */}
            <ChartCard title="Receitas Mensais" description="Previsto vs Realizado (Kz)">
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={receitasMensais}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="mes" />
                    <YAxis />
                    <Tooltip formatter={(value: number) => `${(value / 1000000).toFixed(1)}M Kz`} />
                    <Line type="monotone" dataKey="previsto" stroke="#94A3B8" strokeDasharray="5 5" />
                    <Line type="monotone" dataKey="realizado" stroke="#10B981" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </ChartCard>

            {/* Alunos Recentes */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Alunos Recentes</CardTitle>
                  <CardDescription>Últimas matrículas realizadas</CardDescription>
                </div>
                <Button variant="outline" size="sm" asChild>
                  <Link to="/secretaria/alunos">Ver Todos</Link>
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {mockAlunosSecretaria.slice(0, 5).map((aluno) => (
                    <div 
                      key={aluno.id}
                      className="flex items-center justify-between p-3 rounded-lg border hover:bg-muted/50 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                          <span className="font-medium">{aluno.nome.charAt(0)}</span>
                        </div>
                        <div>
                          <p className="font-medium">{aluno.nome}</p>
                          <p className="text-sm text-muted-foreground">{aluno.matricula}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge variant="outline">{aluno.turma}</Badge>
                        <p className={cn(
                          'text-xs mt-1',
                          aluno.status === 'regular' && 'text-green-600',
                          aluno.status === 'pendente' && 'text-amber-600',
                          aluno.status === 'bloqueado' && 'text-red-600'
                        )}>
                          {aluno.status === 'regular' && 'Regular'}
                          {aluno.status === 'pendente' && 'Pendente'}
                          {aluno.status === 'bloqueado' && 'Bloqueado'}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            {/* Status dos Pagamentos */}
            <Card>
              <CardHeader>
                <CardTitle>Status dos Pagamentos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={pagamentosStatus}
                        cx="50%"
                        cy="50%"
                        innerRadius={40}
                        outerRadius={70}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {pagamentosStatus.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="space-y-2 mt-4">
                  {pagamentosStatus.map((item) => (
                    <div key={item.name} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-3 h-3 rounded-full" 
                          style={{ backgroundColor: item.color }}
                        />
                        <span className="text-sm">{item.name}</span>
                      </div>
                      <span className="text-sm font-medium">{item.value}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Inadimplentes */}
            <Card className="border-red-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-red-600">
                  <AlertTriangle className="h-5 w-5" />
                  Inadimplentes
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {mockInadimplentes.map((inad) => (
                    <div 
                      key={inad.id}
                      className="p-3 rounded-lg bg-red-50 border border-red-100"
                    >
                      <div className="flex items-center justify-between">
                        <p className="font-medium text-sm">{inad.nome}</p>
                        <Badge variant="destructive" className="text-xs">
                          {inad.dias_atraso} dias
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground">{inad.turma}</p>
                      <p className="text-sm font-medium text-red-600 mt-1">
                        {inad.valor_devido.toLocaleString('pt-AO')} Kz
                      </p>
                    </div>
                  ))}
                </div>
                <Button variant="outline" className="w-full mt-4" asChild>
                  <Link to="/secretaria/inadimplentes">Ver Todos</Link>
                </Button>
              </CardContent>
            </Card>

            {/* Ações Rápidas */}
            <Card>
              <CardHeader>
                <CardTitle>Ações Rápidas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="outline" className="w-full justify-between" asChild>
                  <Link to="/secretaria/alunos/novo">
                    Cadastrar Aluno
                    <Plus className="h-4 w-4" />
                  </Link>
                </Button>
                <Button variant="outline" className="w-full justify-between" asChild>
                  <Link to="/secretaria/professores/novo">
                    Cadastrar Professor
                    <Plus className="h-4 w-4" />
                  </Link>
                </Button>
                <Button variant="outline" className="w-full justify-between" asChild>
                  <Link to="/secretaria/pagamentos">
                    Registrar Pagamento
                    <CreditCard className="h-4 w-4" />
                  </Link>
                </Button>
                <Button variant="outline" className="w-full justify-between" asChild>
                  <Link to="/secretaria/horarios">
                    Gerenciar Horários
                    <Calendar className="h-4 w-4" />
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
