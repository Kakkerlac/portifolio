// Mock Data para O Pirilampo - Secretaria Virtual Escolar

import type {
  User, Estudante, Professor, Disciplina, Turma, Nota, Teste,
  Aviso, Aula, Mensalidade, Horario, BlocoNota, ChatMessage,
  DashboardStats, Tema, Material, Pergunta, Encarregado
} from '@/types';

// Usuários por perfil
export const mockUsers: User[] = [
  {
    id: 'u1',
    numero_utilizador: 'EST2025001',
    email: 'maria.silva@pirilampo.ao',
    nome_completo: 'Maria da Conceição Silva',
    telefone: '+244 923 456 789',
    foto_url: 'https://i.pravatar.cc/150?u=maria',
    data_nascimento: '2008-05-15',
    genero: 'Feminino',
    role: 'estudante',
    ativo: true,
    bloqueado: false,
    data_ultimo_acesso: '2025-02-19T14:30:00Z',
    created_at: '2023-01-15T08:00:00Z'
  },
  {
    id: 'u2',
    numero_utilizador: 'PROF2024001',
    email: 'joao.martins@pirilampo.ao',
    nome_completo: 'João Carlos Martins',
    telefone: '+244 912 345 678',
    foto_url: 'https://i.pravatar.cc/150?u=joao',
    data_nascimento: '1985-03-20',
    genero: 'Masculino',
    role: 'professor',
    ativo: true,
    bloqueado: false,
    data_ultimo_acesso: '2025-02-20T09:15:00Z',
    created_at: '2022-06-10T08:00:00Z'
  },
  {
    id: 'u3',
    numero_utilizador: 'SEC2023001',
    email: 'ana.pereira@pirilampo.ao',
    nome_completo: 'Ana Beatriz Pereira',
    telefone: '+244 934 567 890',
    foto_url: 'https://i.pravatar.cc/150?u=ana',
    data_nascimento: '1990-08-12',
    genero: 'Feminino',
    role: 'secretaria',
    ativo: true,
    bloqueado: false,
    data_ultimo_acesso: '2025-02-20T11:00:00Z',
    created_at: '2021-03-05T08:00:00Z'
  },
  {
    id: 'u4',
    numero_utilizador: 'DIR2022001',
    email: 'diretora@pirilampo.ao',
    nome_completo: 'Dra. Fernanda dos Santos',
    telefone: '+244 945 678 901',
    foto_url: 'https://i.pravatar.cc/150?u=fernanda',
    data_nascimento: '1975-11-30',
    genero: 'Feminino',
    role: 'diretora',
    ativo: true,
    bloqueado: false,
    data_ultimo_acesso: '2025-02-20T10:30:00Z',
    created_at: '2020-01-10T08:00:00Z'
  },
  {
    id: 'u5',
    numero_utilizador: 'TI2022001',
    email: 'ti@pirilampo.ao',
    nome_completo: 'Carlos Eduardo Lima',
    telefone: '+244 956 789 012',
    foto_url: 'https://i.pravatar.cc/150?u=carlos',
    data_nascimento: '1988-07-25',
    genero: 'Masculino',
    role: 'ti_admin',
    ativo: true,
    bloqueado: false,
    data_ultimo_acesso: '2025-02-20T12:00:00Z',
    created_at: '2020-01-10T08:00:00Z'
  }
];

// Turmas
export const mockTurmas: Turma[] = [
  { id: 't1', nome: '10ª Classe A', ano_letivo: 2025, turno: 'manha', sala: 'Sala 101', capacidade: 35, estudantes_count: 32 },
  { id: 't2', nome: '10ª Classe B', ano_letivo: 2025, turno: 'manha', sala: 'Sala 102', capacidade: 35, estudantes_count: 30 },
  { id: 't3', nome: '11ª Classe A', ano_letivo: 2025, turno: 'manha', sala: 'Sala 201', capacidade: 30, estudantes_count: 28 },
  { id: 't4', nome: '11ª Classe B', ano_letivo: 2025, turno: 'tarde', sala: 'Sala 202', capacidade: 30, estudantes_count: 29 },
  { id: 't5', nome: '12ª Classe A', ano_letivo: 2025, turno: 'tarde', sala: 'Sala 301', capacidade: 25, estudantes_count: 24 },
  { id: 't6', nome: '12ª Classe B', ano_letivo: 2025, turno: 'tarde', sala: 'Sala 302', capacidade: 25, estudantes_count: 22 }
];

// Disciplinas
export const mockDisciplinas: Disciplina[] = [
  {
    id: 'd1',
    nome: 'Matemática',
    codigo: 'MAT',
    descricao: 'Estudo dos números, formas e padrões',
    carga_horaria: 180,
    professor_id: 'u2',
    professor_nome: 'João Carlos Martins',
    temas: [
      {
        id: 'tema1',
        disciplina_id: 'd1',
        titulo: 'Limites',
        subtitulo: 'Noção de limites e continuidade',
        ordem: 1,
        materiais: [
          { id: 'm1', tema_id: 'tema1', titulo: 'Aula 1 - Introdução aos Limites', tipo: 'video', url: 'https://www.youtube.com/watch?v=DkCHV5Kbx4o', descricao: 'Videoaula introdutória sobre limites' },
          { id: 'm2', tema_id: 'tema1', titulo: 'Exercícios Resolvidos', tipo: 'pdf', url: '#', descricao: 'Lista de exercícios com resolução' },
          { id: 'm3', tema_id: 'tema1', titulo: 'Material Complementar', tipo: 'link', url: 'https://www.youtube.com/watch?v=s3j69Fd3GWM', descricao: 'Videoaula complementar' }
        ]
      },
      {
        id: 'tema2',
        disciplina_id: 'd1',
        titulo: 'Derivadas',
        subtitulo: 'Cálculo diferencial',
        ordem: 2,
        materiais: [
          { id: 'm4', tema_id: 'tema2', titulo: 'Regras de Derivação', tipo: 'video', url: 'https://www.youtube.com/watch?v=cWBEMN75IMc', descricao: 'Aula sobre regras de derivação' },
          { id: 'm5', tema_id: 'tema2', titulo: 'Exercícios de Derivadas', tipo: 'pdf', url: '#', descricao: 'Exercícios práticos' }
        ]
      }
    ]
  },
  {
    id: 'd2',
    nome: 'Português',
    codigo: 'POR',
    descricao: 'Língua portuguesa e literatura',
    carga_horaria: 180,
    professor_id: 'u6',
    professor_nome: 'Prof.ª Maria José',
    temas: [
      {
        id: 'tema3',
        disciplina_id: 'd2',
        titulo: 'Substantivos',
        subtitulo: 'Classificação e uso',
        ordem: 1,
        materiais: [
          { id: 'm6', tema_id: 'tema3', titulo: 'Aula de Substantivos', tipo: 'video', url: 'https://www.youtube.com/watch?v=8iXiBgCnGv4', descricao: 'Videoaula completa sobre substantivos' },
          { id: 'm7', tema_id: 'tema3', titulo: 'Ficha de Trabalho', tipo: 'pdf', url: '#', descricao: 'Exercícios para praticar' }
        ]
      }
    ]
  },
  {
    id: 'd3',
    nome: 'Inglês',
    codigo: 'ING',
    descricao: 'Língua inglesa',
    carga_horaria: 120,
    professor_id: 'u7',
    professor_nome: 'Prof. John Smith',
    temas: [
      {
        id: 'tema4',
        disciplina_id: 'd3',
        titulo: 'Verb to Be',
        subtitulo: 'Uso e conjugação',
        ordem: 1,
        materiais: [
          { id: 'm8', tema_id: 'tema4', titulo: 'Verb to Be - Aula Completa', tipo: 'video', url: 'https://www.youtube.com/watch?v=bSeZlT7Og8I', descricao: 'Aula completa sobre o verbo to be' },
          { id: 'm9', tema_id: 'tema4', titulo: 'Exercícios', tipo: 'pdf', url: '#', descricao: 'Pratique o verb to be' }
        ]
      }
    ]
  },
  {
    id: 'd4',
    nome: 'Física',
    codigo: 'FIS',
    descricao: 'Estudo dos fenômenos naturais',
    carga_horaria: 120,
    professor_id: 'u8',
    professor_nome: 'Prof. António Manuel',
    temas: []
  },
  {
    id: 'd5',
    nome: 'Química',
    codigo: 'QUI',
    descricao: 'Estudo da matéria e suas transformações',
    carga_horaria: 120,
    professor_id: 'u9',
    professor_nome: 'Prof.ª Catarina Lima',
    temas: []
  },
  {
    id: 'd6',
    nome: 'Biologia',
    codigo: 'BIO',
    descricao: 'Estudo dos seres vivos',
    carga_horaria: 100,
    professor_id: 'u10',
    professor_nome: 'Prof.ª Beatriz Fonseca',
    temas: []
  },
  {
    id: 'd7',
    nome: 'Geologia',
    codigo: 'GEO',
    descricao: 'Estudo da Terra',
    carga_horaria: 80,
    professor_id: 'u11',
    professor_nome: 'Prof. Domingos Pedro',
    temas: []
  },
  {
    id: 'd8',
    nome: 'Filosofia',
    codigo: 'FIL',
    descricao: 'Estudo do pensamento humano',
    carga_horaria: 80,
    professor_id: 'u12',
    professor_nome: 'Prof.ª Isabel Castro',
    temas: []
  },
  {
    id: 'd9',
    nome: 'Informática',
    codigo: 'INF',
    descricao: 'Tecnologias da informação',
    carga_horaria: 100,
    professor_id: 'u13',
    professor_nome: 'Prof. Ricardo Sousa',
    temas: []
  },
  {
    id: 'd10',
    nome: 'MIC',
    codigo: 'MIC',
    descricao: 'Métodos de Investigação Científica',
    carga_horaria: 60,
    professor_id: 'u14',
    professor_nome: 'Prof.ª Luísa Mendes',
    temas: []
  },
  {
    id: 'd11',
    nome: 'Empreendedorismo',
    codigo: 'EMP',
    descricao: 'Desenvolvimento de negócios',
    carga_horaria: 60,
    professor_id: 'u15',
    professor_nome: 'Prof. Fernando Costa',
    temas: []
  },
  {
    id: 'd12',
    nome: 'Música',
    codigo: 'MUS',
    descricao: 'Arte musical',
    carga_horaria: 40,
    professor_id: 'u16',
    professor_nome: 'Prof.ª Diana Rocha',
    temas: []
  },
  {
    id: 'd13',
    nome: 'Educação Física',
    codigo: 'EDF',
    descricao: 'Práticas desportivas',
    carga_horaria: 60,
    professor_id: 'u17',
    professor_nome: 'Prof. Bruno Alves',
    temas: []
  },
  {
    id: 'd14',
    nome: 'Psicologia',
    codigo: 'PSI',
    descricao: 'Estudo da mente humana',
    carga_horaria: 60,
    professor_id: 'u18',
    professor_nome: 'Prof.ª Sandra Matos',
    temas: []
  },
  {
    id: 'd15',
    nome: 'Geometria Descritiva',
    codigo: 'GED',
    descricao: 'Representação gráfica',
    carga_horaria: 80,
    professor_id: 'u19',
    professor_nome: 'Prof. Marcelo Vieira',
    temas: []
  }
];

// Estudantes detalhados
export const mockEstudantes: Estudante[] = [
  {
    ...mockUsers[0],
    turma_id: 't1',
    numero_matricula: 'MAT2023001',
    data_matricula: '2023-01-15',
    ano_letivo_atual: 2025,
    status_pagamento: 'regular',
    dias_bloqueio: 0,
    encarregado: {
      id: 'enc1',
      nome_completo: 'José da Silva Santos',
      telefone: '+244 999 888 777',
      email: 'jose.santos@email.ao',
      grau_parentesco: 'Pai',
      profissao: 'Engenheiro Civil',
      estudantes: ['u1']
    }
  }
];

// Professores detalhados
export const mockProfessores: Professor[] = [
  {
    ...mockUsers[1],
    especialidade: 'Matemática Pura',
    carga_horaria: 20,
    data_contratacao: '2022-06-10',
    disciplinas: ['d1'],
    turmas: ['t1', 't2', 't3']
  }
];

// Notas
export const mockNotas: Nota[] = [
  { id: 'n1', estudante_id: 'u1', disciplina_id: 'd1', disciplina_nome: 'Matemática', professor_id: 'u2', professor_nome: 'João Carlos Martins', trimestre: 1, ano_letivo: 2025, nota: 14, tipo_avaliacao: 'teste', peso: 1, data_avaliacao: '2025-01-20', observacao: 'Bom desempenho' },
  { id: 'n2', estudante_id: 'u1', disciplina_id: 'd1', disciplina_nome: 'Matemática', professor_id: 'u2', professor_nome: 'João Carlos Martins', trimestre: 1, ano_letivo: 2025, nota: 15, tipo_avaliacao: 'trabalho', peso: 1, data_avaliacao: '2025-02-05', observacao: 'Excelente trabalho' },
  { id: 'n3', estudante_id: 'u1', disciplina_id: 'd1', disciplina_nome: 'Matemática', professor_id: 'u2', professor_nome: 'João Carlos Martins', trimestre: 2, ano_letivo: 2025, nota: 13, tipo_avaliacao: 'teste', peso: 1, data_avaliacao: '2025-03-15', observacao: '' },
  { id: 'n4', estudante_id: 'u1', disciplina_id: 'd2', disciplina_nome: 'Português', professor_id: 'u6', professor_nome: 'Prof.ª Maria José', trimestre: 1, ano_letivo: 2025, nota: 16, tipo_avaliacao: 'teste', peso: 1, data_avaliacao: '2025-01-25', observacao: '' },
  { id: 'n5', estudante_id: 'u1', disciplina_id: 'd2', disciplina_nome: 'Português', professor_id: 'u6', professor_nome: 'Prof.ª Maria José', trimestre: 2, ano_letivo: 2025, nota: 17, tipo_avaliacao: 'participacao', peso: 0.5, data_avaliacao: '2025-03-10', observacao: '' },
  { id: 'n6', estudante_id: 'u1', disciplina_id: 'd3', disciplina_nome: 'Inglês', professor_id: 'u7', professor_nome: 'Prof. John Smith', trimestre: 1, ano_letivo: 2025, nota: 12, tipo_avaliacao: 'teste', peso: 1, data_avaliacao: '2025-01-18', observacao: '' },
  { id: 'n7', estudante_id: 'u1', disciplina_id: 'd3', disciplina_nome: 'Inglês', professor_id: 'u7', professor_nome: 'Prof. John Smith', trimestre: 2, ano_letivo: 2025, nota: 14, tipo_avaliacao: 'trabalho', peso: 1, data_avaliacao: '2025-03-05', observacao: '' },
  { id: 'n8', estudante_id: 'u1', disciplina_id: 'd4', disciplina_nome: 'Física', professor_id: 'u8', professor_nome: 'Prof. António Manuel', trimestre: 1, ano_letivo: 2025, nota: 11, tipo_avaliacao: 'teste', peso: 1, data_avaliacao: '2025-01-22', observacao: '' },
  { id: 'n9', estudante_id: 'u1', disciplina_id: 'd4', disciplina_nome: 'Física', professor_id: 'u8', professor_nome: 'Prof. António Manuel', trimestre: 2, ano_letivo: 2025, nota: 13, tipo_avaliacao: 'teste', peso: 1, data_avaliacao: '2025-03-18', observacao: '' },
  { id: 'n10', estudante_id: 'u1', disciplina_id: 'd6', disciplina_nome: 'Biologia', professor_id: 'u10', professor_nome: 'Prof.ª Beatriz Fonseca', trimestre: 1, ano_letivo: 2025, nota: 15, tipo_avaliacao: 'trabalho', peso: 1, data_avaliacao: '2025-02-01', observacao: '' }
];

// Testes
export const mockTestes: Teste[] = [
  {
    id: 'test1',
    disciplina_id: 'd1',
    disciplina_nome: 'Matemática',
    professor_id: 'u2',
    professor_nome: 'João Carlos Martins',
    turma_id: 't1',
    titulo: 'Teste de Limites',
    descricao: 'Avaliação sobre noção de limites',
    instrucoes: 'Leia atentamente cada questão. Tempo limite: 45 minutos.',
    data_inicio: '2025-02-15T08:00:00Z',
    data_fim: '2025-02-15T10:00:00Z',
    duracao_minutos: 45,
    senha_acesso: 'LIM2025',
    num_perguntas: 10,
    pontuacao_maxima: 20,
    tentativas_permitidas: 1,
    aleatorizar_perguntas: true,
    mostrar_resultado_imediato: false,
    status: 'encerrado',
    anti_fraude_ativo: true,
    perguntas: [
      {
        id: 'p1',
        teste_id: 'test1',
        pergunta: 'Qual é o limite de f(x) = x² quando x tende a 2?',
        tipo: 'multipla_escolha',
        opcoes: ['2', '4', '0', 'Infinito'],
        resposta_correta: 1,
        pontos: 2,
        ordem: 1
      },
      {
        id: 'p2',
        teste_id: 'test1',
        pergunta: 'O limite de uma constante é a própria constante.',
        tipo: 'verdadeiro_falso',
        opcoes: ['Verdadeiro', 'Falso'],
        resposta_correta: 0,
        pontos: 2,
        ordem: 2
      }
    ]
  },
  {
    id: 'test2',
    disciplina_id: 'd2',
    disciplina_nome: 'Português',
    professor_id: 'u6',
    professor_nome: 'Prof.ª Maria José',
    turma_id: 't1',
    titulo: 'Teste de Substantivos',
    descricao: 'Avaliação sobre classificação de substantivos',
    instrucoes: 'Identifique o tipo de cada substantivo.',
    data_inicio: '2025-02-20T14:00:00Z',
    data_fim: '2025-02-20T16:00:00Z',
    duracao_minutos: 30,
    senha_acesso: 'SUB2025',
    num_perguntas: 15,
    pontuacao_maxima: 20,
    tentativas_permitidas: 1,
    aleatorizar_perguntas: false,
    mostrar_resultado_imediato: true,
    status: 'publicado',
    anti_fraude_ativo: true
  }
];

// Testes resultados
export const mockTestesResultados = [
  { id: 'tr1', teste_id: 'test1', estudante_id: 'u1', respostas: { p1: 1, p2: 0 }, nota_obtida: 16, data_realizacao: '2025-02-15T08:30:00Z', tempo_gasto: 40, ip_address: '192.168.1.100' }
];

// Avisos
export const mockAvisos: Aviso[] = [
  {
    id: 'a1',
    titulo: 'Chamada escrita de História',
    conteudo: 'A chamada escrita de História está marcada para o dia 27/09 às 10:00. Não se esqueçam de trazer o material necessário.',
    tipo_destino: 'turma',
    destino_id: 't1',
    prioridade: 'alta',
    data_publicacao: '2025-02-18T09:00:00Z',
    expira_em: '2025-02-28T23:59:59Z',
    autor_id: 'u3',
    autor_nome: 'Ana Beatriz Pereira',
    lido: false
  },
  {
    id: 'a2',
    titulo: 'Apresentação dos trabalhos de Biologia',
    conteudo: 'Os trabalhos em grupo de Biologia serão apresentados no dia 25/10 às 09:10. Preparem-se!',
    tipo_destino: 'turma',
    destino_id: 't1',
    prioridade: 'media',
    data_publicacao: '2025-02-19T10:30:00Z',
    expira_em: '2025-10-25T23:59:59Z',
    autor_id: 'u10',
    autor_nome: 'Prof.ª Beatriz Fonseca',
    lido: false
  },
  {
    id: 'a3',
    titulo: 'Reunião de Pais e Encarregados',
    conteudo: 'A reunião trimestral com pais e encarregados será no dia 15/03 às 14:00.',
    tipo_destino: 'todos',
    prioridade: 'alta',
    data_publicacao: '2025-02-20T08:00:00Z',
    expira_em: '2025-03-15T23:59:59Z',
    autor_id: 'u4',
    autor_nome: 'Dra. Fernanda dos Santos',
    lido: false
  }
];

// Aulas do dia
export const mockAulas: Aula[] = [
  { id: 'aula1', disciplina_id: 'd1', disciplina_nome: 'Matemática', professor_id: 'u2', turma_id: 't1', tema: 'Limites', data: '2025-02-20', hora_inicio: '07:30', hora_fim: '09:00', sala: 'Sala 101', status: 'realizada' },
  { id: 'aula2', disciplina_id: 'd2', disciplina_nome: 'Português', professor_id: 'u6', turma_id: 't1', tema: 'Substantivos', data: '2025-02-20', hora_inicio: '09:10', hora_fim: '10:50', sala: 'Sala 101', status: 'agendada' },
  { id: 'aula3', disciplina_id: 'd3', disciplina_nome: 'Inglês', professor_id: 'u7', turma_id: 't1', tema: 'Verb to Be', data: '2025-02-20', hora_inicio: '11:00', hora_fim: '12:30', sala: 'Sala 101', status: 'agendada' },
  { id: 'aula4', disciplina_id: 'd4', disciplina_nome: 'Física', professor_id: 'u8', turma_id: 't1', tema: 'Cinemática', data: '2025-02-20', hora_inicio: '14:00', hora_fim: '15:30', sala: 'Laboratório Física', status: 'agendada' }
];

// Horários semanais
export const mockHorarios: Horario[] = [
  { id: 'h1', turma_id: 't1', disciplina_id: 'd1', disciplina_nome: 'Matemática', professor_id: 'u2', professor_nome: 'João Carlos Martins', dia_semana: 1, hora_inicio: '07:30', hora_fim: '09:00', sala: 'Sala 101' },
  { id: 'h2', turma_id: 't1', disciplina_id: 'd2', disciplina_nome: 'Português', professor_id: 'u6', professor_nome: 'Prof.ª Maria José', dia_semana: 1, hora_inicio: '09:10', hora_fim: '10:50', sala: 'Sala 101' },
  { id: 'h3', turma_id: 't1', disciplina_id: 'd3', disciplina_nome: 'Inglês', professor_id: 'u7', professor_nome: 'Prof. John Smith', dia_semana: 1, hora_inicio: '11:00', hora_fim: '12:30', sala: 'Sala 101' },
  { id: 'h4', turma_id: 't1', disciplina_id: 'd4', disciplina_nome: 'Física', professor_id: 'u8', professor_nome: 'Prof. António Manuel', dia_semana: 2, hora_inicio: '07:30', hora_fim: '09:00', sala: 'Lab. Física' },
  { id: 'h5', turma_id: 't1', disciplina_id: 'd5', disciplina_nome: 'Química', professor_id: 'u9', professor_nome: 'Prof.ª Catarina Lima', dia_semana: 2, hora_inicio: '09:10', hora_fim: '10:50', sala: 'Lab. Química' },
  { id: 'h6', turma_id: 't1', disciplina_id: 'd6', disciplina_nome: 'Biologia', professor_id: 'u10', professor_nome: 'Prof.ª Beatriz Fonseca', dia_semana: 2, hora_inicio: '11:00', hora_fim: '12:30', sala: 'Lab. Biologia' },
  { id: 'h7', turma_id: 't1', disciplina_id: 'd1', disciplina_nome: 'Matemática', professor_id: 'u2', professor_nome: 'João Carlos Martins', dia_semana: 3, hora_inicio: '07:30', hora_fim: '09:00', sala: 'Sala 101' },
  { id: 'h8', turma_id: 't1', disciplina_id: 'd7', disciplina_nome: 'Geologia', professor_id: 'u11', professor_nome: 'Prof. Domingos Pedro', dia_semana: 3, hora_inicio: '09:10', hora_fim: '10:50', sala: 'Sala 101' },
  { id: 'h9', turma_id: 't1', disciplina_id: 'd8', disciplina_nome: 'Filosofia', professor_id: 'u12', professor_nome: 'Prof.ª Isabel Castro', dia_semana: 3, hora_inicio: '11:00', hora_fim: '12:30', sala: 'Sala 101' },
  { id: 'h10', turma_id: 't1', disciplina_id: 'd2', disciplina_nome: 'Português', professor_id: 'u6', professor_nome: 'Prof.ª Maria José', dia_semana: 4, hora_inicio: '07:30', hora_fim: '09:00', sala: 'Sala 101' },
  { id: 'h11', turma_id: 't1', disciplina_id: 'd9', disciplina_nome: 'Informática', professor_id: 'u13', professor_nome: 'Prof. Ricardo Sousa', dia_semana: 4, hora_inicio: '09:10', hora_fim: '10:50', sala: 'Lab. Informática' },
  { id: 'h12', turma_id: 't1', disciplina_id: 'd3', disciplina_nome: 'Inglês', professor_id: 'u7', professor_nome: 'Prof. John Smith', dia_semana: 4, hora_inicio: '11:00', hora_fim: '12:30', sala: 'Sala 101' },
  { id: 'h13', turma_id: 't1', disciplina_id: 'd1', disciplina_nome: 'Matemática', professor_id: 'u2', professor_nome: 'João Carlos Martins', dia_semana: 5, hora_inicio: '07:30', hora_fim: '09:00', sala: 'Sala 101' },
  { id: 'h14', turma_id: 't1', disciplina_id: 'd15', disciplina_nome: 'Geometria Descritiva', professor_id: 'u19', professor_nome: 'Prof. Marcelo Vieira', dia_semana: 5, hora_inicio: '09:10', hora_fim: '10:50', sala: 'Sala 101' },
  { id: 'h15', turma_id: 't1', disciplina_id: 'd13', disciplina_nome: 'Educação Física', professor_id: 'u17', professor_nome: 'Prof. Bruno Alves', dia_semana: 5, hora_inicio: '11:00', hora_fim: '12:30', sala: 'Campo Desportivo' }
];

// Mensalidades
export const mockMensalidades: Mensalidade[] = [
  { id: 'm1', estudante_id: 'u1', mes_referencia: 1, ano_letivo: 2025, valor_original: 45000, juros: 0, desconto: 0, valor_final: 45000, data_vencimento: '2025-01-10', data_pagamento: '2025-01-08', status: 'pago', metodo_pagamento: 'transferencia', referencia: 'TXN123456' },
  { id: 'm2', estudante_id: 'u1', mes_referencia: 2, ano_letivo: 2025, valor_original: 45000, juros: 0, desconto: 0, valor_final: 45000, data_vencimento: '2025-02-10', data_pagamento: '2025-02-09', status: 'pago', metodo_pagamento: 'multicaixa', referencia: 'MCX789012' },
  { id: 'm3', estudante_id: 'u1', mes_referencia: 3, ano_letivo: 2025, valor_original: 45000, juros: 0, desconto: 0, valor_final: 45000, data_vencimento: '2025-03-10', status: 'pendente' }
];

// Bloco de Notas
export const mockBlocoNotas: BlocoNota[] = [
  {
    id: 'bn1',
    estudante_id: 'u1',
    disciplina_id: 'd6',
    disciplina_nome: 'Biologia',
    conteudo: 'Quarta tenho tarefa de biologia e terça tenho aulas à tarde então tenho que fazê-la segunda.',
    etiquetas: ['tarefa', 'biologia', 'urgente'],
    data_criacao: '2025-02-18T15:30:00Z',
    data_atualizacao: '2025-02-18T15:30:00Z'
  },
  {
    id: 'bn2',
    estudante_id: 'u1',
    disciplina_id: 'd1',
    disciplina_nome: 'Matemática',
    conteudo: 'Revisar derivadas antes do teste de sexta-feira. Focar nas regras da cadeia.',
    etiquetas: ['revisão', 'matemática', 'teste'],
    data_criacao: '2025-02-19T10:00:00Z',
    data_atualizacao: '2025-02-19T10:00:00Z'
  }
];

// Chat Messages
export const mockChatMessages: ChatMessage[] = [
  {
    id: 'cm1',
    remetente_id: 'u1',
    remetente_nome: 'Maria da Conceição Silva',
    remetente_foto: 'https://i.pravatar.cc/150?u=maria',
    destinatario_id: 'u2',
    conteudo: 'Bom dia, professor! Tenho uma dúvida sobre o exercício 5 da lição de limites.',
    data_envio: '2025-02-19T16:00:00Z',
    lida: true
  },
  {
    id: 'cm2',
    remetente_id: 'u2',
    remetente_nome: 'João Carlos Martins',
    remetente_foto: 'https://i.pravatar.cc/150?u=joao',
    destinatario_id: 'u1',
    conteudo: 'Bom dia, Maria! Claro, qual é a sua dúvida? O exercício 5 é sobre limites laterais.',
    data_envio: '2025-02-19T16:15:00Z',
    lida: true
  },
  {
    id: 'cm3',
    remetente_id: 'u1',
    remetente_nome: 'Maria da Conceição Silva',
    remetente_foto: 'https://i.pravatar.cc/150?u=maria',
    destinatario_id: 'u2',
    conteudo: 'Não entendi quando o limite pela esquerda é diferente do limite pela direita.',
    data_envio: '2025-02-19T16:20:00Z',
    lida: false
  }
];

// Dashboard Stats
export const mockDashboardStats: DashboardStats = {
  totalEstudantes: 165,
  totalProfessores: 24,
  totalTurmas: 6,
  totalDisciplinas: 15,
  inadimplentes: 8,
  mediaGeral: 13.5,
  taxaPresenca: 92
};

// Lista de professores para chat
export const mockProfessoresLista = [
  { id: 'u2', nome: 'João Carlos Martins', disciplina: 'Matemática', foto: 'https://i.pravatar.cc/150?u=joao', online: true },
  { id: 'u6', nome: 'Prof.ª Maria José', disciplina: 'Português', foto: 'https://i.pravatar.cc/150?u=mariajose', online: false },
  { id: 'u7', nome: 'Prof. John Smith', disciplina: 'Inglês', foto: 'https://i.pravatar.cc/150?u=john', online: true },
  { id: 'u8', nome: 'Prof. António Manuel', disciplina: 'Física', foto: 'https://i.pravatar.cc/150?u=antonio', online: false },
  { id: 'u9', nome: 'Prof.ª Catarina Lima', disciplina: 'Química', foto: 'https://i.pravatar.cc/150?u=catarina', online: true },
  { id: 'u10', nome: 'Prof.ª Beatriz Fonseca', disciplina: 'Biologia', foto: 'https://i.pravatar.cc/150?u=beatriz', online: false },
  { id: 'u11', nome: 'Prof. Domingos Pedro', disciplina: 'Geologia', foto: 'https://i.pravatar.cc/150?u=domingos', online: false },
  { id: 'u12', nome: 'Prof.ª Isabel Castro', disciplina: 'Filosofia', foto: 'https://i.pravatar.cc/150?u=isabel', online: true },
  { id: 'u13', nome: 'Prof. Ricardo Sousa', disciplina: 'Informática', foto: 'https://i.pravatar.cc/150?u=ricardo', online: false },
  { id: 'u14', nome: 'Prof.ª Luísa Mendes', disciplina: 'MIC', foto: 'https://i.pravatar.cc/150?u=luisa', online: false },
  { id: 'u15', nome: 'Prof. Fernando Costa', disciplina: 'Empreendedorismo', foto: 'https://i.pravatar.cc/150?u=fernando', online: true },
  { id: 'u16', nome: 'Prof.ª Diana Rocha', disciplina: 'Música', foto: 'https://i.pravatar.cc/150?u=diana', online: false },
  { id: 'u17', nome: 'Prof. Bruno Alves', disciplina: 'Ed. Física', foto: 'https://i.pravatar.cc/150?u=bruno', online: false },
  { id: 'u18', nome: 'Prof.ª Sandra Matos', disciplina: 'Psicologia', foto: 'https://i.pravatar.cc/150?u=sandra', online: true },
  { id: 'u19', nome: 'Prof. Marcelo Vieira', disciplina: 'Geometria Descritiva', foto: 'https://i.pravatar.cc/150?u=marcelo', online: false }
];

// Configurações do sistema
export const mockSystemConfig = {
  escola_nome: 'Colégio O Pirilampo',
  escola_endereco: 'Rua dos Educadores, nº 123, Luanda, Angola',
  escola_telefone: '+244 222 333 444',
  escola_email: 'contacto@pirilampo.ao',
  ano_letivo_atual: 2025,
  trimestre_atual: 1,
  bloqueio_inadimplencia_dias: 60,
  bloqueio_inadimplencia_ativo: true,
  juros_atraso_percentual: 2.5,
  logo_url: '/assets/logo.png'
};

// Dados adicionais para secretaria
export const mockAlunosSecretaria = [
  { id: 'u1', nome: 'Maria da Conceição Silva', matricula: 'MAT2023001', turma: '10ª Classe A', status: 'regular', telefone: '+244 923 456 789', email: 'maria.silva@pirilampo.ao' },
  { id: 'u20', nome: 'Pedro António Neto', matricula: 'MAT2023002', turma: '10ª Classe A', status: 'regular', telefone: '+244 912 345 678', email: 'pedro.neto@pirilampo.ao' },
  { id: 'u21', nome: 'Ana Luísa Ferreira', matricula: 'MAT2023003', turma: '10ª Classe A', status: 'pendente', telefone: '+244 934 567 890', email: 'ana.ferreira@pirilampo.ao' },
  { id: 'u22', nome: 'Carlos Manuel Dias', matricula: 'MAT2023004', turma: '10ª Classe B', status: 'bloqueado', telefone: '+244 945 678 901', email: 'carlos.dias@pirilampo.ao' },
  { id: 'u23', nome: 'Beatriz Alexandra Lima', matricula: 'MAT2023005', turma: '10ª Classe B', status: 'regular', telefone: '+244 956 789 012', email: 'beatriz.lima@pirilampo.ao' }
];

export const mockInadimplentes = [
  { id: 'u22', nome: 'Carlos Manuel Dias', turma: '10ª Classe B', dias_atraso: 75, valor_devido: 135000, meses_pendentes: 3 },
  { id: 'u24', nome: 'Joana Maria Santos', turma: '11ª Classe A', dias_atraso: 68, valor_devido: 90000, meses_pendentes: 2 },
  { id: 'u25', nome: 'Miguel Ângelo Costa', turma: '12ª Classe A', dias_atraso: 82, valor_devido: 180000, meses_pendentes: 4 }
];
