import { NavLink, useLocation } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import {
  LayoutDashboard,
  BookOpen,
  Calendar,
  FileText,
  ClipboardList,
  Award,
  UserCircle,
  MessageSquare,
  Users,
  School,
  Clock,
  CreditCard,
  BarChart3,
  Settings,
  Shield,
  ChevronDown,
  LogOut,
  GraduationCap,
  ClipboardCheck,
  FolderOpen,
  TrendingUp,
  Eye,
  FileBarChart,
  Lock,
  Database,
  Wrench,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { useState } from 'react';

interface SidebarProps {
  isOpen: boolean;
  onToggle: () => void;
}

interface NavItem {
  label: string;
  path?: string;
  icon: React.ElementType;
  badge?: string | number;
  children?: NavItem[];
  requiredPermission?: { resource: string; action: string };
}

export function Sidebar({ isOpen, onToggle }: SidebarProps) {
  const { user, logout, hasPermission } = useAuth();
  const location = useLocation();
  const [openGroups, setOpenGroups] = useState<string[]>([]);

  const toggleGroup = (label: string) => {
    setOpenGroups(prev => 
      prev.includes(label) 
        ? prev.filter(g => g !== label)
        : [...prev, label]
    );
  };

  const getNavItems = (): NavItem[] => {
    if (!user) return [];

    const commonItems: NavItem[] = [];

    switch (user.role) {
      case 'estudante':
        return [
          { label: 'Home', path: '/estudante', icon: LayoutDashboard },
          { label: 'Disciplinas', path: '/estudante/disciplinas', icon: BookOpen },
          { label: 'Calendário', path: '/estudante/calendario', icon: Calendar },
          { label: 'Notas', path: '/estudante/notas', icon: FileText },
          { label: 'Testes', path: '/estudante/testes', icon: ClipboardList, badge: 1 },
          { label: 'Classificação', path: '/estudante/classificacao', icon: Award },
          { label: 'Perfil', path: '/estudante/perfil', icon: UserCircle },
        ];

      case 'professor':
        return [
          { label: 'Dashboard', path: '/professor', icon: LayoutDashboard },
          { 
            label: 'Minhas Turmas', 
            icon: Users,
            children: [
              { label: 'Turmas', path: '/professor/turmas', icon: School },
              { label: 'Lançar Notas', path: '/professor/notas', icon: FileText },
              { label: 'Presenças', path: '/professor/presencas', icon: ClipboardCheck },
            ]
          },
          { label: 'Testes', path: '/professor/testes', icon: ClipboardList },
          { label: 'Materiais', path: '/professor/materiais', icon: FolderOpen },
          { label: 'Relatórios', path: '/professor/relatorios', icon: BarChart3 },
          { label: 'Mensagens', path: '/professor/mensagens', icon: MessageSquare, badge: 3 },
        ];

      case 'secretaria':
        return [
          { label: 'Dashboard', path: '/secretaria', icon: LayoutDashboard },
          { 
            label: 'Alunos', 
            icon: GraduationCap,
            children: [
              { label: 'Lista de Alunos', path: '/secretaria/alunos', icon: Users },
              { label: 'Cadastrar Aluno', path: '/secretaria/alunos/novo', icon: UserCircle },
              { label: 'Inadimplentes', path: '/secretaria/inadimplentes', icon: AlertIcon, badge: 8 },
            ]
          },
          { 
            label: 'Professores', 
            icon: School,
            children: [
              { label: 'Lista', path: '/secretaria/professores', icon: Users },
              { label: 'Cadastrar', path: '/secretaria/professores/novo', icon: UserCircle },
            ]
          },
          { 
            label: 'Turmas & Horários', 
            icon: Clock,
            children: [
              { label: 'Turmas', path: '/secretaria/turmas', icon: School },
              { label: 'Horários', path: '/secretaria/horarios', icon: Calendar },
            ]
          },
          { 
            label: 'Pagamentos', 
            icon: CreditCard,
            children: [
              { label: 'Mensalidades', path: '/secretaria/pagamentos', icon: FileText },
              { label: 'Histórico', path: '/secretaria/pagamentos/historico', icon: Clock },
            ]
          },
          { label: 'Relatórios', path: '/secretaria/relatorios', icon: BarChart3 },
        ];

      case 'diretora':
        return [
          { label: 'Visão Geral', path: '/diretora', icon: LayoutDashboard },
          { label: 'Indicadores', path: '/diretora/indicadores', icon: TrendingUp },
          { label: 'Auditoria', path: '/diretora/auditoria', icon: Eye },
          { label: 'Relatórios Globais', path: '/diretora/relatorios', icon: FileBarChart },
          { label: 'Gestão', path: '/diretora/gestao', icon: Settings },
        ];

      case 'ti_admin':
        return [
          { label: 'Dashboard', path: '/ti', icon: LayoutDashboard },
          { 
            label: 'Usuários', 
            icon: Users,
            children: [
              { label: 'Todos os Usuários', path: '/ti/usuarios', icon: Users },
              { label: 'Permissões', path: '/ti/permissoes', icon: Lock },
            ]
          },
          { label: 'Configurações', path: '/ti/configuracoes', icon: Settings },
          { label: 'Logs', path: '/ti/logs', icon: Database },
          { label: 'Manutenção', path: '/ti/manutencao', icon: Wrench },
        ];

      default:
        return commonItems;
    }
  };

  const navItems = getNavItems();

  const isActive = (path?: string) => {
    if (!path) return false;
    return location.pathname === path || location.pathname.startsWith(path + '/');
  };

  const renderNavItem = (item: NavItem, depth = 0) => {
    if (item.children) {
      const isGroupOpen = openGroups.includes(item.label);
      const hasActiveChild = item.children.some(child => isActive(child.path));
      
      return (
        <Collapsible 
          key={item.label} 
          open={isGroupOpen || hasActiveChild}
          onOpenChange={() => toggleGroup(item.label)}
        >
          <CollapsibleTrigger asChild>
            <Button
              variant="ghost"
              className={cn(
                'w-full justify-between px-3 py-2 h-10',
                hasActiveChild && 'bg-primary/10 text-primary'
              )}
            >
              <div className="flex items-center gap-3">
                <item.icon className="h-5 w-5" />
                {isOpen && <span className="text-sm">{item.label}</span>}
              </div>
              {isOpen && (
                <ChevronDown className={cn(
                  'h-4 w-4 transition-transform',
                  isGroupOpen && 'transform rotate-180'
                )} />
              )}
            </Button>
          </CollapsibleTrigger>
          <CollapsibleContent>
            <div className="pl-4 space-y-1 mt-1">
              {item.children.map(child => (
                <NavLink
                  key={child.path}
                  to={child.path!}
                  className={({ isActive }) => cn(
                    'flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors',
                    isActive 
                      ? 'bg-primary text-primary-foreground' 
                      : 'hover:bg-muted'
                  )}
                >
                  <child.icon className="h-4 w-4" />
                  {isOpen && <span>{child.label}</span>}
                </NavLink>
              ))}
            </div>
          </CollapsibleContent>
        </Collapsible>
      );
    }

    return (
      <NavLink
        key={item.path}
        to={item.path!}
        className={({ isActive }) => cn(
          'flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors',
          isActive 
            ? 'bg-primary text-primary-foreground' 
            : 'hover:bg-muted'
        )}
      >
        <item.icon className="h-5 w-5" />
        {isOpen && (
          <>
            <span className="flex-1">{item.label}</span>
            {item.badge && (
              <Badge variant="secondary" className="text-xs">
                {item.badge}
              </Badge>
            )}
          </>
        )}
      </NavLink>
    );
  };

  return (
    <aside 
      className={cn(
        'fixed left-0 top-0 z-40 h-screen bg-card border-r transition-all duration-300',
        isOpen ? 'w-64' : 'w-16'
      )}
    >
      <div className="flex flex-col h-full">
        {/* Logo */}
        <div className="flex items-center justify-between h-16 px-4 border-b">
          {isOpen ? (
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <GraduationCap className="h-5 w-5 text-primary-foreground" />
              </div>
              <div className="flex flex-col">
                <span className="font-bold text-sm leading-tight">O Pirilampo</span>
                <span className="text-xs text-muted-foreground">Secretaria Virtual</span>
              </div>
            </div>
          ) : (
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center mx-auto">
              <GraduationCap className="h-5 w-5 text-primary-foreground" />
            </div>
          )}
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={onToggle}
            className={cn('h-8 w-8', !isOpen && 'hidden')}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
        </div>

        {/* Navigation */}
        <ScrollArea className="flex-1 py-4 px-2">
          <nav className="space-y-1">
            {navItems.map(item => renderNavItem(item))}
          </nav>
        </ScrollArea>

        {/* User & Logout */}
        <div className="p-4 border-t">
          {isOpen ? (
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center overflow-hidden">
                  {user?.foto_url ? (
                    <img src={user.foto_url} alt={user.nome_completo} className="w-full h-full object-cover" />
                  ) : (
                    <UserCircle className="h-6 w-6 text-muted-foreground" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{user?.nome_completo}</p>
                  <p className="text-xs text-muted-foreground capitalize">{user?.role.replace('_', ' ')}</p>
                </div>
              </div>
              <Button 
                variant="outline" 
                className="w-full" 
                size="sm"
                onClick={logout}
              >
                <LogOut className="h-4 w-4 mr-2" />
                Terminar Sessão
              </Button>
            </div>
          ) : (
            <Button 
              variant="ghost" 
              size="icon" 
              className="w-full"
              onClick={logout}
            >
              <LogOut className="h-5 w-5" />
            </Button>
          )}
        </div>
      </div>
    </aside>
  );
}

// Icone de alerta para inadimplentes
function AlertIcon({ className }: { className?: string }) {
  return (
    <svg 
      className={className} 
      fill="none" 
      viewBox="0 0 24 24" 
      stroke="currentColor"
    >
      <path 
        strokeLinecap="round" 
        strokeLinejoin="round" 
        strokeWidth={2} 
        d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" 
      />
    </svg>
  );
}
