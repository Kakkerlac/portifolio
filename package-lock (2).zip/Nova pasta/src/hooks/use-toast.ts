import { toast as sonnerToast } from 'sonner';

interface ToastOptions {
  title?: string;
  description?: string;
  variant?: 'default' | 'destructive' | 'success';
}

export function useToast() {
  const toast = (options: ToastOptions) => {
    if (options.variant === 'destructive') {
      sonnerToast.error(options.title || options.description || '', {
        description: options.description,
      });
    } else if (options.variant === 'success') {
      sonnerToast.success(options.title || options.description || '', {
        description: options.description,
      });
    } else {
      sonnerToast(options.title || options.description || '', {
        description: options.description,
      });
    }
  };

  return { toast };
}

export { sonnerToast as toast };
