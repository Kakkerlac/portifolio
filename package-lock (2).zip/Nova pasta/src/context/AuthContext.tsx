import React, { createContext, useContext, useState, useCallback, type ReactNode } from 'react';
import type { User, UserRole } from '@/types';
import { mockUsers, mockEstudantes, mockProfessores } from '@/data/mockData';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (numero_utilizador: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  hasPermission: (resource: string, action: string) => boolean;
  canAccessRole: (role: UserRole) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Senhas mock para cada usuário (em produção, isso seria hash no backend)
const MOCK_PASSWORDS: Record<string, string> = {
  'EST2025001': 'estudante123',
  'PROF2024001': 'professor123',
  'SEC2023001': 'secretaria123',
  'DIR2022001': 'diretora123',
  'TI2022001': 'admin123'
};

// Permissões por role
const ROLE_PERMISSIONS: Record<UserRole, Record<string, string[]>> = {
  estudante: {
    dashboard: ['view'],
    disciplinas: ['view'],
    notas: ['view'],
    calendario: ['view'],
    testes: ['view', 'take'],
    perfil: ['view'],
    chat: ['send', 'receive'],
    pagamentos: ['view']
  },
  professor: {
    dashboard: ['view'],
    disciplinas: ['view', 'manage'],
    notas: ['create', 'edit', 'view'],
    presencas: ['create', 'edit', 'view'],
    testes: ['create', 'edit', 'view'],
    materiais: ['upload', 'delete'],
    relatorios: ['view'],
    chat: ['send', 'receive'],
    calendario: ['view']
  },
  secretaria: {
    dashboard: ['view'],
    alunos: ['create', 'edit', 'view', 'delete'],
    professores: ['create', 'edit', 'view'],
    turmas: ['create', 'edit', 'view'],
    horarios: ['create', 'edit', 'view'],
    pagamentos: ['view', 'manage'],
    mensalidades: ['mark_paid'],
    relatorios: ['view', 'generate'],
    encarregados: ['create', 'edit', 'view'],
    avisos: ['create', 'edit', 'view']
  },
  diretora: {
    dashboard: ['view'],
    all_data: ['view'],
    relatorios: ['view', 'generate', 'export'],
    auditoria: ['view'],
    indicadores: ['view'],
    secretaria: ['view', 'supervise'],
    alunos: ['view'],
    professores: ['view'],
    turmas: ['view'],
    pagamentos: ['view']
  },
  ti_admin: {
    all: ['*'],
    users: ['create', 'edit', 'delete', 'view'],
    config: ['edit', 'view'],
    logs: ['view'],
    permissoes: ['edit'],
    bloqueios: ['manage']
  }
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const login = useCallback(async (numero_utilizador: string, password: string): Promise<{ success: boolean; error?: string }> => {
    setIsLoading(true);
    
    // Simula delay de rede
    await new Promise(resolve => setTimeout(resolve, 800));
    
    try {
      // Verifica se é um usuário de teste
      const mockUser = mockUsers.find(u => u.numero_utilizador === numero_utilizador);
      
      if (!mockUser) {
        return { success: false, error: 'Número de utilizador não encontrado' };
      }
      
      // Verifica senha (em produção, isso seria no backend)
      const expectedPassword = MOCK_PASSWORDS[numero_utilizador];
      if (password !== expectedPassword) {
        return { success: false, error: 'Palavra-passe incorreta' };
      }
      
      // Verifica se usuário está ativo
      if (!mockUser.ativo) {
        return { success: false, error: 'Conta desativada. Contacte a secretaria.' };
      }
      
      // Verifica se usuário está bloqueado
      if (mockUser.bloqueado) {
        return { success: false, error: `Conta bloqueada. Motivo: ${mockUser.motivo_bloqueio || 'Contacte a secretaria.'}` };
      }
      
      // Enriquece dados do usuário baseado no role
      let enrichedUser = { ...mockUser };
      
      if (mockUser.role === 'estudante') {
        const estudanteData = mockEstudantes.find(e => e.id === mockUser.id);
        if (estudanteData) {
          enrichedUser = { ...enrichedUser, ...estudanteData };
        }
      } else if (mockUser.role === 'professor') {
        const professorData = mockProfessores.find(p => p.id === mockUser.id);
        if (professorData) {
          enrichedUser = { ...enrichedUser, ...professorData };
        }
      }
      
      setUser(enrichedUser);
      
      // Salva no localStorage para persistência
      localStorage.setItem('pirilampo_user', JSON.stringify(enrichedUser));
      
      return { success: true };
    } finally {
      setIsLoading(false);
    }
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    localStorage.removeItem('pirilampo_user');
  }, []);

  const hasPermission = useCallback((resource: string, action: string): boolean => {
    if (!user) return false;
    
    const permissions = ROLE_PERMISSIONS[user.role];
    if (!permissions) return false;
    
    // TI admin tem acesso total
    if (user.role === 'ti_admin' && permissions.all?.includes('*')) {
      return true;
    }
    
    const resourcePerms = permissions[resource];
    if (!resourcePerms) return false;
    
    return resourcePerms.includes(action) || resourcePerms.includes('*');
  }, [user]);

  const canAccessRole = useCallback((role: UserRole): boolean => {
    if (!user) return false;
    
    const roleLevels: Record<UserRole, number> = {
      estudante: 1,
      professor: 2,
      secretaria: 3,
      diretora: 4,
      ti_admin: 5
    };
    
    return roleLevels[user.role] >= roleLevels[role];
  }, [user]);

  // Verifica se há usuário salvo no localStorage ao iniciar
  React.useEffect(() => {
    const savedUser = localStorage.getItem('pirilampo_user');
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser));
      } catch {
        localStorage.removeItem('pirilampo_user');
      }
    }
  }, []);

  return (
    <AuthContext.Provider value={{
      user,
      isAuthenticated: !!user,
      isLoading,
      login,
      logout,
      hasPermission,
      canAccessRole
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth deve ser usado dentro de um AuthProvider');
  }
  return context;
}
