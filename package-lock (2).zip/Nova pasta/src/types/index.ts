// Tipos do Sistema O Pirilampo

export type UserRole = 'estudante' | 'professor' | 'secretaria' | 'diretora' | 'ti_admin';

export interface User {
  id: string;
  numero_utilizador: string;
  email: string;
  nome_completo: string;
  telefone?: string;
  foto_url?: string;
  data_nascimento?: string;
  genero?: string;
  role: UserRole;
  ativo: boolean;
  bloqueado: boolean;
  motivo_bloqueio?: string;
  data_ultimo_acesso?: string;
  created_at: string;
}

export interface Role {
  id: string;
  name: string;
  slug: UserRole;
  description: string;
  level: number;
  permissions: Record<string, string[]>;
}

export interface Estudante extends User {
  turma_id: string;
  numero_matricula: string;
  data_matricula: string;
  ano_letivo_atual: number;
  status_pagamento: 'regular' | 'pendente' | 'bloqueado';
  dias_bloqueio: number;
  encarregado?: Encarregado;
}

export interface Professor extends User {
  especialidade: string;
  carga_horaria: number;
  data_contratacao: string;
  disciplinas: string[];
  turmas: string[];
}

export interface Secretaria extends User {
  departamento: string;
  nivel_acesso: string;
}

export interface Diretora extends User {
  cargo: string;
  data_nomeacao: string;
}

export interface TIAdmin extends User {
  nivel_permissao: string;
  ultimo_acesso: string;
}

export interface Encarregado {
  id: string;
  nome_completo: string;
  telefone: string;
  email?: string;
  grau_parentesco: string;
  profissao?: string;
  estudantes: string[];
}

export interface Turma {
  id: string;
  nome: string;
  ano_letivo: number;
  turno: 'manha' | 'tarde' | 'noite';
  sala: string;
  capacidade: number;
  coordenador_id?: string;
  estudantes_count?: number;
}

export interface Disciplina {
  id: string;
  nome: string;
  codigo: string;
  descricao?: string;
  carga_horaria: number;
  professor_id?: string;
  professor_nome?: string;
  temas: Tema[];
}

export interface Tema {
  id: string;
  disciplina_id: string;
  titulo: string;
  subtitulo?: string;
  ordem: number;
  materiais: Material[];
}

export interface Material {
  id: string;
  tema_id: string;
  titulo: string;
  tipo: 'video' | 'pdf' | 'link' | 'documento';
  url: string;
  descricao?: string;
}

export interface Aula {
  id: string;
  disciplina_id: string;
  disciplina_nome: string;
  professor_id: string;
  turma_id: string;
  tema?: string;
  data: string;
  hora_inicio: string;
  hora_fim: string;
  sala: string;
  status: 'agendada' | 'realizada' | 'cancelada';
}

export interface Nota {
  id: string;
  estudante_id: string;
  disciplina_id: string;
  disciplina_nome: string;
  professor_id: string;
  professor_nome: string;
  trimestre: 1 | 2 | 3;
  ano_letivo: number;
  nota: number;
  tipo_avaliacao: 'teste' | 'trabalho' | 'participacao' | 'exame' | 'outro';
  peso: number;
  data_avaliacao: string;
  observacao?: string;
}

export interface Teste {
  id: string;
  disciplina_id: string;
  disciplina_nome: string;
  professor_id: string;
  professor_nome: string;
  turma_id: string;
  titulo: string;
  descricao?: string;
  instrucoes?: string;
  data_inicio: string;
  data_fim: string;
  duracao_minutos: number;
  senha_acesso?: string;
  num_perguntas: number;
  pontuacao_maxima: number;
  tentativas_permitidas: number;
  aleatorizar_perguntas: boolean;
  mostrar_resultado_imediato: boolean;
  status: 'rascunho' | 'publicado' | 'encerrado';
  anti_fraude_ativo: boolean;
  perguntas?: Pergunta[];
}

export interface Pergunta {
  id: string;
  teste_id: string;
  pergunta: string;
  tipo: 'multipla_escolha' | 'verdadeiro_falso' | 'resposta_curta';
  opcoes: string[];
  resposta_correta: string | number;
  pontos: number;
  ordem: number;
}

export interface TesteResultado {
  id: string;
  teste_id: string;
  estudante_id: string;
  respostas: Record<string, string | number>;
  nota_obtida: number;
  data_realizacao: string;
  tempo_gasto: number;
  ip_address?: string;
  anti_fraude_log?: string;
}

export interface Mensalidade {
  id: string;
  estudante_id: string;
  mes_referencia: number;
  ano_letivo: number;
  valor_original: number;
  juros: number;
  desconto: number;
  valor_final: number;
  data_vencimento: string;
  data_pagamento?: string;
  status: 'pendente' | 'pago' | 'atrasado' | 'cancelado';
  metodo_pagamento?: string;
  referencia?: string;
  comprovativo_url?: string;
}

export interface Aviso {
  id: string;
  titulo: string;
  conteudo: string;
  tipo_destino: 'todos' | 'turma' | 'estudante' | 'professor';
  destino_id?: string;
  prioridade: 'baixa' | 'media' | 'alta' | 'urgente';
  data_publicacao: string;
  expira_em?: string;
  autor_id: string;
  autor_nome: string;
  lido?: boolean;
}

export interface BlocoNota {
  id: string;
  estudante_id: string;
  disciplina_id?: string;
  disciplina_nome?: string;
  conteudo: string;
  etiquetas: string[];
  data_criacao: string;
  data_atualizacao: string;
}

export interface ChatMessage {
  id: string;
  remetente_id: string;
  remetente_nome: string;
  remetente_foto?: string;
  destinatario_id: string;
  conteudo: string;
  anexos?: string[];
  data_envio: string;
  lida: boolean;
}

export interface Horario {
  id: string;
  turma_id: string;
  disciplina_id: string;
  disciplina_nome: string;
  professor_id: string;
  professor_nome: string;
  dia_semana: 0 | 1 | 2 | 3 | 4 | 5 | 6;
  hora_inicio: string;
  hora_fim: string;
  sala: string;
}

export interface Presenca {
  id: string;
  estudante_id: string;
  aula_id: string;
  data: string;
  presente: boolean;
  justificativa?: string;
  registrado_por: string;
}

export interface SystemConfig {
  id: string;
  chave: string;
  valor: string;
  tipo: 'string' | 'number' | 'boolean' | 'json';
  descricao?: string;
  categoria?: string;
}

export interface AccessLog {
  id: string;
  user_id: string;
  user_nome: string;
  acao: string;
  ip_address: string;
  user_agent: string;
  timestamp: string;
  sucesso: boolean;
  detalhes?: string;
}

export interface DashboardStats {
  totalEstudantes: number;
  totalProfessores: number;
  totalTurmas: number;
  totalDisciplinas: number;
  inadimplentes: number;
  mediaGeral: number;
  taxaPresenca: number;
}

export interface IndicadorDesempenho {
  trimestre: number;
  ano_letivo: number;
  media_turma: number;
  media_disciplina: number;
  taxa_aprovacao: number;
  taxa_reprovacao: number;
  comparativo_trimestre_anterior: number;
}
