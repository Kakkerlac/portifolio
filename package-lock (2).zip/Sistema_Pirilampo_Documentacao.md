# O Pirilampo - Secretaria Virtual Escolar
## Documentação Técnica Completa

---

## 1. VISÃO GERAL DO SISTEMA

### 1.1 Descrição
O Pirilampo é uma Secretaria Virtual Escolar completa, moderna, profissional, segura e escalável, desenvolvida para escolas em Angola. O sistema integra gestão pedagógica, financeira e administrativa em uma única plataforma.

### 1.2 Níveis de Acesso
| Perfil | Descrição | Nível |
|--------|-----------|-------|
| **Estudante** | Acesso às disciplinas, notas, calendário, testes | 1 |
| **Professor** | Gestão de turmas, notas, presenças, materiais | 2 |
| **Secretaria** | Gestão administrativa, RH, turmas, pagamentos | 3 |
| **Diretora Geral** | Visão estratégica, supervisão completa, auditoria | 4 |
| **TI (Admin)** | Acesso total, configurações críticas, logs | 5 |

---

## 2. ARQUITETURA RECOMENDADA

### 2.1 Arquitetura em Camadas

```
┌─────────────────────────────────────────────────────────────┐
│                    FRONTEND (React + TS)                     │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────────────────┐ │
│  │   Auth      │ │  Dashboards │ │      Components         │ │
│  │   Module    │ │  (5 roles)  │ │    (shadcn/ui)          │ │
│  └─────────────┘ └─────────────┘ └─────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
                              │
┌─────────────────────────────────────────────────────────────┐
│                      API GATEWAY                             │
│         (Rate Limiting, Auth Middleware, CORS)               │
└─────────────────────────────────────────────────────────────┘
                              │
┌─────────────────────────────────────────────────────────────┐
│                   BACKEND (Node.js/NestJS)                   │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────────────────┐ │
│  │   Auth      │ │   Services  │ │      Controllers        │ │
│  │   Service   │ │  (Business) │ │       (REST API)        │ │
│  └─────────────┘ └─────────────┘ └─────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
                              │
┌─────────────────────────────────────────────────────────────┐
│                      DATABASE LAYER                          │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────────────────┐ │
│  │  PostgreSQL │ │    Redis    │ │      MinIO/S3           │ │
│  │  (Primary)  │ │   (Cache)   │ │    (File Storage)       │ │
│  └─────────────┘ └─────────────┘ └─────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

### 2.2 Padrão de Arquitetura
- **Frontend**: SPA (Single Page Application) com React + TypeScript
- **Backend**: RESTful API com Node.js/NestJS ou Python/FastAPI
- **Database**: PostgreSQL (relacional) + Redis (cache/sessões)
- **File Storage**: MinIO ou AWS S3 (materiais, documentos)
- **Message Queue**: Redis/RabbitMQ (notificações, processamento)

---

## 3. MODELAGEM DA BASE DE DADOS

### 3.1 Diagrama Entidade-Relacionamento (Simplificado)

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│     users       │────│   user_roles    │────│      roles      │
├─────────────────┤     ├─────────────────┤     ├─────────────────┤
│ id (PK)         │     │ user_id (FK)    │     │ id (PK)         │
│ numero_utilizador│    │ role_id (FK)    │     │ name            │
│ password_hash   │     └─────────────────┘     │ permissions     │
│ email           │                             │ level           │
│ nome_completo   │                             └─────────────────┘
│ telefone        │
│ foto_url        │
│ ativo           │
│ bloqueado       │
│ created_at      │
└─────────────────┘
         │
         │         ┌─────────────────┐     ┌─────────────────┐
         │         │    estudantes   │     │    turmas       │
         │         ├─────────────────┤     ├─────────────────┤
         │         │ id (PK)         │     │ id (PK)         │
         │         │ user_id (FK)    │────│ nome            │
         │         │ turma_id (FK)   │     │ ano_letivo      │
         │         │ numero_matricula│     │ turno           │
         │         │ data_matricula  │     │ sala            │
         │         │ status_pagamento│     └─────────────────┘
         │         │ encarregado_id  │
         │         └─────────────────┘
         │
         │         ┌─────────────────┐     ┌─────────────────┐
         │         │   professores   │     │  disciplinas    │
         │         ├─────────────────┤     ├─────────────────┤
         │         │ id (PK)         │     │ id (PK)         │
         │         │ user_id (FK)    │     │ nome            │
         │         │ especialidade   │     │ codigo          │
         │         │ carga_horaria   │     │ descricao       │
         │         │ data_contratacao│     └─────────────────┘
         │         └─────────────────┘
         │
         │         ┌─────────────────┐     ┌─────────────────┐
         │         │   secretaria    │     │    direcao      │
         │         ├─────────────────┤     ├─────────────────┤
         │         │ id (PK)         │     │ id (PK)         │
         │         │ user_id (FK)    │     │ user_id (FK)    │
         │         │ departamento    │     │ cargo           │
         │         │ nivel_acesso    │     │ data_nomeacao   │
         │         └─────────────────┘     └─────────────────┘
         │
         │         ┌─────────────────┐
         │         │   ti_admins     │
         │         ├─────────────────┤
         │         │ id (PK)         │
         │         │ user_id (FK)    │
         │         │ nivel_permissao │
         │         │ ultimo_acesso   │
         │         └─────────────────┘

┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│     notas       │────│    disciplinas  │────│  professor_disc │
├─────────────────┤     ├─────────────────┤     ├─────────────────┤
│ id (PK)         │     │ id (PK)         │     │ professor_id    │
│ estudante_id    │     │ nome            │     │ disciplina_id   │
│ disciplina_id   │     │ codigo          │     │ turma_id        │
│ professor_id    │     │ descricao       │     │ ano_letivo      │
│ trimestre       │     └─────────────────┘     └─────────────────┘
│ nota            │
│ tipo_avaliacao  │
│ data            │
│ observacao      │
└─────────────────┘

┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│    testes       │────│  teste_perguntas│────│  teste_respostas│
├─────────────────┤     ├─────────────────┤     ├─────────────────┤
│ id (PK)         │     │ id (PK)         │     │ id (PK)         │
│ disciplina_id   │     │ teste_id (FK)   │     │ teste_id (FK)   │
│ professor_id    │     │ pergunta        │     │ estudante_id    │
│ titulo          │     │ opcoes (JSON)   │     │ respostas (JSON)│
│ descricao       │     │ resposta_correta│     │ nota_obtida     │
│ data_inicio     │     │ pontos          │     │ data_realizacao │
│ data_fim        │     └─────────────────┘     │ tempo_gasto     │
│ duracao_minutos │                             │ ip_address      │
│ senha_acesso    │                             │ anti_fraude_log │
│ status          │                             └─────────────────┘
└─────────────────┘

┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   pagamentos    │────│  mensalidades   │────│   encarregados  │
├─────────────────┤     ├─────────────────┤     ├─────────────────┤
│ id (PK)         │     │ id (PK)         │     │ id (PK)         │
│ estudante_id    │     │ estudante_id    │     │ user_id (FK)    │
│ tipo            │     │ mes_referencia  │     │ estudante_id    │
│ valor           │     │ ano_letivo      │     │ grau_parentesco │
│ data_vencimento │     │ valor           │     │ profissao       │
│ data_pagamento  │     │ data_vencimento │     │ telefone_alt    │
│ status          │     │ juros           │     └─────────────────┘
│ metodo          │     │ status          │
│ referencia      │     │ data_pagamento  │
│ comprovativo_url│     └─────────────────┘
└─────────────────┘

┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│    horarios     │────│     turmas      │────│    calendario   │
├─────────────────┤     ├─────────────────┤     ├─────────────────┤
│ id (PK)         │     │ id (PK)         │     │ id (PK)         │
│ turma_id        │     │ nome            │     │ data            │
│ disciplina_id   │     │ ano_letivo      │     │ tipo_evento     │
│ professor_id    │     │ turno           │     │ titulo          │
│ dia_semana      │     │ sala            │     │ descricao       │
│ hora_inicio     │     │ capacidade      │     │ turma_id        │
│ hora_fim        │     │ coordenador_id  │     │ disciplina_id   │
│ sala            │     └─────────────────┘     │ criado_por      │
└─────────────────┘                             └─────────────────┘

┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│     avisos      │────│  bloco_notas    │────│    chat_msgs    │
├─────────────────┤     ├─────────────────┤     ├─────────────────┤
│ id (PK)         │     │ id (PK)         │     │ id (PK)         │
│ titulo          │     │ estudante_id    │     │ remetente_id    │
│ conteudo        │     │ disciplina_id   │     │ destinatario_id │
│ tipo_destino    │     │ conteudo        │     │ conteudo        │
│ destino_id      │     │ etiquetas       │     │ anexos          │
│ prioridade      │     │ data_criacao    │     │ data_envio      │
│ data_publicacao │     │ data_atualizacao│     │ lida            │
│ expira_em       │     └─────────────────┘     └─────────────────┘
│ autor_id        │
└─────────────────┘

┌─────────────────┐     ┌─────────────────┐
│  access_logs    │     │ system_config   │
├─────────────────┤     ├─────────────────┤
│ id (PK)         │     │ id (PK)         │
│ user_id         │     │ chave           │
│ acao            │     │ valor           │
│ ip_address      │     │ descricao       │
│ user_agent      │     │ categoria       │
│ timestamp       │     │ atualizado_por  │
│ sucesso         │     │ atualizado_em   │
│ detalhes        │     └─────────────────┘
└─────────────────┘
```

### 3.2 Tabelas Detalhadas

#### 3.2.1 Tabela: `users`
```sql
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    numero_utilizador VARCHAR(20) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE,
    nome_completo VARCHAR(255) NOT NULL,
    telefone VARCHAR(20),
    foto_url TEXT,
    data_nascimento DATE,
    genero VARCHAR(10),
    endereco TEXT,
    cidade VARCHAR(100),
    provincia VARCHAR(100),
    bi_numero VARCHAR(20),
    ativo BOOLEAN DEFAULT true,
    bloqueado BOOLEAN DEFAULT false,
    motivo_bloqueio TEXT,
    data_ultimo_acesso TIMESTAMP,
    tentativas_login INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 3.2.2 Tabela: `roles`
```sql
CREATE TABLE roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(50) UNIQUE NOT NULL,
    slug VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    level INTEGER NOT NULL, -- 1-5
    permissions JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Roles iniciais
INSERT INTO roles (name, slug, description, level, permissions) VALUES
('Estudante', 'estudante', 'Acesso às disciplinas, notas e calendário', 1, '{
    "dashboard": ["view"],
    "disciplinas": ["view"],
    "notas": ["view"],
    "calendario": ["view"],
    "testes": ["view", "take"],
    "perfil": ["view"],
    "chat": ["send", "receive"]
}'),
('Professor', 'professor', 'Gestão de turmas, notas e materiais', 2, '{
    "dashboard": ["view"],
    "disciplinas": ["view", "manage"],
    "notas": ["create", "edit", "view"],
    "presencas": ["create", "edit", "view"],
    "testes": ["create", "edit", "view"],
    "materiais": ["upload", "delete"],
    "relatorios": ["view"],
    "chat": ["send", "receive"]
}'),
('Secretaria', 'secretaria', 'Gestão administrativa e financeira', 3, '{
    "dashboard": ["view"],
    "alunos": ["create", "edit", "view", "delete"],
    "professores": ["create", "edit", "view"],
    "turmas": ["create", "edit", "view"],
    "horarios": ["create", "edit", "view"],
    "pagamentos": ["view", "manage"],
    "mensalidades": ["mark_paid"],
    "relatorios": ["view", "generate"],
    "encarregados": ["create", "edit", "view"]
}'),
('Diretora Geral', 'diretora', 'Supervisão completa e auditoria', 4, '{
    "dashboard": ["view"],
    "all_data": ["view"],
    "relatorios": ["view", "generate", "export"],
    "auditoria": ["view"],
    "indicadores": ["view"],
    "secretaria": ["view", "supervise"]
}'),
('TI Admin', 'ti_admin', 'Acesso total ao sistema', 5, '{
    "all": ["*"],
    "users": ["create", "edit", "delete", "view"],
    "config": ["edit", "view"],
    "logs": ["view"],
    "permissoes": ["edit"],
    "bloqueios": ["manage"]
}');
```

#### 3.2.3 Tabela: `estudantes`
```sql
CREATE TABLE estudantes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    turma_id UUID REFERENCES turmas(id),
    numero_matricula VARCHAR(50) UNIQUE NOT NULL,
    data_matricula DATE NOT NULL,
    ano_letivo_atual INTEGER NOT NULL,
    status_pagamento VARCHAR(20) DEFAULT 'regular', -- regular, pendente, bloqueado
    dias_bloqueio INTEGER DEFAULT 0,
    encarregado_id UUID REFERENCES encarregados(id),
    observacoes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 3.2.4 Tabela: `notas`
```sql
CREATE TABLE notas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    estudante_id UUID REFERENCES estudantes(id) ON DELETE CASCADE,
    disciplina_id UUID REFERENCES disciplinas(id),
    professor_id UUID REFERENCES professores(id),
    trimestre INTEGER NOT NULL CHECK (trimestre BETWEEN 1 AND 3),
    ano_letivo INTEGER NOT NULL,
    nota DECIMAL(4,2) NOT NULL CHECK (nota BETWEEN 0 AND 20),
    tipo_avaliacao VARCHAR(50), -- teste, trabalho, participacao, exame
    peso DECIMAL(3,2) DEFAULT 1.00,
    data_avaliacao DATE,
    observacao TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 3.2.5 Tabela: `testes`
```sql
CREATE TABLE testes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    disciplina_id UUID REFERENCES disciplinas(id),
    professor_id UUID REFERENCES professores(id),
    turma_id UUID REFERENCES turmas(id),
    titulo VARCHAR(255) NOT NULL,
    descricao TEXT,
    instrucoes TEXT,
    data_inicio TIMESTAMP NOT NULL,
    data_fim TIMESTAMP NOT NULL,
    duracao_minutos INTEGER NOT NULL,
    senha_acesso VARCHAR(50),
    num_perguntas INTEGER NOT NULL,
    pontuacao_maxima INTEGER NOT NULL,
    tentativas_permitidas INTEGER DEFAULT 1,
    aleatorizar_perguntas BOOLEAN DEFAULT false,
    mostrar_resultado_imediato BOOLEAN DEFAULT false,
    status VARCHAR(20) DEFAULT 'rascunho', -- rascunho, publicado, encerrado
    anti_fraude_ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 3.2.6 Tabela: `mensalidades`
```sql
CREATE TABLE mensalidades (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    estudante_id UUID REFERENCES estudantes(id) ON DELETE CASCADE,
    mes_referencia INTEGER NOT NULL CHECK (mes_referencia BETWEEN 1 AND 12),
    ano_letivo INTEGER NOT NULL,
    valor_original DECIMAL(10,2) NOT NULL,
    juros DECIMAL(10,2) DEFAULT 0.00,
    desconto DECIMAL(10,2) DEFAULT 0.00,
    valor_final DECIMAL(10,2) NOT NULL,
    data_vencimento DATE NOT NULL,
    data_pagamento DATE,
    status VARCHAR(20) DEFAULT 'pendente', -- pendente, pago, atrasado, cancelado
    metodo_pagamento VARCHAR(50), -- transferencia, dinheiro, multicaixa, paypal
    referencia VARCHAR(100),
    comprovativo_url TEXT,
    processado_por UUID REFERENCES users(id),
    observacao TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 3.2.7 Tabela: `system_config`
```sql
CREATE TABLE system_config (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    chave VARCHAR(100) UNIQUE NOT NULL,
    valor TEXT NOT NULL,
    tipo VARCHAR(20) DEFAULT 'string', -- string, number, boolean, json
    descricao TEXT,
    categoria VARCHAR(50),
    atualizado_por UUID REFERENCES users(id),
    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Configurações iniciais
INSERT INTO system_config (chave, valor, tipo, descricao, categoria) VALUES
('bloqueio_inadimplencia_dias', '60', 'number', 'Dias de atraso para bloqueio automático', 'pagamentos'),
('bloqueio_inadimplencia_ativo', 'true', 'boolean', 'Ativar bloqueio automático por inadimplência', 'pagamentos'),
('juros_atraso_percentual', '2.5', 'number', 'Percentual de juros por mês de atraso', 'pagamentos'),
('tentativas_login_maximas', '5', 'number', 'Máximo de tentativas de login antes do bloqueio', 'seguranca'),
('sessao_duracao_minutos', '120', 'number', 'Duração da sessão em minutos', 'seguranca'),
('ano_letivo_atual', '2025', 'number', 'Ano letivo atual', 'academico'),
('trimestre_atual', '1', 'number', 'Trimestre atual', 'academico'),
('escola_nome', 'Colégio O Pirilampo', 'string', 'Nome da instituição', 'institucional'),
('escola_endereco', 'Luanda, Angola', 'string', 'Endereço da instituição', 'institucional'),
('escola_telefone', '+244 900 000 000', 'string', 'Telefone da instituição', 'institucional'),
('escola_email', 'contacto@pirilampo.ao', 'string', 'Email da instituição', 'institucional'),
('logo_url', '/assets/logo.png', 'string', 'URL do logo da instituição', 'institucional'),
('tema_cor_primaria', '#4F46E5', 'string', 'Cor primária do tema', 'aparencia'),
('tema_cor_secundaria', '#10B981', 'string', 'Cor secundária do tema', 'aparencia'),
('notificacoes_email_ativo', 'true', 'boolean', 'Ativar notificações por email', 'notificacoes'),
('notificacoes_sms_ativo', 'false', 'boolean', 'Ativar notificações por SMS', 'notificacoes'),
('backup_automatico', 'true', 'boolean', 'Ativar backup automático', 'manutencao'),
('backup_frequencia_horas', '24', 'number', 'Frequência do backup em horas', 'manutencao');
```

---

## 4. FLUXO DE PERMISSÕES (RBAC)

### 4.1 Diagrama de Fluxo de Autenticação

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   Login     │────▶│  Verificar  │────▶│   Gerar     │────▶│  Redirecionar│
│  (User/Pass)│     │  Credenciais│     │    JWT      │     │  por Role   │
└─────────────┘     └─────────────┘     └─────────────┘     └─────────────┘
                                                              │
                                    ┌─────────────────────────┼─────────────────────────┐
                                    │                         │                         │
                              ┌─────▼─────┐            ┌─────▼─────┐            ┌─────▼─────┐
                              │Estudante  │            │ Professor │            │Secretaria │
                              │  Dashboard│            │ Dashboard │            │ Dashboard │
                              └───────────┘            └───────────┘            └───────────┘
                                    │                         │                         │
                              ┌─────▼─────┐            ┌─────▼─────┐            ┌─────▼─────┐
                              │Diretora   │            │  TI Admin │            │           │
                              │  Dashboard│            │ Dashboard │            │           │
                              └───────────┘            └───────────┘            └───────────┘
```

### 4.2 Middleware de Autorização

```typescript
// auth.middleware.ts
interface PermissionCheck {
  resource: string;
  action: string;
}

const checkPermission = (required: PermissionCheck) => {
  return (req: Request, res: Response, next: NextFunction) => {
    const userRole = req.user.role;
    const permissions = userRole.permissions;
    
    if (permissions[required.resource]?.includes(required.action) || 
        permissions[required.resource]?.includes('*')) {
      next();
    } else {
      res.status(403).json({ error: 'Acesso negado' });
    }
  };
};

// Uso nas rotas
app.get('/api/notas', 
  authenticateJWT, 
  checkPermission({ resource: 'notas', action: 'view' }),
  notasController.list
);
```

### 4.3 Matriz de Permissões

| Recurso | Estudante | Professor | Secretaria | Diretora | TI |
|---------|-----------|-----------|------------|----------|-----|
| **Dashboard** | Próprio | Próprio | Completo | Estratégico | Total |
| **Disciplinas** | Ver | Gerenciar | Ver | Ver | Total |
| **Notas** | Ver | Inserir/Editar | Ver | Ver | Total |
| **Testes** | Fazer | Criar/Gerenciar | Ver | Ver | Total |
| **Presenças** | Ver | Lançar | Ver | Ver | Total |
| **Turmas** | Ver | Ver (próprias) | Gerenciar | Supervisionar | Total |
| **Alunos** | Ver (próprio) | Ver (suas) | Gerenciar | Supervisionar | Total |
| **Professores** | Ver | Ver (próprio) | Gerenciar | Supervisionar | Total |
| **Pagamentos** | Ver (próprio) | - | Gerenciar | Supervisionar | Total |
| **Relatórios** | Básicos | Turma | Administrativos | Estratégicos | Todos |
| **Configurações** | - | - | Parcial | Parcial | Total |
| **Logs** | - | - | - | Auditoria | Total |
| **Usuários** | - | - | Criar/Editar | Supervisionar | Total |

---

## 5. ESTRUTURA DE PASTAS

### 5.1 Estrutura do Projeto Frontend

```
/mnt/okcomputer/output/app/
├── public/
│   ├── assets/
│   │   ├── logo.png
│   │   ├── logo-white.png
│   │   └── favicon.ico
│   └── index.html
├── src/
│   ├── components/
│   │   ├── ui/                    # shadcn/ui components
│   │   ├── layout/
│   │   │   ├── Sidebar.tsx
│   │   │   ├── Header.tsx
│   │   │   ├── Footer.tsx
│   │   │   └── DashboardLayout.tsx
│   │   ├── common/
│   │   │   ├── DataTable.tsx
│   │   │   ├── ChartCard.tsx
│   │   │   ├── StatCard.tsx
│   │   │   ├── Modal.tsx
│   │   │   └── Loading.tsx
│   │   └── forms/
│   │       ├── InputField.tsx
│   │       ├── SelectField.tsx
│   │       └── DatePicker.tsx
│   ├── pages/
│   │   ├── auth/
│   │   │   ├── Login.tsx
│   │   │   ├── ForgotPassword.tsx
│   │   │   └── ResetPassword.tsx
│   │   ├── estudante/
│   │   │   ├── Dashboard.tsx
│   │   │   ├── Disciplinas.tsx
│   │   │   ├── DisciplinaDetail.tsx
│   │   │   ├── Calendario.tsx
│   │   │   ├── Notas.tsx
│   │   │   ├── Testes.tsx
│   │   │   ├── TesteRealizar.tsx
│   │   │   ├── Classificacao.tsx
│   │   │   └── Perfil.tsx
│   │   ├── professor/
│   │   │   ├── Dashboard.tsx
│   │   │   ├── MinhasTurmas.tsx
│   │   │   ├── LancarNotas.tsx
│   │   │   ├── LancarPresencas.tsx
│   │   │   ├── CriarTeste.tsx
│   │   │   ├── Materiais.tsx
│   │   │   └── Relatorios.tsx
│   │   ├── secretaria/
│   │   │   ├── Dashboard.tsx
│   │   │   ├── Alunos/
│   │   │   │   ├── Lista.tsx
│   │   │   │   ├── Cadastro.tsx
│   │   │   │   └── Detalhes.tsx
│   │   │   ├── Professores/
│   │   │   │   ├── Lista.tsx
│   │   │   │   └── Cadastro.tsx
│   │   │   ├── Turmas/
│   │   │   │   ├── Lista.tsx
│   │   │   │   └── Gerenciar.tsx
│   │   │   ├── Horarios/
│   │   │   │   └── Gerenciar.tsx
│   │   │   ├── Pagamentos/
│   │   │   │   ├── Mensalidades.tsx
│   │   │   │   ├── Historico.tsx
│   │   │   │   └── Inadimplentes.tsx
│   │   │   └── Relatorios/
│   │   │       └── Gerar.tsx
│   │   ├── diretora/
│   │   │   ├── Dashboard.tsx
│   │   │   ├── VisaoGeral.tsx
│   │   │   ├── Indicadores.tsx
│   │   │   ├── Auditoria.tsx
│   │   │   └── RelatoriosGlobais.tsx
│   │   └── ti/
│   │       ├── Dashboard.tsx
│   │       ├── Usuarios/
│   │       │   ├── Lista.tsx
│   │       │   └── Permissoes.tsx
│   │       ├── Configuracoes/
│   │       │   └── Sistema.tsx
│   │       ├── Logs/
│   │       │   └── Visualizar.tsx
│   │       └── Manutencao/
│   │           └── Ferramentas.tsx
│   ├── hooks/
│   │   ├── useAuth.ts
│   │   ├── usePermissions.ts
│   │   ├── useLocalStorage.ts
│   │   └── useToast.ts
│   ├── context/
│   │   ├── AuthContext.tsx
│   │   ├── ThemeContext.tsx
│   │   └── NotificationContext.tsx
│   ├── services/
│   │   ├── api.ts
│   │   ├── auth.service.ts
│   │   ├── notas.service.ts
│   │   ├── testes.service.ts
│   │   ├── pagamentos.service.ts
│   │   └── relatorios.service.ts
│   ├── types/
│   │   ├── user.ts
│   │   ├── estudante.ts
│   │   ├── professor.ts
│   │   ├── nota.ts
│   │   ├── teste.ts
│   │   └── pagamento.ts
│   ├── utils/
│   │   ├── constants.ts
│   │   ├── helpers.ts
│   │   ├── formatters.ts
│   │   └── validators.ts
│   ├── data/
│   │   └── mockData.ts
│   ├── styles/
│   │   └── globals.css
│   ├── App.tsx
│   ├── App.css
│   ├── main.tsx
│   └── index.css
├── package.json
├── tsconfig.json
├── vite.config.ts
├── tailwind.config.js
└── README.md
```

---

## 6. TECNOLOGIAS RECOMENDADAS

### 6.1 Frontend
| Tecnologia | Versão | Propósito |
|------------|--------|-----------|
| **React** | 18.x | Framework UI |
| **TypeScript** | 5.x | Tipagem estática |
| **Vite** | 5.x | Build tool |
| **Tailwind CSS** | 3.4.x | Estilização |
| **shadcn/ui** | Latest | Componentes UI |
| **React Router** | 6.x | Navegação |
| **TanStack Query** | 5.x | Gerenciamento de estado server |
| **Zustand** | 4.x | Gerenciamento de estado client |
| **Recharts** | 2.x | Gráficos e visualizações |
| **React Hook Form** | 7.x | Formulários |
| **Zod** | 3.x | Validação de schemas |
| **Axios** | 1.x | HTTP client |
| **date-fns** | 3.x | Manipulação de datas |
| **Lucide React** | Latest | Ícones |

### 6.2 Backend (Recomendação)
| Tecnologia | Versão | Propósito |
|------------|--------|-----------|
| **Node.js** | 20.x | Runtime |
| **NestJS** | 10.x | Framework backend |
| **TypeScript** | 5.x | Tipagem |
| **PostgreSQL** | 16.x | Banco de dados |
| **Prisma** | 5.x | ORM |
| **Redis** | 7.x | Cache/Sessões |
| **JWT** | 9.x | Autenticação |
| **bcrypt** | 5.x | Hash de senhas |
| **Joi/Zod** | Latest | Validação |
| **Winston** | 3.x | Logging |
| **Swagger** | Latest | Documentação API |

### 6.3 DevOps & Infraestrutura
| Tecnologia | Propósito |
|------------|-----------|
| **Docker** | Containerização |
| **Docker Compose** | Orquestração local |
| **Nginx** | Reverse proxy |
| **GitHub Actions** | CI/CD |
| **AWS/Azure** | Cloud hosting |
| **Let's Encrypt** | SSL/TLS |

---

## 7. SISTEMA DE BLOQUEIO POR INADIMPLÊNCIA

### 7.1 Fluxo do Sistema

```
┌─────────────────┐
│ Mensalidade     │
│ Vencida         │
└────────┬────────┘
         │
         ▼
┌─────────────────┐     ┌─────────────────┐
│ Verificar       │────▶│ Notificar       │
│ Atraso          │     │ Estudante/Resp  │
└────────┬────────┘     └─────────────────┘
         │
         │ Após 30 dias
         ▼
┌─────────────────┐     ┌─────────────────┐
│ Aplicar Juros   │────▶│ Notificar       │
│ (2.5% ao mês)   │     │ Novamente       │
└────────┬────────┘     └─────────────────┘
         │
         │ Após 60 dias (configurável)
         ▼
┌─────────────────┐     ┌─────────────────┐
│ Bloquear Conta  │────▶│ Notificar       │
│ do Estudante    │     │ Bloqueio        │
└────────┬────────┘     └─────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────┐
│ ACESSO BLOQUEADO:                               │
│ ❌ Testes                                       │
│ ❌ Matérias                                     │
│ ❌ Horários                                     │
│ ❌ Avisos                                       │
│ ❌ Notas                                        │
│                                                 │
│ ✅ Apenas:                                      │
│   - Visualizar mensagem de bloqueio             │
│   - Acesso à área de pagamentos                 │
│   - Contato com secretaria                      │
└─────────────────────────────────────────────────┘
```

### 7.2 Implementação

```typescript
// payment-block.service.ts
class PaymentBlockService {
  async verificarInadimplencia(estudanteId: string): Promise<{
    bloqueado: boolean;
    diasAtraso: number;
    mensalidadesPendentes: number;
    valorTotalDevido: number;
  }> {
    const mensalidades = await this.prisma.mensalidades.findMany({
      where: {
        estudante_id: estudanteId,
        status: 'pendente',
        data_vencimento: { lt: new Date() }
      }
    });

    const diasBloqueio = await this.config.get('bloqueio_inadimplencia_dias');
    const bloqueioAtivo = await this.config.get('bloqueio_inadimplencia_ativo');
    
    const maiorAtraso = Math.max(...mensalidades.map(m => 
      Math.floor((Date.now() - m.data_vencimento.getTime()) / (1000 * 60 * 60 * 24))
    ));

    const deveBloquear = bloqueioAtivo && maiorAtraso >= diasBloqueio;

    if (deveBloquear) {
      await this.bloquearEstudante(estudanteId, maiorAtraso);
    }

    return {
      bloqueado: deveBloquear,
      diasAtraso: maiorAtraso,
      mensalidadesPendentes: mensalidades.length,
      valorTotalDevido: mensalidades.reduce((sum, m) => sum + m.valor_final, 0)
    };
  }

  async bloquearEstudante(estudanteId: string, diasAtraso: number): Promise<void> {
    await this.prisma.estudantes.update({
      where: { id: estudanteId },
      data: { 
        status_pagamento: 'bloqueado',
        dias_bloqueio: diasAtraso
      }
    });

    await this.notificacaoService.enviar({
      tipo: 'BLOQUEIO_CONTA',
      destinatario: estudanteId,
      titulo: 'Conta Bloqueada - Pagamento Pendente',
      mensagem: `Sua conta foi bloqueada devido a ${diasAtraso} dias de inadimplência.`
    });
  }
}
```

---

## 8. SUGESTÕES DE MELHORIAS INTELIGENTES

### 8.1 Inteligência Artificial & Machine Learning

1. **Previsão de Desempenho**
   - Algoritmo que analisa padrões de notas e presenças
   - Alerta precoce para estudantes em risco de reprovação
   - Sugestões de intervenção pedagógica

2. **Chatbot de Atendimento**
   - Assistente virtual para dúvidas frequentes
   - Disponível 24/7 para estudantes e encarregados
   - Integração com WhatsApp

3. **Análise de Sentimento**
   - Análise de feedbacks dos estudantes
   - Identificação de problemas em disciplinas específicas
   - Monitoramento da satisfação geral

### 8.2 Recursos Avançados

4. **Gamificação**
   - Sistema de pontos e badges
   - Ranking de desempenho
   - Desafios semanais/mensais

5. **Relatórios Preditivos**
   - Previsão de inadimplência
   - Projeção de matrículas
   - Análise de tendências de desempenho

6. **Integração com Plataformas Externas**
   - Google Classroom
   - Microsoft Teams
   - Zoom para aulas online

7. **Aplicativo Mobile**
   - Versão PWA (Progressive Web App)
   - Notificações push
   - Acesso offline parcial

8. **Biometria & Segurança**
   - Login com reconhecimento facial (opcional)
   - Autenticação de dois fatores (2FA)
   - Detecção de comportamento suspeito

### 8.3 Funcionalidades Extras

9. **Portal do Encarregado**
   - App dedicado para pais/responsáveis
   - Notificações em tempo real
   - Comunicação direta com professores

10. **Biblioteca Digital**
    - Acervo de livros e materiais
    - Sistema de empréstimo digital
    - Integração com bibliotecas externas

11. **Gestão de Transporte Escolar**
    - Rotas e horários
    - Rastreamento de veículos
    - Notificações de chegada

12. **Cantina Escolar**
    - Cardápio digital
    - Pagamento integrado
    - Controle de restrições alimentares

---

## 9. INTEGRAÇÃO DE PAGAMENTOS (ANGOLA)

### 9.1 Entidades Pagadoras Suportadas

| Entidade | Tipo | Status |
|----------|------|--------|
| **Multicaixa Express** | Transferência/Referência | ✅ Recomendado |
| **Unitel Money** | Mobile Money | ✅ Recomendado |
| **Africell Money** | Mobile Money | ✅ Opcional |
| **PayPal** | Internacional | ✅ Opcional |
| **Stripe** | Cartão Internacional | ✅ Opcional |

### 9.2 Fluxo de Pagamento

```
Estudante/Responsável
        │
        ▼
┌─────────────────┐
│ Seleciona       │
│ Método          │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Gera Referência │
│ ou QR Code      │
└────────┬────────┘
         │
         ▼
┌─────────────────┐     ┌─────────────────┐
│ Realiza         │────▶│ Sistema recebe  │
│ Pagamento       │     │ Confirmação     │
└─────────────────┘     └────────┬────────┘
                                 │
                                 ▼
                        ┌─────────────────┐
                        │ Atualiza        │
                        │ Mensalidade     │
                        └────────┬────────┘
                                 │
                                 ▼
                        ┌─────────────────┐
                        │ Libera Acesso   │
                        │ (se bloqueado)  │
                        └─────────────────┘
```

---

## 10. SEGURANÇA

### 10.1 Medidas Implementadas

- ✅ **HTTPS/TLS 1.3** em todas as conexões
- ✅ **Hash de senhas** com bcrypt (cost factor 12)
- ✅ **JWT** com expiração curta (2 horas)
- ✅ **Refresh tokens** para sessões longas
- ✅ **Rate limiting** nas APIs
- ✅ **CORS** configurado corretamente
- ✅ **Sanitização** de inputs (XSS protection)
- ✅ **SQL Injection** protection (ORM/Prepared statements)
- ✅ **CSRF tokens** para formulários
- ✅ **Logs de auditoria** de todas as ações críticas
- ✅ **Backup criptografado** diário
- ✅ **2FA** opcional para usuários administrativos

### 10.2 Conformidade

- **LGPD/DPGA** (Lei de Proteção de Dados de Angola)
- **GDPR** (para cidadãos europeos, se aplicável)
- **PCI DSS** (para dados de pagamento)

---

## 11. IMPLEMENTAÇÃO PASSO A PASSO

### Fase 1: Fundação (Semanas 1-2)
- [x] Setup do projeto
- [ ] Configuração do banco de dados
- [ ] Sistema de autenticação
- [ ] Middleware de permissões

### Fase 2: Core (Semanas 3-4)
- [ ] Dashboard do Estudante
- [ ] Dashboard do Professor
- [ ] Gestão de notas
- [ ] Gestão de presenças

### Fase 3: Admin (Semanas 5-6)
- [ ] Dashboard da Secretaria
- [ ] Gestão de turmas e horários
- [ ] Dashboard da Diretora
- [ ] Sistema de relatórios

### Fase 4: Avançado (Semanas 7-8)
- [ ] Sistema de testes online
- [ ] Sistema de pagamentos
- [ ] Bloqueio por inadimplência
- [ ] Dashboard de TI

### Fase 5: Polimento (Semanas 9-10)
- [ ] Testes de segurança
- [ ] Otimização de performance
- [ ] Documentação final
- [ ] Treinamento da equipe

---

## 12. CONCLUSÃO

O Pirilampo é um sistema completo, moderno e escalável que atende às necessidades de uma escola angolana contemporânea. Com arquitetura robusta, segurança avançada e interface intuitiva, o sistema proporciona:

- **Para Estudantes**: Acesso fácil a todas as informações acadêmicas
- **Para Professores**: Ferramentas eficientes de gestão pedagógica
- **Para Secretaria**: Controle administrativo e financeiro integrado
- **Para Direção**: Visão estratégica e indicadores de desempenho
- **Para TI**: Controle total e manutenção simplificada

O sistema está pronto para ser implementado e pode crescer conforme as necessidades da instituição.

---

**Documentação Técnica - O Pirilampo**  
*Versão 1.0 - Fevereiro 2025*  
*Desenvolvido para escolas em Angola*
